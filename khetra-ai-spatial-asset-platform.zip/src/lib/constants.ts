export const ROLES = ["admin", "reviewer", "operator"] as const;
export type Role = (typeof ROLES)[number];

export const ROLE_LABELS: Record<Role, string> = {
  admin: "Administrator",
  reviewer: "Reviewer",
  operator: "Data Entry Operator",
};

export const STATUSES = ["draft", "needs_review", "approved", "published"] as const;
export type Status = (typeof STATUSES)[number];

export const STATUS_LABELS: Record<Status, string> = {
  draft: "Draft",
  needs_review: "Needs Review",
  approved: "Approved",
  published: "Published",
};

/** Allowed status transitions grouped by role. Enforced server-side. */
export const TRANSITIONS: Record<Role, Record<Status, Status[]>> = {
  operator: {
    draft: ["needs_review"],
    needs_review: ["draft"],
    approved: [],
    published: [],
  },
  reviewer: {
    draft: ["needs_review"],
    needs_review: ["approved", "draft"],
    approved: ["needs_review", "published"],
    published: ["approved"],
  },
  admin: {
    draft: ["needs_review", "approved", "published"],
    needs_review: ["draft", "approved", "published"],
    approved: ["draft", "needs_review", "published"],
    published: ["approved", "draft"],
  },
};

export const ASSET_TYPES = ["land", "building", "other"] as const;
export type AssetType = (typeof ASSET_TYPES)[number];

export const DOC_TYPES = [
  { id: "ror_extract", label: "RoR / Khata Extract" },
  { id: "register_page", label: "Endowment Register Page" },
  { id: "settlement", label: "Settlement Record" },
  { id: "map_sheet", label: "Map Sheet" },
  { id: "other", label: "Other Document" },
] as const;

export const DEMO_NOTICE =
  "Demonstration Platform: This project illustrates how religious institutions could digitise, map, preserve, and manage their assets. Property records, parcel boundaries, documents, and collection figures shown as sample data are illustrative and must not be used for legal, ownership, survey, or financial decisions.";

export const CONCERN_LABEL = "Reported concern — not legally determined";

/** Basemap definitions (rendered client-side by Leaflet). */
export const BASEMAPS = {
  satellite: {
    id: "satellite",
    label: "Satellite",
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution:
      "Imagery © Esri & contributors — Maxar, Earthstar Geographics, USDA FSA, USGS, Aerogrid, IGN, IGP, and the GIS User Community. Imagery dates, resolution and accuracy vary by location and scale; not survey-accurate.",
    maxZoom: 19,
  },
  labeled: {
    id: "labeled",
    label: "Satellite + Labels",
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    overlayUrl:
      "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
    attribution:
      "Imagery © Esri & contributors; Reference labels © Esri, HERE, Garmin, FAO, NOAA, USGS. Varies by location; not survey-accurate.",
    maxZoom: 19,
  },
  street: {
    id: "street",
    label: "Street Map",
    url: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution: "© OpenStreetMap contributors",
    maxZoom: 19,
  },
} as const;

export type BasemapId = keyof typeof BASEMAPS;

export const UPLOAD_LIMIT_BYTES = 15 * 1024 * 1024;
export const ALLOWED_UPLOAD_TYPES: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/jpg": "jpg",
  "application/pdf": "pdf",
};
