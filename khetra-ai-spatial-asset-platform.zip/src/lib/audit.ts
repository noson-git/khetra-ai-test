import "server-only";
import { db } from "@/db";
import { auditLog } from "@/db/schema";
import type { SessionUser } from "./auth";

export async function logAudit(opts: {
  user: SessionUser | null;
  action: string;
  entity: string;
  entityId?: string | null;
  summary: string;
  payload?: unknown;
}) {
  try {
    await db.insert(auditLog).values({
      userId: opts.user?.id ?? null,
      userName: opts.user?.displayName ?? "system",
      userRole: opts.user?.role ?? "system",
      action: opts.action,
      entity: opts.entity,
      entityId: opts.entityId ?? null,
      summary: opts.summary,
      payload: opts.payload === undefined ? null : (opts.payload as never),
    });
  } catch (e) {
    console.error("audit write failed", e);
  }
}
