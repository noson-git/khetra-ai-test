import "server-only";
import { cookies } from "next/headers";
import { randomBytes } from "node:crypto";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";
import type { Role } from "./constants";

export { hashPassword, verifyPassword } from "./password";

export const SESSION_COOKIE = "khetra_session";
const SESSION_DAYS = 7;

export type SessionUser = {
  id: string;
  username: string;
  displayName: string;
  role: Role;
};

export function newToken(): string {
  return randomBytes(32).toString("hex");
}

export async function createSession(userId: string): Promise<string> {
  const token = newToken();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ token, userId, expiresAt });
  return token;
}

export async function destroySession(token: string): Promise<void> {
  await db.delete(sessions).where(eq(sessions.token, token));
}

/** Read the current session from the request cookie. Returns null if unauthenticated. */
export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
    .limit(1);
  const row = rows[0];
  if (!row) return null;
  return {
    id: row.user.id,
    username: row.user.username,
    displayName: row.user.displayName,
    role: row.user.role as Role,
  };
}

export function unauthorized(message = "Authentication required") {
  return Response.json({ ok: false, error: "unauthorized", message }, { status: 401 });
}

export function forbidden(message = "Your role does not permit this action") {
  return Response.json({ ok: false, error: "forbidden", message }, { status: 403 });
}

export function badRequest(message: string, extra?: Record<string, unknown>) {
  return Response.json({ ok: false, error: "bad_request", message, ...extra }, { status: 400 });
}

export function notFound(message = "Not found") {
  return Response.json({ ok: false, error: "not_found", message }, { status: 404 });
}

/** Guard: returns the user or a ready Response (401/403) to return directly. */
export async function requireRole(roles: Role[]): Promise<{ user: SessionUser | null; response: Response | null }> {
  const user = await getSessionUser();
  if (!user) return { user: null, response: unauthorized() };
  if (!roles.includes(user.role)) return { user: null, response: forbidden() };
  return { user, response: null };
}

export async function requireAuth(): Promise<{ user: SessionUser | null; response: Response | null }> {
  const user = await getSessionUser();
  if (!user) return { user: null, response: unauthorized() };
  return { user, response: null };
}
