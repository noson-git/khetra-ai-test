import { CONCERN_LABEL } from "./constants";

/* Serializers keep staff-only fields out of public payloads (privacy redaction). */

type PropRow = Record<string, unknown>;

export function serializeProperty(p: PropRow, scope: "public" | "staff") {
  const base = {
    id: p.id,
    assetCode: p.assetCode,
    institutionId: p.institutionId,
    assetType: p.assetType,
    title: p.title,
    description: p.description,
    district: p.district,
    tahasil: p.tahasil,
    mouza: p.mouza,
    khataNo: p.khataNo,
    plotNo: p.plotNo,
    landClass: p.landClass,
    areaOriginal: p.areaOriginal,
    areaUnit: p.areaUnit,
    areaAcres: p.areaAcres === null || p.areaAcres === undefined ? null : Number(p.areaAcres),
    docDate: p.docDate,
    docRef: p.docRef,
    geom: p.geom,
    lat: p.lat,
    lng: p.lng,
    geometryNote: p.geometryNote,
    status: p.status,
    archived: p.archived,
    reportedConcern: p.reportedConcern,
    concernNote: p.reportedConcern ? CONCERN_LABEL : null,
    concernDetail: scope === "staff" ? p.concernNote : null, // detail stays staff-only
    sampleData: p.sampleData ?? true,
    createdAt: p.createdAt,
    updatedAt: p.updatedAt,
  };
  if (scope === "staff") {
    return { ...base, sensitiveNote: p.sensitiveNote ?? null, concernDetail: p.concernNote ?? null };
  }
  return { ...base, redactionNote: p.sensitiveNote ? "Personal details and internal notes redacted for public view." : null };
}

export function serializeDocument(d: PropRow, scope: "public" | "staff") {
  const ocrMeta = d.ocr && typeof d.ocr === "object" ? (d.ocr as Record<string, unknown>) : null;
  const base = {
    id: d.id,
    institutionId: d.institutionId,
    propertyId: d.propertyId,
    title: d.title,
    docType: d.docType,
    refNo: d.refNo,
    docDate: d.docDate,
    status: d.status,
    mime: d.mime,
    pageKind: d.pageKind,
    version: d.version,
    redactedPublic: d.redactedPublic,
    extracted: d.extracted ?? null,
    ocr: ocrMeta
      ? {
          status: ocrMeta.status ?? null,
          engine: ocrMeta.engine ?? null,
          languages: ocrMeta.languages ?? null,
          processedAt: ocrMeta.processedAt ?? null,
          avgConfidence: ocrMeta.avgConfidence ?? null,
          words: ocrMeta.words ?? null,
          imageQuality: ocrMeta.imageQuality ?? null,
          message: ocrMeta.message ?? null,
          rawText: scope === "staff" ? (ocrMeta.rawText ?? null) : null,
        }
      : null,
    sampleData: d.sampleData ?? true,
    createdAt: d.createdAt,
    updatedAt: d.updatedAt,
  };
  if (scope === "staff") {
    return { ...base, sensitiveNote: d.sensitiveNote ?? null, originalPath: d.originalPath, enhancedPath: d.enhancedPath ?? null };
  }
  return {
    ...base,
    hasSensitiveRedactions: Boolean(d.sensitiveNote),
  };
}

export function serializeHundi(h: PropRow) {
  return {
    id: h.id,
    institutionId: h.institutionId,
    collectionDate: h.collectionDate,
    cashRupees: Number(h.cashRupees ?? 0),
    draftRupees: Number(h.draftRupees ?? 0),
    totalRupees: Number(h.totalRupees ?? 0),
    committeeNote: h.committeeNote,
    sourceRef: h.sourceRef,
    sampleData: h.sampleData ?? true,
    createdAt: h.createdAt,
    updatedAt: h.updatedAt,
  };
}

export function serializeInstitution(i: PropRow) {
  return {
    id: i.id,
    name: i.name,
    nameOdia: i.nameOdia,
    deity: i.deity,
    type: i.type,
    city: i.city,
    district: i.district,
    lat: i.lat,
    lng: i.lng,
    active: i.active,
  };
}
