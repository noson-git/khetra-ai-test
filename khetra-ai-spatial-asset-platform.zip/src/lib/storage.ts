import "server-only";
import { mkdir, writeFile, access } from "node:fs/promises";
import path from "node:path";
import { ALLOWED_UPLOAD_TYPES, UPLOAD_LIMIT_BYTES } from "./constants";

const ROOT = path.join(process.cwd(), "storage");

export function storageRoot() {
  return ROOT;
}

export function ocrDataDir() {
  return path.join(process.cwd(), "ocr-data");
}

export async function ensureDirs() {
  await mkdir(path.join(ROOT, "documents"), { recursive: true });
  await mkdir(path.join(ROOT, "enhanced"), { recursive: true });
}

/** Resolve a storage-relative path safely (no traversal outside storage/). */
export function resolveStorage(relPath: string): string | null {
  const abs = path.resolve(ROOT, relPath);
  if (!abs.startsWith(path.resolve(ROOT) + path.sep)) return null;
  return abs;
}

export async function fileExists(relPath: string | null | undefined): Promise<boolean> {
  if (!relPath) return false;
  const abs = resolveStorage(relPath);
  if (!abs) return false;
  try {
    await access(abs);
    return true;
  } catch {
    return false;
  }
}

export type UploadValidation = { ok: true; ext: string } | { ok: false; message: string };

export function validateUpload(mime: string, size: number): UploadValidation {
  const ext = ALLOWED_UPLOAD_TYPES[mime];
  if (!ext) {
    return {
      ok: false,
      message: `Unsupported file type "${mime}". Accepted: PDF, JPG, PNG.`,
    };
  }
  if (size <= 0) return { ok: false, message: "The uploaded file is empty." };
  if (size > UPLOAD_LIMIT_BYTES) {
    return { ok: false, message: `File exceeds the ${Math.round(UPLOAD_LIMIT_BYTES / 1024 / 1024)} MB limit.` };
  }
  return { ok: true, ext };
}

export async function saveUpload(documentId: string, buffer: Buffer, ext: string): Promise<string> {
  await ensureDirs();
  const rel = `documents/${documentId}-original.${ext}`;
  await writeFile(path.join(ROOT, rel), buffer);
  return rel;
}

export async function saveEnhanced(documentId: string, buffer: Buffer): Promise<string> {
  await ensureDirs();
  const rel = `enhanced/${documentId}-enhanced.png`;
  await writeFile(path.join(ROOT, rel), buffer);
  return rel;
}

export async function saveVersion(documentId: string, version: number, buffer: Buffer, ext: string): Promise<string> {
  await ensureDirs();
  const rel = `documents/${documentId}-v${version}.${ext}`;
  await writeFile(path.join(ROOT, rel), buffer);
  return rel;
}
