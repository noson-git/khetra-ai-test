import "server-only";
import path from "node:path";
import { readFile } from "node:fs/promises";
import { ocrDataDir } from "./storage";

/**
 * OCR pipeline — honesty contract:
 *  - If the engine or language data is missing, report `configured: false`
 *    with explicit setup guidance. Never fabricate a successful run.
 *  - Fields that cannot be read are returned as "not_detected" or
 *    "illegible" — never invented.
 *  - Original units are preserved verbatim; normalisation is separate and
 *    marked `uncertain` when assumptions were needed.
 */

export type FieldStatus = "ok" | "uncertain" | "illegible" | "not_detected";

export type ExtractedField = {
  key: string;
  label: string;
  value: string | null;
  normalized: string | null;
  status: FieldStatus;
  confidence: number | null; // 0..100 indicative token confidence
  source: "ocr" | "manual";
  note?: string;
};

const WANTED_LANGS = ["eng", "ori", "hin"] as const;

async function traineddataPresent(lang: string): Promise<boolean> {
  try {
    await readFile(path.join(ocrDataDir(), `${lang}.traineddata`));
    return true;
  } catch {
    return false;
  }
}

export type OcrAvailability = {
  configured: boolean;
  engine: string | null;
  languages: { lang: string; present: boolean }[];
  pdfRasterisation: boolean;
  notes: string[];
  setup: string[];
};

export async function checkOcrAvailability(): Promise<OcrAvailability> {
  const disabled = process.env.OCR_ENGINE === "off";
  const languages = [] as { lang: string; present: boolean }[];
  for (const l of WANTED_LANGS) languages.push({ lang: l, present: await traineddataPresent(l) });
  const present = languages.filter((l) => l.present).map((l) => l.lang);

  let engineOk = false;
  let engineVersion: string | null = null;
  if (!disabled) {
    try {
      const mod = await import("tesseract.js");
      engineOk = Boolean(mod?.createWorker);
      engineVersion = "tesseract.js (WASM port of Tesseract OCR)";
    } catch {
      engineOk = false;
    }
  }

  const notes: string[] = [];
  const setup: string[] = [];
  if (disabled) {
    notes.push("OCR engine disabled via OCR_ENGINE=off.");
    setup.push("Remove OCR_ENGINE=off to enable the local Tesseract.js engine.");
  }
  if (!engineOk && !disabled) setup.push("Install the engine: npm install tesseract.js");
  const missing = WANTED_LANGS.filter((l) => !present.includes(l));
  if (missing.length) {
    notes.push(`Missing language data: ${missing.join(", ")}. Those scripts/languages cannot be recognised.`);
    setup.push(
      `Download Traineddata files into ./ocr-data — e.g. curl -L -o ocr-data/<lang>.traineddata https://github.com/tesseract-ocr/tessdata_fast/raw/main/<lang>.traineddata`,
    );
  }
  notes.push("PDF rasterisation requires poppler/ghostscript, which is not available in this environment; PDF uploads are stored and viewable but page images cannot be auto-extracted. Upload JPG/PNG page scans for full OCR.");
  setup.push("To OCR PDFs: install poppler-utils + ghostscript, or convert pages to PNG/JPG before upload.");
  notes.push("Confidence values are indicative (token-level averages) and are not a measure of correctness.");
  notes.push("Historical Odia typeset and handwritten cursive are poorly handled by any general OCR; expect manual verification.");

  return {
    configured: Boolean(!disabled && engineOk && present.length > 0),
    engine: engineOk ? engineVersion : null,
    languages,
    pdfRasterisation: false,
    notes,
    setup,
  };
}

/** Image enhancement: grayscale, contrast stretch (normalise), light denoise. Original is never modified. */
export async function enhanceScan(input: Buffer): Promise<{ enhanced: Buffer; width: number; height: number }> {
  const sharp = (await import("sharp")).default;
  const base = sharp(input, { failOn: "none" }).rotate(); // honour EXIF orientation
  const meta = await base.metadata();
  const enhanced = await base
    .grayscale()
    .normalize() // global contrast stretch (approximates CLAHE-style expansion for scans)
    .median(3) // edge-preserving salt-and-pepper denoise
    .png()
    .toBuffer();
  return { enhanced, width: meta.width ?? 0, height: meta.height ?? 0 };
}

type OcrWord = { text: string; conf: number };

function parseTsv(tsv: string): OcrWord[] {
  const words: OcrWord[] = [];
  for (const line of tsv.split("\n")) {
    const cols = line.split("\t");
    if (cols.length < 12) continue;
    const level = Number(cols[0]);
    if (level !== 5) continue;
    const conf = Number(cols[10]);
    const text = cols[11]?.trim();
    if (!text) continue;
    words.push({ text, conf: Number.isFinite(conf) ? conf : -1 });
  }
  return words;
}

/** Approximate confidence for a matched phrase by scanning the word stream. */
function confidenceFor(matchText: string, words: OcrWord[], cursor: { i: number }): number | null {
  const tokens = matchText.split(/\s+/).filter(Boolean);
  if (!tokens.length) return null;
  const confs: number[] = [];
  let idx = cursor.i;
  for (const tok of tokens) {
    const norm = tok.replace(/[.,:;()#]/g, "").toLowerCase();
    let found = -1;
    for (let j = Math.max(0, idx - 6); j < Math.min(words.length, idx + 24); j++) {
      if (words[j].text.replace(/[.,:;()#]/g, "").toLowerCase() === norm) {
        found = j;
        break;
      }
    }
    if (found >= 0) {
      if (words[found].conf >= 0) confs.push(words[found].conf);
      idx = found + 1;
    }
  }
  cursor.i = idx;
  if (!confs.length) return null;
  return Math.round((confs.reduce((a, b) => a + b, 0) / confs.length) * 10) / 10;
}

const DISTRICTS = ["Khordha", "Khurda", "Puri", "Cuttack", "Ganjam", "Sambalpur", "Balasore", "Jagatsinghpur", "Kendrapara", "Nayagarh"];
const KNOWN_KISAM = ["Patita", "Sarad", "Rakhit", "Chhota", "Dhoba", "Paili", "Gochhar", "Jalasaya", "Bari", "Taila"];

export type OcrRunResult =
  | {
      ok: true;
      text: string;
      words: number;
      avgConfidence: number | null;
      imageQuality: "legible" | "degraded" | "poor";
      fields: ExtractedField[];
      languagesUsed: string[];
      enhanced: Buffer | null;
    }
  | { ok: false; message: string };

function statusFromConf(conf: number | null): FieldStatus {
  if (conf === null) return "uncertain";
  if (conf >= 68) return "ok";
  if (conf >= 42) return "uncertain";
  return "illegible";
}

export function extractFields(text: string, words: OcrWord[]): ExtractedField[] {
  const fields: ExtractedField[] = [];
  const cursor = { i: 0 };
  const push = (key: string, label: string, value: string | null, opts?: { conf?: number | null; normalized?: string | null; note?: string; forceStatus?: FieldStatus }) => {
    const conf = value ? (opts?.conf ?? confidenceFor(value, words, cursor)) : null;
    fields.push({
      key,
      label,
      value,
      normalized: opts?.normalized ?? null,
      status: opts?.forceStatus ?? (value ? statusFromConf(conf) : "not_detected"),
      confidence: value ? conf : null,
      source: "ocr",
      note: opts?.note,
    });
  };

  // Institution / deity
  const instMatch = text.match(/(Lingaraj\w*|Jagannath\w*|Mahaprabhu\S*\s*Jagannath\w*)/i);
  let inst: string | null = null;
  if (instMatch) {
    const raw = instMatch[0];
    inst = /lingaraj/i.test(raw) ? "Lingaraj Temple — Bhubaneswar" : "Shree Jagannath Temple — Puri";
  }
  push("institution", "Institution / Deity", inst, { conf: instMatch ? confidenceFor(instMatch[0], words, { i: 0 }) : null });

  // District — only report what we actually found; never default to a guess.
  let district: string | null = null;
  const dMatch = text.match(/district\s*[:\-.]?\s*([A-Za-z]+)/i);
  if (dMatch) {
    const raw = dMatch[1].toLowerCase();
    const hit = DISTRICTS.find((x) => x.toLowerCase() === raw) ?? (raw === "khurda" ? "Khordha" : undefined);
    district = hit ?? dMatch[1];
  }
  if (!district) {
    // Fallback: report a district only if its name literally appears in the text.
    district = DISTRICTS.find((d) => new RegExp(`\\b${d}\\b`, "i").test(text)) ?? null;
  }
  push("district", "District", district);

  // Tahasil / Mouza
  const tMatch = text.match(/taha?sil\s*[:\-.]?\s*([A-Z][A-Za-z .]{2,24}?)(?=\s{2,}|\n|,|;|mouza|khata|$)/i);
  push("tahasil", "Tahasil", tMatch ? tMatch[1].trim() : null);

  const mMatch = text.match(/mouza\s*[:\-.]?\s*([A-Z][A-Za-z .]{2,28}?)(?=\s{2,}|\n|,|;|khata|plot|$)/i);
  push("mouza", "Mouza / Village", mMatch ? mMatch[1].trim() : null);

  // Khata / Plot
  const kMatch = text.match(/khata\s*(?:no\.?|number)?\s*[:\-.]?\s*([0-9]{1,6}(?:\/[0-9]{1,5})?)/i);
  push("khataNo", "Khata No.", kMatch ? kMatch[1] : null);

  const pMatch = text.match(/plot\s*(?:no\.?|number)?\s*[:\-.]?\s*([0-9]{1,6}(?:\/[0-9]{1,5})?)/i);
  push("plotNo", "Plot No.", pMatch ? pMatch[1] : null);

  // Land classification
  const kisamMatch = text.match(/kisam\s*[:\-.]?\s*([A-Za-z .]{3,20}?)(?=\s{2,}|\n|,|;|area|plot|$)/i);
  let kisam = kisamMatch ? kisamMatch[1].trim() : null;
  if (kisam) {
    const known = KNOWN_KISAM.find((k) => kisam!.toLowerCase().includes(k.toLowerCase()));
    if (known) kisam = known;
  }
  push("landClass", "Land Classification (Kisam)", kisam ?? null);

  // Area — original units preserved; normalisation separate
  const acDec = text.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:acres?|acr\w*)\s*(?:&|and|,)?\s*([0-9]+(?:\.[0-9]+)?)\s*(?:decimals?|dec\w*)/i)
    ?? text.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:acres?)\b/i);
  const acOnlyDec = !acDec ? text.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:decimals?|dec\w*)/i) : null;
  const guntha = !acDec && !acOnlyDec ? text.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:gunthas?|gunta\w*)\s*(?:&|and|,)?\s*([0-9]+(?:\.[0-9]+)?\s*(?:mana\w*))?/i) : null;

  if (acDec) {
    const acres = parseFloat(acDec[1]);
    const dec = acDec[2] !== undefined ? parseFloat(acDec[2]) : null;
    const original = dec !== null ? `${acDec[1]} Acres ${acDec[2]} Decimals` : `${acDec[1]} Acres`;
    const normAcres = dec !== null ? acres + dec / 100 : acres;
    push("area", "Area (as recorded)", original, {
      normalized: `${normAcres.toFixed(4)} acres`,
      note: "Decimals converted at 1 acre = 100 decimals.",
    });
  } else if (acOnlyDec) {
    const dec = parseFloat(acOnlyDec[1]);
    push("area", "Area (as recorded)", `${acOnlyDec[1]} Decimals`, {
      normalized: `${(dec / 100).toFixed(4)} acres`,
      note: "Decimals converted at 1 acre = 100 decimals.",
    });
  } else if (guntha) {
    const g = parseFloat(guntha[1]);
    const mana = guntha[2] ? guntha[2].trim() : null;
    const norm = (g * 0.025).toFixed(4);
    push("area", "Area (as recorded)", mana ? `${acOnlyOr(guntha[1])} Guntha ${mana}` : `${guntha[1]} Guntha`, {
      normalized: `${norm} acres (approx.)`,
      forceStatus: mana ? "uncertain" : statusFromConf(null),
      note: "Guntha normalised at 1 guntha = 0.025 acre (regional conversion — verify). 'Mana' is not normalised; regional definitions vary.",
    });
  } else {
    push("area", "Area (as recorded)", null, { note: "No legible area statement found." });
  }

  // Date(s)
  const dateMatch =
    text.match(/\b([0-3]?\d[.\-/][01]?\d[.\-/](?:19|20)\d{2})\b/) ??
    text.match(/\b([0-3]?\d\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*,?\s+(?:19|20)\d{2})\b/i) ??
    text.match(/\b((?:19|20)\d{2})\b/);
  push("docDate", "Record Date / Year", dateMatch ? dateMatch[1] : null);

  // Reference number
  const refMatch = text.match(/(?:ref(?:erence)?|record|serial|sl\.?|ror|case)\s*(?:no\.?|number)?\s*[:\-.#]?\s*([A-Z0-9/\-]{4,20})/i);
  push("refNo", "Document Reference No.", refMatch ? refMatch[1] : null);

  return fields;
}

function acOnlyOr(v: string): string {
  return v;
}

export async function runOcrPipeline(input: Buffer, opts?: { enhance?: boolean }): Promise<OcrRunResult> {
  const availability = await checkOcrAvailability();
  if (!availability.configured) {
    return {
      ok: false,
      message:
        "OCR engine is not configured in this deployment. " +
        availability.setup.join(" "),
    };
  }
  const langsToUse = availability.languages.filter((l) => l.present).map((l) => l.lang);
  let enhanced: Buffer | null = null;
  let source = input;
  if (opts?.enhance !== false) {
    try {
      const res = await enhanceScan(input);
      enhanced = res.enhanced;
      source = res.enhanced;
    } catch (e) {
      // Enhancement is best-effort; OCR proceeds on the original.
      console.error("enhancement failed, OCR proceeds on original", e);
    }
  }

  let text = "";
  let words: OcrWord[] = [];
  try {
    const { createWorker } = await import("tesseract.js");
    const worker = await createWorker(langsToUse.join("+"), 1 as never, {
      langPath: ocrDataDir(),
      gzip: false,
      cacheMethod: "none",
    } as never);
    try {
      const res = (await worker.recognize(source, {}, { text: true, tsv: true } as never)) as never as {
        data: { text?: string; tsv?: string };
      };
      text = res.data.text ?? "";
      words = parseTsv(res.data.tsv ?? "");
    } finally {
      await worker.terminate();
    }
  } catch (e) {
    return {
      ok: false,
      message:
        "OCR engine failed to process this file: " +
        (e instanceof Error ? e.message : String(e)) +
        ". You can still enter fields manually in the verification workbench.",
    };
  }

  const confs = words.filter((w) => w.conf >= 0).map((w) => w.conf);
  const avgConfidence = confs.length ? Math.round((confs.reduce((a, b) => a + b, 0) / confs.length) * 10) / 10 : null;
  const imageQuality: "legible" | "degraded" | "poor" =
    avgConfidence === null ? "poor" : avgConfidence >= 70 ? "legible" : avgConfidence >= 45 ? "degraded" : "poor";

  if (words.length < 4) {
    const fields = extractFields("", []);
    // Everything stays 'not_detected'; honesty first.
    return {
      ok: true,
      text,
      words: words.length,
      avgConfidence,
      imageQuality: "poor",
      fields,
      languagesUsed: langsToUse,
      enhanced,
    };
  }

  const fields = extractFields(text, words);
  return { ok: true, text, words: words.length, avgConfidence, imageQuality, fields, languagesUsed: langsToUse, enhanced };
}
