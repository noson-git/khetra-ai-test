/**
 * Deterministic illustrative parcel generation.
 * These shapes are synthetic placeholder geometry for demonstration —
 * explicitly NOT survey boundaries, NOT legal parcel outlines.
 */

export type GeoJsonPolygon = {
  type: "Polygon";
  coordinates: number[][][]; // [ [ [lng,lat], ... ] ]
};

function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function makeRng(seed: number): () => number {
  let a = seed || 1;
  return () => {
    a ^= a << 13;
    a ^= a >>> 17;
    a ^= a << 5;
    a >>>= 0;
    return a / 4294967296;
  };
}

/** Generates a slightly irregular quadrilateral around a centroid. */
export function illustrativePolygon(lat: number, lng: number, sizeMeters: number, seed: string): GeoJsonPolygon {
  const rng = makeRng(hashString(seed));
  const dLatBase = sizeMeters / 111320;
  const dLngBase = sizeMeters / (111320 * Math.cos((lat * Math.PI) / 180));
  const corners: Array<[number, number]> = [];
  // four corners with jitter, ordered
  const base: Array<[number, number]> = [
    [-1, -1],
    [1, -1],
    [1, 1],
    [-1, 1],
  ];
  const angle = (rng() * Math.PI) / 6 - Math.PI / 12; // small rotation
  const cosA = Math.cos(angle);
  const sinA = Math.sin(angle);
  for (const [sx, sy] of base) {
    const jx = 0.72 + rng() * 0.5;
    const jy = 0.72 + rng() * 0.5;
    let x = sx * jx * (dLngBase / 2);
    let y = sy * jy * (dLatBase / 2);
    const rx = x * cosA - y * sinA;
    const ry = x * sinA + y * cosA;
    x = rx;
    y = ry;
    corners.push([lng + x, lat + y]);
  }
  corners.push(corners[0]);
  return { type: "Polygon", coordinates: [corners] };
}

export function polygonCentroid(geom: GeoJsonPolygon): { lat: number; lng: number } | null {
  const ring = geom?.coordinates?.[0];
  if (!ring || ring.length === 0) return null;
  let sx = 0;
  let sy = 0;
  const n = ring.length - 1 > 0 ? ring.length - 1 : ring.length;
  for (let i = 0; i < n; i++) {
    sx += ring[i][0];
    sy += ring[i][1];
  }
  return { lng: sx / n, lat: sy / n };
}
