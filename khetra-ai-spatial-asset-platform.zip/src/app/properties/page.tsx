"use client";

import { useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import {
  Archive,
  ExternalLink,
  FileImage,
  FileText,
  LayoutGrid,
  List,
  Map as MapIcon,
  RotateCcw,
  ScanSearch,
  Search,
  Table as TableIcon,
  TriangleAlert,
} from "lucide-react";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import DemoNotice from "@/components/demo-notice";
import PropertyDrawer, { type PropertyRecord } from "@/components/property-drawer";
import { useInstitution } from "@/components/institution-context";
import { DemoTag, EmptyState, Spinner, StatusChip, formatDate } from "@/components/ui";
import { DOC_TYPES } from "@/lib/constants";

const GisMap = dynamic(() => import("@/components/gis-map"), { ssr: false });

type Tab = "map" | "list" | "scans" | "digitised";

type PublicDoc = {
  id: string;
  institutionId: string;
  propertyId: string | null;
  title: string;
  docType: string;
  refNo: string | null;
  docDate: string | null;
  status: string;
  pageKind: string;
  extracted: { key: string; label: string; value: string | null; status: string; confidence: number | null }[] | null;
  ocr: { status: string | null; avgConfidence: number | null; engine?: string | null } | null;
  hasSensitiveRedactions?: boolean;
};

export default function PropertiesPage() {
  const { institution, institutionId } = useInstitution();
  const [tab, setTab] = useState<Tab>("list");
  const [properties, setProperties] = useState<PropertyRecord[]>([]);
  const [docs, setDocs] = useState<PublicDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [docsLoading, setDocsLoading] = useState(true);

  const [q, setQ] = useState("");
  const [district, setDistrict] = useState("");
  const [tahasil, setTahasil] = useState("");
  const [mouza, setMouza] = useState("");
  const [assetType, setAssetType] = useState("");
  const [yearFrom, setYearFrom] = useState("");
  const [yearTo, setYearTo] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [focus, setFocus] = useState<{ lat: number; lng: number; zoom?: number } | null>(null);

  useEffect(() => {
    if (!institutionId) return;
    setLoading(true);
    setSelectedId(null);
    fetch(`/api/properties?institution=${institutionId}`)
      .then((r) => r.json())
      .then((d) => setProperties(d?.ok ? d.properties : []))
      .catch(() => setProperties([]))
      .finally(() => setLoading(false));
    setDocsLoading(true);
    fetch(`/api/documents?institution=${institutionId}`)
      .then((r) => r.json())
      .then((d) => setDocs(d?.ok ? d.documents : []))
      .catch(() => setDocs([]))
      .finally(() => setDocsLoading(false));
  }, [institutionId]);

  const districts = useMemo(() => [...new Set(properties.map((p) => p.district))].sort(), [properties]);
  const tahasils = useMemo(
    () => [...new Set(properties.filter((p) => !district || p.district === district).map((p) => p.tahasil))].sort(),
    [properties, district],
  );
  const mouzas = useMemo(
    () =>
      [...new Set(properties.filter((p) => (!district || p.district === district) && (!tahasil || p.tahasil === tahasil)).map((p) => p.mouza))].sort(),
    [properties, district, tahasil],
  );

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return properties.filter((p) => {
      if (district && p.district !== district) return false;
      if (tahasil && p.tahasil !== tahasil) return false;
      if (mouza && p.mouza !== mouza) return false;
      if (assetType && p.assetType !== assetType) return false;
      const yr = p.docDate ? Number(String(p.docDate).slice(0, 4)) : null;
      if (yearFrom && (!yr || yr < Number(yearFrom))) return false;
      if (yearTo && (!yr || yr > Number(yearTo))) return false;
      if (needle) {
        const hay = [p.title, p.assetCode, p.khataNo, p.plotNo, p.mouza, p.docRef, p.landClass].filter(Boolean).join(" ").toLowerCase();
        if (!hay.includes(needle)) return false;
      }
      return true;
    });
  }, [properties, district, tahasil, mouza, assetType, yearFrom, yearTo, q]);

  const selected = properties.find((p) => p.id === selectedId) ?? null;

  const openOnMap = (p: PropertyRecord) => {
    setTab("map");
    setSelectedId(p.id);
    if (p.lat != null && p.lng != null) setFocus({ lat: p.lat, lng: p.lng, zoom: 16 });
  };

  const resetFilters = () => {
    setQ(""); setDistrict(""); setTahasil(""); setMouza(""); setAssetType(""); setYearFrom(""); setYearTo("");
  };

  const docTypeLabel = (id: string) => DOC_TYPES.find((d) => d.id === id)?.label ?? id;

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1 mx-auto w-full max-w-[1500px] px-4 md:px-6 py-8">
        <div className="flex flex-wrap items-end justify-between gap-3 mb-2">
          <div>
            <p className="eyebrow text-[var(--color-saffron-2)] mb-1.5">Public Portal</p>
            <h1 className="font-display text-3xl md:text-5xl leading-tight">
              Temple Lands <span className="italic text-[var(--color-saffron-2)]">&amp;</span> Properties
            </h1>
            <p className="text-sm text-[rgba(244,236,216,0.55)] mt-2 max-w-2xl">
              Demonstration asset register for <strong className="text-[var(--color-paper)]">{institution?.name ?? "…"}</strong>. Only
              approved &amp; published records appear here — drafts and private documents never leave the staff console.
            </p>
          </div>
          <DemoTag />
        </div>

        <div className="my-5"><DemoNotice compact /></div>

        {/* tabs */}
        <div className="flex flex-wrap gap-1.5 rounded-2xl border hairline bg-[rgba(244,236,216,0.03)] p-1.5 w-fit mb-5">
          {(
            [
              { id: "map", label: "Map View", icon: MapIcon },
              { id: "list", label: "Property List", icon: List },
              { id: "scans", label: "Historical / Scanned Records", icon: FileImage },
              { id: "digitised", label: "Digitised Records", icon: TableIcon },
            ] as { id: Tab; label: string; icon: typeof MapIcon }[]
          ).map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-[13px] font-semibold transition-colors ${
                tab === t.id ? "bg-[rgba(232,137,47,0.2)] text-[var(--color-saffron-2)]" : "text-[rgba(244,236,216,0.65)] hover:bg-[rgba(244,236,216,0.06)]"
              }`}
            >
              <t.icon size={14} /> {t.label}
            </button>
          ))}
        </div>

        {/* filters */}
        <div className="card p-3.5 flex flex-wrap items-end gap-3 mb-5">
          <div className="grow min-w-[180px] max-w-xs">
            <label className="label">Search</label>
            <div className="relative">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[rgba(244,236,216,0.35)]" />
              <input className="input !pl-8" placeholder="Khata / plot / mouza / record ID…" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
          </div>
          <Sel label="District" value={district} onChange={(v) => { setDistrict(v); setTahasil(""); setMouza(""); }} options={districts} all="All districts" />
          <Sel label="Tahasil" value={tahasil} onChange={(v) => { setTahasil(v); setMouza(""); }} options={tahasils} all="All tahasils" />
          <Sel label="Mouza" value={mouza} onChange={setMouza} options={mouzas} all="All mouzas" />
          <Sel label="Asset type" value={assetType} onChange={setAssetType} options={["land", "building", "other"]} all="All types" />
          <div>
            <label className="label">Doc year from</label>
            <input className="input w-24" inputMode="numeric" placeholder="1985" value={yearFrom} onChange={(e) => setYearFrom(e.target.value.replace(/[^0-9]/g, "").slice(0, 4))} />
          </div>
          <div>
            <label className="label">to</label>
            <input className="input w-24" inputMode="numeric" placeholder="2026" value={yearTo} onChange={(e) => setYearTo(e.target.value.replace(/[^0-9]/g, "").slice(0, 4))} />
          </div>
          <button className="btn btn-ghost btn-sm mb-0.5" onClick={resetFilters}><RotateCcw size={12} /> Reset</button>
        </div>

        {/* views */}
        {tab === "map" && (
          <div className="relative">
            {loading && <div className="absolute inset-0 z-[550] rounded-2xl bg-[rgba(19,16,11,0.5)] flex items-center justify-center"><Spinner /></div>}
            <GisMap properties={filtered} institution={institution} selectedId={selectedId} onSelect={setSelectedId} focus={focus} heightClass="h-[68vh]" />
            <p className="mt-2 text-[11px] text-[rgba(244,236,216,0.45)]">Click any illustrative parcel to open its record.</p>
          </div>
        )}

        {tab === "list" && (
          <div>
            {loading ? (
              <div className="flex justify-center py-16"><Spinner /></div>
            ) : filtered.length === 0 ? (
              <EmptyState icon={Archive} title="No published records match" message="Adjust filters — or records may still be under staff review." />
            ) : (
              <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
                {filtered.map((p) => (
                  <button key={p.id} onClick={() => setSelectedId(p.id)} className="card p-5 text-left hover:border-[rgba(232,137,47,0.45)] transition-colors group">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="chip">{p.assetCode}</span>
                      <span className="chip">{p.assetType}</span>
                      {p.reportedConcern && (
                        <span className="chip !border-[rgba(217,93,57,0.55)] !text-[#f2b09d]"><TriangleAlert size={10} /> concern</span>
                      )}
                    </div>
                    <p className="font-display text-lg leading-snug group-hover:text-[var(--color-saffron-2)] transition-colors">{p.title}</p>
                    <p className="text-[12px] text-[rgba(244,236,216,0.55)] mt-1.5">
                      {p.mouza} · {p.tahasil} · {p.district}
                    </p>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 mt-3 text-[11.5px] text-[rgba(244,236,216,0.5)]">
                      {p.khataNo && <span>Khata <b className="text-[var(--color-paper)]">{p.khataNo}</b></span>}
                      {p.plotNo && <span>Plot <b className="text-[var(--color-paper)]">{p.plotNo}</b></span>}
                      {p.areaOriginal && <span>{p.areaOriginal}</span>}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "scans" && (
          <div>
            <p className="text-[12px] text-[rgba(244,236,216,0.5)] mb-4 max-w-2xl">
              Preserved historical documents linked to published records. Personal details are redacted before public
              display; documents appear here only after staff verification and publication.
            </p>
            {docsLoading ? (
              <div className="flex justify-center py-16"><Spinner /></div>
            ) : docs.length === 0 ? (
              <EmptyState icon={FileImage} title="No published scans yet" message="Documents under review or in draft remain private to staff." />
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {docs.map((d) => {
                  const linked = properties.find((p) => p.id === d.propertyId);
                  return (
                    <div key={d.id} className="card overflow-hidden">
                      {d.pageKind === "image" ? (
                        <a href={`/api/documents/${d.id}/file`} target="_blank" rel="noreferrer" className="block h-44 overflow-hidden border-b hairline">
                          <img src={`/api/documents/${d.id}/file`} alt={d.title} className="w-full h-full object-cover object-top opacity-90 hover:opacity-100 hover:scale-[1.02] transition-all duration-500" loading="lazy" />
                        </a>
                      ) : (
                        <div className="h-24 border-b hairline flex items-center justify-center text-[rgba(244,236,216,0.4)] text-xs">PDF document</div>
                      )}
                      <div className="p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="font-semibold text-[15px] leading-snug flex items-center gap-1.5">
                              <FileText size={14} className="text-[var(--color-saffron-2)] shrink-0" /> {d.title}
                            </p>
                            <p className="text-[11.5px] text-[rgba(244,236,216,0.5)] mt-1">
                              {docTypeLabel(d.docType)} {d.refNo ? `· Ref ${d.refNo}` : ""} {d.docDate ? `· ${formatDate(d.docDate)}` : ""}
                            </p>
                          </div>
                          <a href={`/api/documents/${d.id}/file`} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm shrink-0">
                            <ExternalLink size={12} /> Open
                          </a>
                        </div>
                        {d.hasSensitiveRedactions && (
                          <p className="text-[10.5px] text-[var(--color-gold)] mt-2">Personal details & sensitive notes redacted for public view</p>
                        )}
                        {linked ? (
                          <button onClick={() => setSelectedId(linked.id)} className="mt-3 text-[11.5px] text-[var(--color-saffron-2)] underline underline-offset-2">
                            Linked digitised record: {linked.assetCode} — {linked.title}
                          </button>
                        ) : (
                          <p className="mt-3 text-[11.5px] text-[rgba(244,236,216,0.45)]">Not linked to a public property record.</p>
                        )}
                        {d.extracted && d.extracted.length > 0 && (
                          <div className="mt-3 flex flex-wrap gap-1.5">
                            {d.extracted.filter((f) => f.value && ["khataNo", "plotNo", "mouza", "area", "docDate"].includes(f.key)).slice(0, 5).map((f) => (
                              <span key={f.key} className={`chip ${f.status === "uncertain" || f.status === "illegible" ? "!border-[rgba(232,137,47,0.5)] !text-[var(--color-saffron-2)]" : ""}`}>
                                {f.label}: {f.value}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {tab === "digitised" && (
          <div className="table-shell overflow-x-auto">
            <table className="min-w-[980px]">
              <thead>
                <tr>
                  <th>Record / Asset ID</th>
                  <th>Asset</th>
                  <th>Location (District · Tahasil · Mouza)</th>
                  <th>Khata / Plot</th>
                  <th>Kisam</th>
                  <th>Area (original unit)</th>
                  <th>Doc date</th>
                  <th>Source ref</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p) => (
                  <tr key={p.id} className="cursor-pointer" onClick={() => setSelectedId(p.id)}>
                    <td>
                      <span className="font-mono text-[11px] text-[var(--color-saffron-2)]">{p.assetCode}</span>
                      <br />
                      <span className="text-[12px] font-semibold">{p.title}</span>
                    </td>
                    <td className="capitalize">{p.assetType}</td>
                    <td className="text-[12px]">{p.district} · {p.tahasil} · {p.mouza}</td>
                    <td className="font-mono text-[11.5px]">{p.khataNo ?? "—"} / {p.plotNo ?? "—"}</td>
                    <td>{p.landClass ?? "—"}</td>
                    <td className="text-[12px]">{p.areaOriginal ?? "—"}{p.areaAcres != null ? <><br /><span className="text-[10.5px] text-[rgba(244,236,216,0.45)]">≈ {Number(p.areaAcres).toFixed(4)} ac</span></> : null}</td>
                    <td className="whitespace-nowrap">{formatDate(p.docDate)}</td>
                    <td className="font-mono text-[11px]">{p.docRef ?? "—"}</td>
                    <td><StatusChip status={p.status} /></td>
                  </tr>
                ))}
                {!filtered.length && (
                  <tr><td colSpan={9}><EmptyState icon={LayoutGrid} title="No digitised records" message="Nothing published matches the current filters." /></td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        <div className="mt-8 grid md:grid-cols-2 gap-4">
          <div className="rounded-2xl border hairline p-5 bg-[rgba(244,236,216,0.02)]">
            <p className="font-display text-lg mb-2 flex items-center gap-2"><ScanSearch size={16} className="text-[var(--color-saffron-2)]" /> Reading this register</p>
            <ul className="text-[12.5px] text-[rgba(244,236,216,0.6)] leading-relaxed space-y-1.5 list-disc pl-4">
              <li>Every record is fictional demonstration data with illustrative parcel geometry.</li>
              <li>Areas keep their original units; normalised acreage is indicative, not authoritative.</li>
              <li>“Reported concern” flags demonstrate a workflow — nothing is legally determined here.</li>
            </ul>
          </div>
          <div className="rounded-2xl border hairline p-5 bg-[rgba(244,236,216,0.02)]">
            <p className="font-display text-lg mb-2 flex items-center gap-2"><FileText size={16} className="text-[var(--color-saffron-2)]" /> Provenance</p>
            <p className="text-[12.5px] text-[rgba(244,236,216,0.6)] leading-relaxed">
              Scans and digitised entries share one lineage: each public document links to its record and vice-versa.
              Drafts, unreviewed OCR output and staff-only notes remain inside the secured console.
            </p>
          </div>
        </div>
      </main>
      <SiteFooter />
      <PropertyDrawer property={selected} onClose={() => setSelectedId(null)} onViewOnMap={openOnMap} />
    </div>
  );
}

function Sel({ label, value, onChange, options, all }: { label: string; value: string; onChange: (v: string) => void; options: string[]; all: string }) {
  return (
    <div>
      <label className="label">{label}</label>
      <select className="select" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">{all}</option>
        {options.map((o) => (
          <option key={o} value={o} className="capitalize">{o}</option>
        ))}
      </select>
    </div>
  );
}
