"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Landmark, LogIn, ShieldCheck, UserRound, KeyRound } from "lucide-react";
import { Spinner } from "@/components/ui";
import { ROLE_LABELS } from "@/lib/constants";

const DEMO_ACCOUNTS = [
  { username: "admin", password: "admin123", role: "admin" as const, blurb: "Full control: records, publication, hundi ledger, audit, diagnostics." },
  { username: "reviewer", password: "review123", role: "reviewer" as const, blurb: "Verification cell: review records & OCR, approve for publication." },
  { username: "operator", password: "operator123", role: "operator" as const, blurb: "Intake desk: upload scans, run OCR, create draft records." },
];

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setBusy(true);
    setError(null);
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    }).catch(() => null);
    setBusy(false);
    if (!res) return setError("Network error — please retry.");
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.ok) return setError(data?.message ?? "Sign-in failed.");
    router.push(params.get("next") || "/admin");
    router.refresh();
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-16 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(700px_380px_at_75%_15%,rgba(232,137,47,0.12),transparent_60%)]" />
      <div className="relative w-full max-w-md">
        <Link href="/" className="flex items-center justify-center gap-2.5 mb-8">
          <span className="font-odia text-2xl text-[var(--color-saffron-2)]">କ୍ଷେତ୍ର</span>
          <span className="font-display text-2xl">KhetraAI</span>
        </Link>
        <div className="card p-7">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-10 h-10 rounded-xl border hairline flex items-center justify-center text-[var(--color-saffron-2)]"><ShieldCheck size={18} /></span>
            <div>
              <h1 className="font-display text-xl leading-tight">Staff Console Sign-in</h1>
              <p className="text-[11.5px] text-[rgba(244,236,216,0.5)]">Role-based access, enforced on the server</p>
            </div>
          </div>
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="label">Username</label>
              <div className="relative">
                <UserRound size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[rgba(244,236,216,0.35)]" />
                <input className="input !pl-8" autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} />
              </div>
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <KeyRound size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[rgba(244,236,216,0.35)]" />
                <input type="password" className="input !pl-8" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
            </div>
            {error && <p className="text-[12.5px] text-[#f2b09d] border border-[rgba(217,93,57,0.45)] bg-[rgba(217,93,57,0.1)] rounded-lg px-3 py-2">{error}</p>}
            <button className="btn btn-primary w-full" disabled={busy}>
              {busy ? <Spinner size={14} /> : <LogIn size={14} />} Sign in
            </button>
          </form>
        </div>
        <div className="card-paper mt-4 p-5 text-[var(--color-ink)]">
          <p className="text-[11px] uppercase tracking-[0.18em] font-bold text-[var(--color-clay)] mb-3 flex items-center gap-1.5">
            <Landmark size={12} /> Demonstration accounts
          </p>
          <div className="space-y-3">
            {DEMO_ACCOUNTS.map((a) => (
              <button
                key={a.username}
                onClick={() => { setUsername(a.username); setPassword(a.password); }}
                className="w-full text-left rounded-lg border border-[rgba(19,16,11,0.14)] px-3 py-2.5 hover:bg-[rgba(255,255,255,0.5)] transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[13px] font-bold">{ROLE_LABELS[a.role]}</span>
                  <span className="font-mono text-[11px] text-[rgba(19,16,11,0.6)]">{a.username} / {a.password}</span>
                </div>
                <p className="text-[11px] text-[rgba(19,16,11,0.55)] mt-0.5">{a.blurb}</p>
              </button>
            ))}
          </div>
          <p className="text-[10.5px] text-[rgba(19,16,11,0.5)] mt-3 leading-relaxed">
            Demo credentials for evaluation only. In a production deployment these would be issued per-staff with
            rotation, and sessions would be TLS-protected.
          </p>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
