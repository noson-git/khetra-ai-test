import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import AdminShell from "@/components/admin/admin-shell";

export const dynamic = "force-dynamic";

export const metadata = { title: "Staff Console" };

export default async function AdminPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/admin");
  return <AdminShell user={user} />;
}
