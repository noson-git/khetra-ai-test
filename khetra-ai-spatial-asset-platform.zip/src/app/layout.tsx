import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, Inter, Noto_Sans_Oriya } from "next/font/google";
import { InstitutionProvider } from "@/components/institution-context";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  axes: ["opsz"],
});

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

const odia = Noto_Sans_Oriya({ subsets: ["oriya"], variable: "--font-odia-var" });

export const metadata: Metadata = {
  title: {
    default: "KhetraAI — GIS & Spatial Asset Intelligence for Religious Endowments",
    template: "%s · KhetraAI",
  },
  description:
    "Demonstration platform showing how religious institutions could digitise, map, preserve and manage endowment assets. Sample data only — not a legal land-records portal.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${inter.variable} ${odia.variable}`}>
      <body className="grain bg-radial-dusk min-h-screen antialiased">
        <InstitutionProvider>{children}</InstitutionProvider>
      </body>
    </html>
  );
}
