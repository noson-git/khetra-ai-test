import { db } from "@/db";
import { documents, hundiEntries, institutions, properties, sessions, users } from "@/db/schema";
import { sql } from "drizzle-orm";
import { requireRole } from "@/lib/auth";
import { checkOcrAvailability } from "@/lib/ocr";
import { storageRoot } from "@/lib/storage";

export const dynamic = "force-dynamic";

/** GET /api/system/status — Administrator diagnostics. */
export async function GET() {
  const { user, response } = await requireRole(["admin"]);
  if (response) return response;
  void user;
  const availability = await checkOcrAvailability();
  const count = async (t: never) => {
    const r = await db.select({ c: sql<number>`count(*)::int` }).from(t as never);
    return (r as unknown as { c: number }[])[0]?.c ?? 0;
  };
  const counts = {
    users: await count(users as never),
    institutions: await count(institutions as never),
    properties: await count(properties as never),
    documents: await count(documents as never),
    hundiEntries: await count(hundiEntries as never),
    sessions: await count(sessions as never),
  };
  return Response.json({
    ok: true,
    database: { connected: true, engine: "PostgreSQL (Drizzle ORM)", counts },
    ocr: availability,
    storage: { root: storageRoot(), note: "Unpublished documents are served only to authenticated staff." },
    environment: {
      nodeEnv: process.env.NODE_ENV,
      databaseConfigured: Boolean(process.env.DATABASE_URL),
      ocrEngineOverride: process.env.OCR_ENGINE ?? "auto",
      browserApiKeys: "None required — basemaps use keyless public endpoints (Esri World Imagery, OSM).",
    },
    demo: true,
  });
}
