import { db } from "@/db";
import { documents, documentVersions } from "@/db/schema";
import { and, desc, eq, type SQL } from "drizzle-orm";
import { badRequest, getSessionUser, requireRole } from "@/lib/auth";
import { serializeDocument } from "@/lib/serialize";
import { logAudit } from "@/lib/audit";
import { saveUpload, validateUpload } from "@/lib/storage";

export const dynamic = "force-dynamic";

/** GET /api/documents — public sees published only; staff (scope=staff) sees all. */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const user = await getSessionUser();
  const scope = url.searchParams.get("scope") === "staff" && user ? "staff" : "public";
  const conds: SQL[] = [];
  const institution = url.searchParams.get("institution");
  if (institution) conds.push(eq(documents.institutionId, institution));
  const propertyId = url.searchParams.get("propertyId");
  if (propertyId) conds.push(eq(documents.propertyId, propertyId));
  if (scope === "public") conds.push(eq(documents.status, "published"));
  else {
    const status = url.searchParams.get("status");
    if (status) conds.push(eq(documents.status, status as never));
  }
  const rows = await db
    .select()
    .from(documents)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(documents.createdAt))
    .limit(500);
  return Response.json({ ok: true, scope, documents: rows.map((d) => serializeDocument(d as unknown as Record<string, unknown>, scope)) });
}

/** POST /api/documents — multipart upload (staff). Original preserved, versioned. */
export async function POST(req: Request) {
  const { user, response } = await requireRole(["admin", "reviewer", "operator"]);
  if (response) return response;

  const form = await req.formData().catch(() => null);
  if (!form) return badRequest("Expected multipart/form-data");
  const file = form.get("file");
  if (!(file instanceof File)) return badRequest("No file supplied (field name: file)");
  const mime = file.type || "application/octet-stream";
  const buffer = Buffer.from(await file.arrayBuffer());
  const validation = validateUpload(mime, buffer.length);
  if (!validation.ok) return badRequest(validation.message);

  const title = String(form.get("title") ?? "").trim() || file.name;
  const institutionId = String(form.get("institutionId") ?? "").trim();
  if (!institutionId) return badRequest("institutionId is required");
  const docType = String(form.get("docType") ?? "other");
  const refNo = form.get("refNo") ? String(form.get("refNo")) : null;
  const propertyId = form.get("propertyId") ? String(form.get("propertyId")) : null;
  const docDate = form.get("docDate") ? String(form.get("docDate")) : null;
  const sensitiveNote = form.get("sensitiveNote") ? String(form.get("sensitiveNote")) : null;

  const [row] = await db
    .insert(documents)
    .values({
      institutionId,
      propertyId,
      title,
      docType,
      refNo,
      docDate,
      status: "draft",
      mime,
      sizeBytes: buffer.length,
      originalPath: "pending",
      pageKind: validation.ext === "pdf" ? "pdf" : "image",
      sensitiveNote,
      version: 1,
      createdBy: user!.id,
      ocr: {
        status: "pending",
        engine: null,
        languages: null,
        processedAt: null,
        avgConfidence: null,
        words: null,
        message:
          validation.ext === "pdf"
            ? "PDF stored. Page-image extraction requires poppler/ghostscript (unavailable here) — OCR cannot run on this PDF. Convert pages to PNG/JPG or enter fields manually."
            : "Awaiting OCR run.",
        rawText: null,
      },
    } as never)
    .returning();

  const rel = await saveUpload(row.id, buffer, validation.ext);
  const [updated] = await db.update(documents).set({ originalPath: rel } as never).where(eq(documents.id, row.id)).returning();
  await db.insert(documentVersions).values({
    documentId: row.id,
    version: 1,
    note: "Original upload",
    path: rel,
    createdBy: user!.id,
  } as never);
  await logAudit({
    user,
    action: "upload",
    entity: "document",
    entityId: row.id,
    summary: `Uploaded document "${title}" (${Math.round(buffer.length / 1024)} KB ${validation.ext.toUpperCase()})`,
  });
  return Response.json({ ok: true, document: serializeDocument(updated as unknown as Record<string, unknown>, "staff") }, { status: 201 });
}
