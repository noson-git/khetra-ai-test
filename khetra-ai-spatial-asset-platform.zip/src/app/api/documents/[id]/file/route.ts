import { db } from "@/db";
import { documents } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSessionUser, notFound } from "@/lib/auth";
import { resolveStorage } from "@/lib/storage";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { Readable } from "node:stream";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const CONTENT_TYPES: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  pdf: "application/pdf",
};

/**
 * Serves stored scans. Unpublished documents live in private storage and are
 * only reachable by authenticated staff — no path guessing, no public URLs.
 */
export async function GET(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const url = new URL(req.url);
  const kind = url.searchParams.get("kind") === "enhanced" ? "enhanced" : "original";
  const [row] = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  if (!row) return notFound("Document not found");

  const user = await getSessionUser();
  if (!user && row.status !== "published") {
    return notFound("Document not found"); // no existence leak for private files
  }

  const rel = kind === "enhanced" ? (row.enhancedPath ?? row.originalPath) : row.originalPath;
  const abs = resolveStorage(rel ?? "");
  if (!abs) return notFound("File not available");
  let info;
  try {
    info = await stat(abs);
  } catch {
    return notFound("File not available on disk");
  }
  const ext = (abs.split(".").pop() ?? "").toLowerCase();
  const type = CONTENT_TYPES[ext] ?? "application/octet-stream";
  const stream = Readable.toWeb(createReadStream(abs)) as unknown as ReadableStream;
  return new Response(stream, {
    headers: {
      "Content-Type": type,
      "Content-Length": String(info.size),
      "Content-Disposition": `inline; filename="${row.title.replace(/[^\w .-]/g, "_").slice(0, 80)}.${ext}"`,
      "Cache-Control": user ? "private, no-store" : "public, max-age=300",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
