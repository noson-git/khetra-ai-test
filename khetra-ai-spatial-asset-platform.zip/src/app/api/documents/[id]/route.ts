import { db } from "@/db";
import { documents, documentVersions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { badRequest, getSessionUser, notFound, requireRole } from "@/lib/auth";
import { serializeDocument } from "@/lib/serialize";
import { logAudit } from "@/lib/audit";
import { TRANSITIONS, type Role, type Status } from "@/lib/constants";
import { saveVersion, validateUpload } from "@/lib/storage";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

/** GET one document (public: published only; staff: any). */
export async function GET(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const [row] = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  if (!row) return notFound("Document not found");
  const user = await getSessionUser();
  const scope = user ? "staff" : "public";
  if (scope === "public" && row.status !== "published") return notFound("Document not found");
  const versions = scope === "staff" ? await db.select().from(documentVersions).where(eq(documentVersions.documentId, id)) : undefined;
  return Response.json({
    ok: true,
    scope,
    document: serializeDocument(row as unknown as Record<string, unknown>, scope),
    ...(versions ? { versions } : {}),
  });
}

/**
 * PATCH — staff actions:
 *  - extracted: corrected field array (verification workbench). Original scan untouched.
 *  - linkPropertyId: link/unlink cadastral record
 *  - meta edits (title, docType, refNo, docDate, sensitiveNote)
 *  - status transitions per role matrix
 */
export async function PATCH(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const { user, response } = await requireRole(["admin", "reviewer", "operator"]);
  if (response) return response;
  const [before] = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  if (!before) return notFound("Document not found");

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return badRequest("Invalid JSON body");
  }

  const changes: Record<string, unknown> = {};
  const summary: string[] = [];

  if (Array.isArray(body.extracted)) {
    if (user!.role === "operator" && !["draft", "needs_review"].includes(before.status)) {
      return badRequest("Data Entry Operators may only correct extractions in Draft or Needs Review state.");
    }
    const cleaned = (body.extracted as Array<Record<string, unknown>>).slice(0, 40).map((f) => ({
      key: String(f.key ?? "").slice(0, 40),
      label: String(f.label ?? "").slice(0, 80),
      value: f.value === null || f.value === undefined ? null : String(f.value).slice(0, 300),
      normalized: f.normalized === null || f.normalized === undefined ? null : String(f.normalized).slice(0, 300),
      status: ["ok", "uncertain", "illegible", "not_detected"].includes(String(f.status)) ? String(f.status) : "ok",
      confidence: typeof f.confidence === "number" ? f.confidence : null,
      source: f.source === "ocr" ? "ocr" : "manual",
      note: f.note ? String(f.note).slice(0, 300) : undefined,
    }));
    changes.extracted = cleaned;
    summary.push(`corrected ${cleaned.length} extracted fields`);
  }

  if ("linkPropertyId" in body) {
    changes.propertyId = body.linkPropertyId ? String(body.linkPropertyId) : null;
    summary.push(changes.propertyId ? "linked to property record" : "unlinked from property record");
  }

  for (const k of ["title", "docType", "refNo", "docDate", "sensitiveNote"] as const) {
    if (k in body) {
      changes[k] = body[k] ? String(body[k]) : null;
      summary.push(`updated ${k}`);
    }
  }

  if (body.status && body.status !== before.status) {
    const target = String(body.status) as Status;
    const allowed = TRANSITIONS[user!.role as Role][before.status as Status] ?? [];
    if (!allowed.includes(target)) {
      return Response.json(
        { ok: false, error: "forbidden", message: `${user!.role} cannot move a document from ${before.status} to ${target}.` },
        { status: 403 },
      );
    }
    changes.status = target;
    summary.push(`status ${before.status} → ${target}`);
  }

  if (!Object.keys(changes).length) return badRequest("No changes supplied");
  changes.updatedAt = new Date();
  const [after] = await db.update(documents).set(changes as never).where(eq(documents.id, id)).returning();
  await logAudit({
    user,
    action: changes.status ? "transition" : "update",
    entity: "document",
    entityId: id,
    summary: `Document "${before.title}": ${summary.join("; ")}`,
  });
  return Response.json({ ok: true, document: serializeDocument(after as unknown as Record<string, unknown>, "staff") });
}

/** PUT — replace the file (new version). Old version preserved. */
export async function PUT(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const { user, response } = await requireRole(["admin", "reviewer"]);
  if (response) return response;
  const [before] = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  if (!before) return notFound("Document not found");
  const form = await req.formData().catch(() => null);
  if (!form) return badRequest("Expected multipart/form-data");
  const file = form.get("file");
  if (!(file instanceof File)) return badRequest("No file supplied");
  const buffer = Buffer.from(await file.arrayBuffer());
  const validation = validateUpload(file.type, buffer.length);
  if (!validation.ok) return badRequest(validation.message);

  const nextVersion = (before.version ?? 1) + 1;
  const rel = await saveVersion(id, nextVersion, buffer, validation.ext);
  const [after] = await db
    .update(documents)
    .set({
      originalPath: rel,
      mime: file.type,
      sizeBytes: buffer.length,
      version: nextVersion,
      pageKind: validation.ext === "pdf" ? "pdf" : "image",
      enhancedPath: null,
      status: "draft",
      ocr: { status: "pending", message: "File replaced — OCR required for the new version." },
      updatedAt: new Date(),
    } as never)
    .where(eq(documents.id, id))
    .returning();
  await db.insert(documentVersions).values({
    documentId: id,
    version: nextVersion,
    note: String(form.get("note") ?? "Replacement upload"),
    path: rel,
    createdBy: user!.id,
  } as never);
  await logAudit({ user, action: "version", entity: "document", entityId: id, summary: `Replaced file for "${before.title}" (v${nextVersion}); prior version retained` });
  return Response.json({ ok: true, document: serializeDocument(after as unknown as Record<string, unknown>, "staff") });
}
