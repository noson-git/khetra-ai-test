import { db } from "@/db";
import { documents } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSessionUser, notFound, requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { serializeDocument } from "@/lib/serialize";
import { resolveStorage, saveEnhanced } from "@/lib/storage";
import { readFile } from "node:fs/promises";
import { checkOcrAvailability, runOcrPipeline } from "@/lib/ocr";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

/** GET — honest OCR capability report for this deployment. */
export async function GET() {
  const availability = await checkOcrAvailability();
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false }, { status: 401 });
  return Response.json({ ok: true, availability });
}

/**
 * POST — run enhancement + OCR. Never fabricates success: failures are
 * returned with actionable messages, and the record keeps its honest state.
 */
export async function POST(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const { user, response } = await requireRole(["admin", "reviewer", "operator"]);
  if (response) return response;
  const [doc] = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  if (!doc) return notFound("Document not found");

  if (doc.pageKind === "pdf") {
    const msg =
      "This document is a PDF. Page rasterisation (poppler/ghostscript) is not available in this environment, so OCR cannot run on it here. Convert pages to PNG/JPG and upload those, or enter the fields manually in the workbench.";
    const [updated] = await db
      .update(documents)
      .set({ ocr: { status: "unavailable", message: msg, processedAt: new Date().toISOString() }, updatedAt: new Date() } as never)
      .where(eq(documents.id, id))
      .returning();
    await logAudit({ user, action: "ocr_run", entity: "document", entityId: id, summary: `OCR skipped for "${doc.title}": PDF rasterisation unavailable` });
    return Response.json({ ok: false, message: msg, document: serializeDocument(updated as unknown as Record<string, unknown>, "staff") }, { status: 422 });
  }

  const abs = resolveStorage(doc.originalPath ?? "");
  if (!abs) return notFound("Original file missing from storage");
  let input: Buffer;
  try {
    input = await readFile(abs);
  } catch {
    return notFound("Original file missing from storage");
  }

  const result = await runOcrPipeline(input, { enhance: true });

  if (!result.ok) {
    const [updated] = await db
      .update(documents)
      .set({
        ocr: { status: "failed", message: result.message, processedAt: new Date().toISOString() },
        updatedAt: new Date(),
      } as never)
      .where(eq(documents.id, id))
      .returning();
    await logAudit({ user, action: "ocr_run", entity: "document", entityId: id, summary: `OCR failed for "${doc.title}"`, payload: { message: result.message } });
    return Response.json(
      { ok: false, message: result.message, document: serializeDocument(updated as unknown as Record<string, unknown>, "staff") },
      { status: 422 },
    );
  }

  let enhancedPath = doc.enhancedPath;
  if (result.enhanced) {
    try {
      enhancedPath = await saveEnhanced(id, result.enhanced);
    } catch (e) {
      console.error("could not save enhanced image", e);
    }
  }

  const needsReview = result.imageQuality !== "legible" || result.fields.some((f) => f.status === "illegible" || f.status === "not_detected");
  const ocrMeta = {
    status: "done",
    engine: "tesseract.js (WASM Tesseract)",
    languages: result.languagesUsed,
    processedAt: new Date().toISOString(),
    avgConfidence: result.avgConfidence,
    words: result.words,
    imageQuality: result.imageQuality,
    message: needsReview
      ? "Extraction complete — needs manual review. Low-confidence or missing fields are highlighted; nothing is assumed."
      : "Extraction complete with legible quality. Verify all fields before approval.",
    rawText: result.text.slice(0, 8000),
  };
  const patched = doc.status === "draft" ? { status: "needs_review" } : {};
  const [updated] = await db
    .update(documents)
    .set({
      ocr: ocrMeta,
      extracted: result.fields as never,
      enhancedPath,
      ...patched,
      updatedAt: new Date(),
    } as never)
    .where(eq(documents.id, id))
    .returning();

  await logAudit({
    user,
    action: "ocr_run",
    entity: "document",
    entityId: id,
    summary: `OCR on "${doc.title}": ${result.words} tokens, avg confidence ${result.avgConfidence ?? "n/a"} (${result.imageQuality})`,
  });
  return Response.json({ ok: true, document: serializeDocument(updated as unknown as Record<string, unknown>, "staff"), quality: result.imageQuality });
}
