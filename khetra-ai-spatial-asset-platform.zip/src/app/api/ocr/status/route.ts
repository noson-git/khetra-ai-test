import { requireAuth } from "@/lib/auth";
import { checkOcrAvailability } from "@/lib/ocr";

export const dynamic = "force-dynamic";

/** Staff-only capability report. Honest about missing engine / language data. */
export async function GET() {
  const { response } = await requireAuth();
  if (response) return response;
  const availability = await checkOcrAvailability();
  return Response.json({ ok: true, availability });
}
