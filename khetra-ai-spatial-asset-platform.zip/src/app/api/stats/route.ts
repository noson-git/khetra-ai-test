import { db } from "@/db";
import { documents, hundiEntries, properties } from "@/db/schema";
import { and, desc, eq, sql, type SQL } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * All figures are computed live from the stored (sample) dataset.
 * scope=public  → published, non-archived records only.
 * scope=staff   → full dataset (requires authentication).
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const institutionId = url.searchParams.get("institution");
  const user = await getSessionUser();
  const scope = url.searchParams.get("scope") === "staff" && user ? "staff" : "public";
  if (!institutionId) return Response.json({ ok: false, message: "institution is required" }, { status: 400 });

  const instCond = eq(properties.institutionId, institutionId);
  const visibility: SQL[] =
    scope === "public" ? [eq(properties.status, "published"), eq(properties.archived, false)] : [];

  const propRows = await db
    .select({
      id: properties.id,
      assetType: properties.assetType,
      district: properties.district,
      tahasil: properties.tahasil,
      mouza: properties.mouza,
      status: properties.status,
      archived: properties.archived,
      areaAcres: properties.areaAcres,
      reportedConcern: properties.reportedConcern,
    })
    .from(properties)
    .where(and(instCond, ...visibility));

  const n = (v: unknown) => (v === null || v === undefined ? 0 : Number(v));
  const totalArea = propRows.reduce((a, r) => a + n(r.areaAcres), 0);

  const group = (key: "district" | "tahasil" | "mouza" | "assetType" | "status") => {
    const acc = new Map<string, { count: number; area: number }>();
    for (const r of propRows) {
      const k = String(r[key] ?? "—");
      const prev = acc.get(k) ?? { count: 0, area: 0 };
      prev.count += 1;
      prev.area += n(r.areaAcres);
      acc.set(k, prev);
    }
    return [...acc.entries()]
      .map(([label, v]) => ({ label, count: v.count, areaAcres: Math.round(v.area * 10000) / 10000 }))
      .sort((a, b) => b.count - a.count || b.areaAcres - a.areaAcres);
  };

  const docCond = eq(documents.institutionId, institutionId);
  const docVis: SQL[] = scope === "public" ? [eq(documents.status, "published")] : [];
  const docRows = await db
    .select({ id: documents.id, status: documents.status, docType: documents.docType, ocr: documents.ocr })
    .from(documents)
    .where(and(docCond, ...docVis));

  const docByStatus = docRows.reduce<Record<string, number>>((acc, r) => {
    acc[r.status] = (acc[r.status] ?? 0) + 1;
    return acc;
  }, {});
  const ocrProcessed = docRows.filter((r) => (r.ocr as { status?: string } | null)?.status === "done").length;

  const hundiLatest = await db
    .select({ collectionDate: hundiEntries.collectionDate, totalRupees: hundiEntries.totalRupees })
    .from(hundiEntries)
    .where(eq(hundiEntries.institutionId, institutionId))
    .orderBy(desc(hundiEntries.collectionDate))
    .limit(1);
  const hundiAgg = await db
    .select({
      entries: sql<number>`count(*)::int`,
      total: sql<string>`coalesce(sum(${hundiEntries.totalRupees}),0)::text`,
      firstDate: sql<string | null>`min(${hundiEntries.collectionDate})`,
      lastDate: sql<string | null>`max(${hundiEntries.collectionDate})`,
    })
    .from(hundiEntries)
    .where(eq(hundiEntries.institutionId, institutionId));

  return Response.json({
    ok: true,
    scope,
    institutionId,
    properties: {
      total: propRows.length,
      totalAreaAcres: Math.round(totalArea * 10000) / 10000,
      byDistrict: group("district"),
      byTahasil: group("tahasil"),
      byMouza: group("mouza"),
      byAssetType: group("assetType"),
      byStatus: group("status"),
      reportedConcerns: propRows.filter((r) => r.reportedConcern).length,
    },
    documents: {
      total: docRows.length,
      byStatus: docByStatus,
      ocrProcessed,
      pendingOcr: scope === "staff" ? docRows.filter((r) => !(r.ocr as { status?: string } | null)?.status || (r.ocr as { status?: string }).status !== "done").length : undefined,
    },
    hundi: {
      latest: hundiLatest[0]
        ? { collectionDate: hundiLatest[0].collectionDate, totalRupees: Number(hundiLatest[0].totalRupees) }
        : null,
      entries: hundiAgg[0]?.entries ?? 0,
      totalRupees: Number(hundiAgg[0]?.total ?? 0),
      firstDate: hundiAgg[0]?.firstDate ?? null,
      lastDate: hundiAgg[0]?.lastDate ?? null,
    },
    demo: true,
  });
}
