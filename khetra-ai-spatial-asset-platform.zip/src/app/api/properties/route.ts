import { db } from "@/db";
import { properties } from "@/db/schema";
import { and, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { getSessionUser, requireRole, badRequest } from "@/lib/auth";
import { serializeProperty } from "@/lib/serialize";
import { logAudit } from "@/lib/audit";
import { ASSET_TYPES, STATUSES } from "@/lib/constants";
import { illustrativePolygon, polygonCentroid } from "@/lib/geo";

export const dynamic = "force-dynamic";

/**
 * GET /api/properties
 * Public callers always receive only published, non-archived records.
 * scope=staff (authenticated) may filter by status / archived.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const user = await getSessionUser();
  const wantsStaff = url.searchParams.get("scope") === "staff";
  const scope = wantsStaff && user ? "staff" : "public";

  const conds: SQL[] = [];
  const institution = url.searchParams.get("institution");
  if (institution) conds.push(eq(properties.institutionId, institution));

  if (scope === "public") {
    conds.push(eq(properties.status, "published"));
    conds.push(eq(properties.archived, false));
  } else {
    const status = url.searchParams.get("status");
    if (status && (STATUSES as readonly string[]).includes(status)) conds.push(eq(properties.status, status));
    if (url.searchParams.get("archived") !== "true") conds.push(eq(properties.archived, false));
  }

  const district = url.searchParams.get("district");
  const tahasil = url.searchParams.get("tahasil");
  const mouza = url.searchParams.get("mouza");
  const assetType = url.searchParams.get("assetType");
  if (district) conds.push(eq(properties.district, district));
  if (tahasil) conds.push(eq(properties.tahasil, tahasil));
  if (mouza) conds.push(eq(properties.mouza, mouza));
  if (assetType) conds.push(eq(properties.assetType, assetType));

  const yearFrom = Number(url.searchParams.get("yearFrom"));
  const yearTo = Number(url.searchParams.get("yearTo"));
  if (Number.isFinite(yearFrom) && yearFrom > 0) {
    conds.push(sql`extract(year from ${properties.docDate}::date) >= ${yearFrom}`);
  }
  if (Number.isFinite(yearTo) && yearTo > 0) {
    conds.push(sql`extract(year from ${properties.docDate}::date) <= ${yearTo}`);
  }

  const q = (url.searchParams.get("q") ?? "").trim();
  if (q) {
    const like = `%${q}%`;
    conds.push(
      or(
        ilike(properties.assetCode, like),
        ilike(properties.title, like),
        ilike(properties.khataNo, like),
        ilike(properties.plotNo, like),
        ilike(properties.mouza, like),
        ilike(properties.docRef, like),
      ) as SQL,
    );
  }

  const rows = await db
    .select()
    .from(properties)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(properties.assetCode)
    .limit(2000);

  return Response.json({
    ok: true,
    scope,
    count: rows.length,
    properties: rows.map((p) => serializeProperty(p as unknown as Record<string, unknown>, scope)),
    demo: true,
  });
}

/** POST /api/properties — create draft record (any authenticated staff role). */
export async function POST(req: Request) {
  const { user, response } = await requireRole(["admin", "reviewer", "operator"]);
  if (response) return response;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return badRequest("Invalid JSON body");
  }
  const required = ["institutionId", "title", "district", "tahasil", "mouza"] as const;
  for (const k of required) {
    if (!String(body[k] ?? "").trim()) return badRequest(`Field "${k}" is required.`);
  }
  const assetType = ASSET_TYPES.includes(body.assetType as never) ? String(body.assetType) : "land";

  const lat = body.lat !== undefined && body.lat !== null && body.lat !== "" ? Number(body.lat) : null;
  const lng = body.lng !== undefined && body.lng !== null && body.lng !== "" ? Number(body.lng) : null;
  let geom = (body.geom as never) ?? null;
  if (!geom && lat !== null && lng !== null) {
    geom = illustrativePolygon(lat, lng, 55, String(body.title)) as never;
  }

  // Generate asset code
  const inst = String(body.institutionId);
  const prefix = inst === "jagannath" ? "KTR-SJ" : inst === "lingaraj" ? "KTR-LT" : "KTR-XX";
  const existing = await db
    .select({ code: properties.assetCode })
    .from(properties)
    .where(ilike(properties.assetCode, `${prefix}-%`));
  const next = existing.length + 1;
  const assetCode = `${prefix}-${String(next).padStart(4, "0")}`;

  const values = {
    assetCode,
    institutionId: inst,
    assetType,
    title: String(body.title).trim(),
    description: body.description ? String(body.description) : null,
    district: String(body.district).trim(),
    tahasil: String(body.tahasil).trim(),
    mouza: String(body.mouza).trim(),
    khataNo: body.khataNo ? String(body.khataNo) : null,
    plotNo: body.plotNo ? String(body.plotNo) : null,
    landClass: body.landClass ? String(body.landClass) : null,
    areaOriginal: body.areaOriginal ? String(body.areaOriginal) : null,
    areaUnit: body.areaUnit ? String(body.areaUnit) : null,
    areaAcres: body.areaAcres !== undefined && body.areaAcres !== null && body.areaAcres !== "" ? String(body.areaAcres) : null,
    docDate: body.docDate ? String(body.docDate) : null,
    docRef: body.docRef ? String(body.docRef) : null,
    geom,
    lat: geom && lat === null ? polygonCentroid(geom as never)?.lat ?? null : lat,
    lng: geom && lng === null ? polygonCentroid(geom as never)?.lng ?? null : lng,
    status: "draft",
    reportedConcern: Boolean(body.reportedConcern),
    concernNote: body.concernNote ? String(body.concernNote) : null,
    sensitiveNote: body.sensitiveNote ? String(body.sensitiveNote) : null,
    sampleData: body.sampleData === undefined ? true : Boolean(body.sampleData),
    createdBy: user!.id,
  };
  const [row] = await db.insert(properties).values(values as never).returning();
  await logAudit({
    user,
    action: "create",
    entity: "property",
    entityId: row.id,
    summary: `Created draft property ${row.assetCode} (${row.title})`,
  });
  return Response.json({ ok: true, property: serializeProperty(row as unknown as Record<string, unknown>, "staff") }, { status: 201 });
}
