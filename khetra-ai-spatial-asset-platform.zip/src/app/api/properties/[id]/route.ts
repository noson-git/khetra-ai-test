import { db } from "@/db";
import { properties } from "@/db/schema";
import { eq } from "drizzle-orm";
import { badRequest, getSessionUser, notFound, requireRole } from "@/lib/auth";
import { serializeProperty } from "@/lib/serialize";
import { logAudit } from "@/lib/audit";
import { ASSET_TYPES, TRANSITIONS, type Status, type Role } from "@/lib/constants";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

/** GET one record. Public callers only receive published records. */
export async function GET(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const [row] = await db.select().from(properties).where(eq(properties.id, id)).limit(1);
  if (!row) return notFound("Record not found");
  const user = await getSessionUser();
  const scope = user ? "staff" : "public";
  if (scope === "public" && (row.status !== "published" || row.archived)) {
    return notFound("Record not found");
  }
  return Response.json({ ok: true, scope, property: serializeProperty(row as unknown as Record<string, unknown>, scope) });
}

const EDITABLE = [
  "title",
  "description",
  "assetType",
  "district",
  "tahasil",
  "mouza",
  "khataNo",
  "plotNo",
  "landClass",
  "areaOriginal",
  "areaUnit",
  "areaAcres",
  "docDate",
  "docRef",
  "geom",
  "lat",
  "lng",
  "reportedConcern",
  "concernNote",
  "sensitiveNote",
  "sampleData",
] as const;

/** PATCH — edit fields, transition status, archive/restore. All role-checked server-side. */
export async function PATCH(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const { user, response } = await requireRole(["admin", "reviewer", "operator"]);
  if (response) return response;
  const [before] = await db.select().from(properties).where(eq(properties.id, id)).limit(1);
  if (!before) return notFound("Record not found");

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return badRequest("Invalid JSON body");
  }

  const changes: Record<string, unknown> = {};
  const summaryParts: string[] = [];

  // Field edits — operators may only edit drafts / needs_review; reviewer+admin may edit any non-archived state
  const wantsEdit = EDITABLE.some((k) => k in body);
  if (wantsEdit) {
    if (before.archived) return badRequest("Archived records must be restored before editing.");
    if (user!.role === "operator" && !["draft", "needs_review"].includes(before.status)) {
      return badRequest("Data Entry Operators may only edit records in Draft or Needs Review state.");
    }
    for (const k of EDITABLE) {
      if (!(k in body)) continue;
      let v = body[k];
      if (k === "assetType" && !ASSET_TYPES.includes(v as never)) return badRequest("Invalid asset type");
      if (k === "areaAcres" && v !== null && v !== "") v = String(v);
      if (k === "areaAcres" && (v === "" || v === undefined)) v = null;
      if (["reportedConcern", "sampleData"].includes(k)) v = Boolean(v);
      changes[k] = v === "" ? null : v;
    }
    if (Object.keys(changes).length) summaryParts.push(`edited fields: ${Object.keys(changes).join(", ")}`);
  }

  // Status transition
  if (body.status && body.status !== before.status) {
    const target = String(body.status) as Status;
    const allowed = TRANSITIONS[user!.role as Role][before.status as Status] ?? [];
    if (!allowed.includes(target)) {
      return Response.json(
        {
          ok: false,
          error: "forbidden",
          message: `${user!.role} cannot move a record from ${before.status} to ${target}. Allowed: ${allowed.join(", ") || "none"}.`,
        },
        { status: 403 },
      );
    }
    changes.status = target;
    summaryParts.push(`status ${before.status} → ${target}`);
  }

  // Archive / restore (admin only)
  if (body.archived !== undefined && Boolean(body.archived) !== before.archived) {
    if (user!.role !== "admin") {
      return Response.json({ ok: false, error: "forbidden", message: "Only Administrators may archive or restore records." }, { status: 403 });
    }
    changes.archived = Boolean(body.archived);
    summaryParts.push(Boolean(body.archived) ? "archived" : "restored");
  }

  if (!Object.keys(changes).length) return badRequest("No changes supplied");
  changes.updatedAt = new Date();
  const [after] = await db.update(properties).set(changes as never).where(eq(properties.id, id)).returning();
  await logAudit({
    user,
    action: changes.status ? "transition" : body.archived !== undefined ? (changes.archived ? "archive" : "restore") : "update",
    entity: "property",
    entityId: id,
    summary: `${before.assetCode}: ${summaryParts.join("; ")}`,
    payload: { before: { status: before.status, archived: before.archived }, changes },
  });
  return Response.json({ ok: true, property: serializeProperty(after as unknown as Record<string, unknown>, "staff") });
}
