import { db } from "@/db";
import { auditLog } from "@/db/schema";
import { and, desc, eq, ilike, type SQL } from "drizzle-orm";
import { requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** GET /api/audit — staff-visible audit trail (all authenticated roles). */
export async function GET(req: Request) {
  const { response } = await requireAuth();
  if (response) return response;
  const url = new URL(req.url);
  const conds: SQL[] = [];
  const entity = url.searchParams.get("entity");
  if (entity) conds.push(eq(auditLog.entity, entity));
  const q = url.searchParams.get("q");
  if (q) conds.push(ilike(auditLog.summary, `%${q}%`));
  const rows = await db
    .select()
    .from(auditLog)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(auditLog.createdAt))
    .limit(200);
  return Response.json({ ok: true, entries: rows });
}
