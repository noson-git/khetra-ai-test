import { db } from "@/db";
import { hundiEntries } from "@/db/schema";
import { eq } from "drizzle-orm";
import { badRequest, notFound, requireRole } from "@/lib/auth";
import { serializeHundi } from "@/lib/serialize";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

/** PATCH — correct a collection entry (Administrator only). */
export async function PATCH(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const { user, response } = await requireRole(["admin"]);
  if (response) return response;
  const [before] = await db.select().from(hundiEntries).where(eq(hundiEntries.id, id)).limit(1);
  if (!before) return notFound("Entry not found");
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return badRequest("Invalid JSON body");
  }
  const changes: Record<string, unknown> = {};
  if (body.collectionDate !== undefined) {
    const d = String(body.collectionDate);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return badRequest("collectionDate must be YYYY-MM-DD");
    changes.collectionDate = d;
  }
  let cash = Number(body.cashRupees ?? before.cashRupees);
  let draft = Number(body.draftRupees ?? before.draftRupees);
  if (!Number.isFinite(cash) || !Number.isFinite(draft) || cash < 0 || draft < 0) return badRequest("Amounts must be non-negative numbers");
  cash = Math.round(cash * 100) / 100;
  draft = Math.round(draft * 100) / 100;
  changes.cashRupees = cash.toFixed(2);
  changes.draftRupees = draft.toFixed(2);
  changes.totalRupees = (cash + draft).toFixed(2);
  for (const k of ["committeeNote", "sourceRef"] as const) {
    if (k in body) changes[k] = body[k] ? String(body[k]) : null;
  }
  if ("sampleData" in body) changes.sampleData = Boolean(body.sampleData);
  changes.updatedAt = new Date();
  try {
    const [after] = await db.update(hundiEntries).set(changes as never).where(eq(hundiEntries.id, id)).returning();
    await logAudit({
      user,
      action: "update",
      entity: "hundi",
      entityId: id,
      summary: `Hundi ${before.collectionDate}: corrected (₹${before.totalRupees} → ₹${after.totalRupees})`,
    });
    return Response.json({ ok: true, entry: serializeHundi(after as unknown as Record<string, unknown>) });
  } catch (e) {
    const flat = `${String(e)} ${String((e as { cause?: { message?: string } })?.cause?.message ?? "")} ${String(
      (e as { cause?: { cause?: { message?: string } } })?.cause?.cause?.message ?? "",
    )}`;
    return badRequest(/uq_hundi_inst_date|duplicate key|unique/i.test(flat) ? "Another entry already exists on that date." : "Could not save changes.");
  }
}

/** DELETE — remove an entry (Administrator only). Audited. */
export async function DELETE(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const { user, response } = await requireRole(["admin"]);
  if (response) return response;
  const [before] = await db.select().from(hundiEntries).where(eq(hundiEntries.id, id)).limit(1);
  if (!before) return notFound("Entry not found");
  await db.delete(hundiEntries).where(eq(hundiEntries.id, id));
  await logAudit({
    user,
    action: "delete",
    entity: "hundi",
    entityId: id,
    summary: `Deleted hundi entry ${before.collectionDate} (₹${before.totalRupees}, ${before.institutionId})`,
  });
  return Response.json({ ok: true });
}
