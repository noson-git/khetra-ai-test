import { db } from "@/db";
import { hundiEntries } from "@/db/schema";
import { and, desc, eq, gte, lte, sql, type SQL } from "drizzle-orm";
import { badRequest, requireRole } from "@/lib/auth";
import { serializeHundi } from "@/lib/serialize";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/**
 * GET /api/hundi?institution=&from=&to=
 * Public read access — this is a collection *history*, clearly labelled as
 * demonstration data. Not a payment gateway.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const institution = url.searchParams.get("institution");
  if (!institution) return badRequest("institution is required");
  const conds: SQL[] = [eq(hundiEntries.institutionId, institution)];
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  if (from) conds.push(gte(hundiEntries.collectionDate, from));
  if (to) conds.push(lte(hundiEntries.collectionDate, to));

  const rows = await db
    .select()
    .from(hundiEntries)
    .where(and(...conds))
    .orderBy(desc(hundiEntries.collectionDate))
    .limit(400);

  const [agg] = await db
    .select({
      total: sql<string>`coalesce(sum(${hundiEntries.totalRupees}),0)::text`,
      cash: sql<string>`coalesce(sum(${hundiEntries.cashRupees}),0)::text`,
      draft: sql<string>`coalesce(sum(${hundiEntries.draftRupees}),0)::text`,
    })
    .from(hundiEntries)
    .where(and(...conds));

  const latest = await db
    .select()
    .from(hundiEntries)
    .where(eq(hundiEntries.institutionId, institution))
    .orderBy(desc(hundiEntries.collectionDate))
    .limit(1);

  return Response.json({
    ok: true,
    institution,
    entries: rows.map((r) => serializeHundi(r as unknown as Record<string, unknown>)),
    range: { from: from ?? null, to: to ?? null },
    totals: {
      cash: Number(agg?.cash ?? 0),
      draft: Number(agg?.draft ?? 0),
      total: Number(agg?.total ?? 0),
      count: rows.length,
    },
    latest: latest[0] ? serializeHundi(latest[0] as unknown as Record<string, unknown>) : null,
    demo: true,
    disclaimer: "Collection history display only — demonstration data. Not a payment gateway and not a donation request.",
  });
}

/** POST — add a collection entry (Administrator only). */
export async function POST(req: Request) {
  const { user, response } = await requireRole(["admin"]);
  if (response) return response;
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return badRequest("Invalid JSON body");
  }
  const institution = String(body.institutionId ?? "").trim();
  const collectionDate = String(body.collectionDate ?? "").trim();
  if (!institution) return badRequest("institutionId is required");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(collectionDate)) return badRequest("collectionDate must be YYYY-MM-DD");
  const cash = Number(body.cashRupees ?? 0);
  const draft = Number(body.draftRupees ?? 0);
  if (!Number.isFinite(cash) || !Number.isFinite(draft) || cash < 0 || draft < 0) {
    return badRequest("Amounts must be non-negative numbers");
  }
  const total = Math.round((cash + draft) * 100) / 100;
  try {
    const [row] = await db
      .insert(hundiEntries)
      .values({
        institutionId: institution,
        collectionDate,
        cashRupees: cash.toFixed(2),
        draftRupees: draft.toFixed(2),
        totalRupees: total.toFixed(2),
        committeeNote: body.committeeNote ? String(body.committeeNote) : null,
        sourceRef: body.sourceRef ? String(body.sourceRef) : null,
        sampleData: body.sampleData === undefined ? true : Boolean(body.sampleData),
        createdBy: user!.id,
      } as never)
      .returning();
    await logAudit({ user, action: "create", entity: "hundi", entityId: row.id, summary: `Hundi entry ${collectionDate} — ₹${total.toFixed(2)} (${institution})` });
    return Response.json({ ok: true, entry: serializeHundi(row as unknown as Record<string, unknown>) }, { status: 201 });
  } catch (e) {
    const flat = (() => {
      let s = "";
      let cur: unknown = e;
      while (cur && typeof cur === "object" && cur !== null) {
        s += " " + String((cur as { message?: string }).message ?? "");
        cur = (cur as { cause?: unknown }).cause;
      }
      return s + " " + String(e);
    })();
    const msg = /uq_hundi_inst_date|duplicate key|unique/i.test(flat)
      ? "An entry already exists for this institution on that date. Edit the existing entry instead."
      : "Could not save the entry.";
    return badRequest(msg);
  }
}
