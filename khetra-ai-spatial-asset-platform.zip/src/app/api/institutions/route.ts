import { db } from "@/db";
import { institutions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { serializeInstitution } from "@/lib/serialize";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(institutions).where(eq(institutions.active, true));
  return Response.json({ ok: true, institutions: rows.map((r) => serializeInstitution(r as unknown as Record<string, unknown>)) });
}
