import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createSession, SESSION_COOKIE, verifyPassword } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import type { Role } from "@/lib/constants";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  let body: { username?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, message: "Invalid JSON body" }, { status: 400 });
  }
  const username = (body.username ?? "").trim().toLowerCase();
  const password = body.password ?? "";
  if (!username || !password) {
    return Response.json({ ok: false, message: "Username and password are required." }, { status: 400 });
  }
  const row = await db.select().from(users).where(eq(users.username, username)).limit(1);
  const user = row[0];
  if (!user || !verifyPassword(password, user.passwordHash)) {
    await logAudit({ user: null, action: "login_failed", entity: "session", summary: `Failed login for "${username}"` });
    return Response.json({ ok: false, message: "Invalid credentials." }, { status: 401 });
  }
  const token = await createSession(user.id);
  await logAudit({
    user: { id: user.id, username: user.username, displayName: user.displayName, role: user.role as Role },
    action: "login",
    entity: "session",
    summary: `${user.displayName} signed in`,
  });
  const res = Response.json({
    ok: true,
    user: { id: user.id, username: user.username, displayName: user.displayName, role: user.role },
  });
  res.headers.append(
    "Set-Cookie",
    `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${7 * 24 * 3600}`,
  );
  return res;
}
