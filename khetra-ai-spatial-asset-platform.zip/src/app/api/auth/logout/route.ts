import { cookies } from "next/headers";
import { destroySession, SESSION_COOKIE, getSessionUser } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

export async function POST() {
  const user = await getSessionUser();
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) await destroySession(token);
  if (user) {
    await logAudit({ user, action: "logout", entity: "session", summary: `${user.displayName} signed out` });
  }
  const res = Response.json({ ok: true });
  res.headers.append("Set-Cookie", `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
  return res;
}
