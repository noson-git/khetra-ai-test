import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, authenticated: false }, { status: 401 });
  return Response.json({ ok: true, authenticated: true, user });
}
