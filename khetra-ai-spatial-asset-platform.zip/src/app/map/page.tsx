"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import { Filter, RotateCcw, Search, MapPin } from "lucide-react";
import SiteHeader from "@/components/site-header";
import DemoNotice from "@/components/demo-notice";
import PropertyDrawer, { type PropertyRecord } from "@/components/property-drawer";
import { useInstitution } from "@/components/institution-context";
import { DemoTag, EmptyState, Spinner } from "@/components/ui";

const GisMap = dynamic(() => import("@/components/gis-map"), { ssr: false });

const ASSET_OPTIONS = [
  { value: "", label: "All asset types" },
  { value: "land", label: "Land" },
  { value: "building", label: "Building" },
  { value: "other", label: "Other property" },
];

export default function MapPage() {
  const { institution, institutionId } = useInstitution();
  const [all, setAll] = useState<PropertyRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [district, setDistrict] = useState("");
  const [tahasil, setTahasil] = useState("");
  const [mouza, setMouza] = useState("");
  const [assetType, setAssetType] = useState("");
  const [q, setQ] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [focus, setFocus] = useState<{ lat: number; lng: number; zoom?: number } | null>(null);

  useEffect(() => {
    if (!institutionId) return;
    setLoading(true);
    setSelectedId(null);
    fetch(`/api/properties?institution=${institutionId}`)
      .then((r) => r.json())
      .then((d) => setAll(d?.ok ? d.properties : []))
      .catch(() => setAll([]))
      .finally(() => setLoading(false));
  }, [institutionId]);

  const districts = useMemo(() => [...new Set(all.map((p) => p.district))].sort(), [all]);
  const tahasils = useMemo(
    () => [...new Set(all.filter((p) => !district || p.district === district).map((p) => p.tahasil))].sort(),
    [all, district],
  );
  const mouzas = useMemo(
    () =>
      [...new Set(all.filter((p) => (!district || p.district === district) && (!tahasil || p.tahasil === tahasil)).map((p) => p.mouza))].sort(),
    [all, district, tahasil],
  );

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return all.filter((p) => {
      if (district && p.district !== district) return false;
      if (tahasil && p.tahasil !== tahasil) return false;
      if (mouza && p.mouza !== mouza) return false;
      if (assetType && p.assetType !== assetType) return false;
      if (needle) {
        const hay = [p.title, p.assetCode, p.khataNo, p.plotNo, p.mouza, p.docRef].filter(Boolean).join(" ").toLowerCase();
        if (!hay.includes(needle)) return false;
      }
      return true;
    });
  }, [all, district, tahasil, mouza, assetType, q]);

  const selected = all.find((p) => p.id === selectedId) ?? null;

  const reset = useCallback(() => {
    setDistrict("");
    setTahasil("");
    setMouza("");
    setAssetType("");
    setQ("");
  }, []);

  const flyTo = useCallback((p: PropertyRecord) => {
    if (p.lat != null && p.lng != null) setFocus({ lat: p.lat, lng: p.lng, zoom: 16 });
    setSelectedId(p.id);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1 mx-auto w-full max-w-[1600px] px-4 md:px-6 py-6">
        <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
          <div>
            <p className="eyebrow text-[var(--color-saffron-2)] mb-1.5">Web-GIS Explorer</p>
            <h1 className="font-display text-3xl md:text-4xl leading-tight">
              {institution?.name ?? "—"} <span className="text-[rgba(244,236,216,0.4)]">· Estate Map</span>
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <DemoTag />
            <span className="chip hidden sm:inline-flex">published records only</span>
          </div>
        </div>

        <DemoNotice compact />

        {/* filter bar */}
        <div className="card mt-4 p-3.5 flex flex-wrap items-end gap-3">
          <div className="grow min-w-[180px] max-w-xs">
            <label className="label">Search record</label>
            <div className="relative">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[rgba(244,236,216,0.35)]" />
              <input className="input !pl-8" placeholder="Khata / plot / mouza / ID…" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
          </div>
          <FilterSelect label="District" value={district} onChange={(v) => { setDistrict(v); setTahasil(""); setMouza(""); }} options={districts} allLabel="All districts" />
          <FilterSelect label="Tahasil" value={tahasil} onChange={(v) => { setTahasil(v); setMouza(""); }} options={tahasils} allLabel="All tahasils" />
          <FilterSelect label="Mouza" value={mouza} onChange={setMouza} options={mouzas} allLabel="All mouzas" />
          <div>
            <label className="label">Asset</label>
            <select className="select" value={assetType} onChange={(e) => setAssetType(e.target.value)}>
              {ASSET_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
          <button className="btn btn-ghost btn-sm mb-0.5" onClick={reset}><RotateCcw size={12} /> Reset</button>
          <span className="ml-auto text-[11px] text-[rgba(244,236,216,0.5)] flex items-center gap-1.5 mb-1.5">
            <Filter size={11} /> {filtered.length} record{filtered.length === 1 ? "" : "s"} shown
          </span>
        </div>

        <div className="mt-4 grid xl:grid-cols-[1fr_320px] gap-4 items-start">
          <div className="relative">
            {loading && (
              <div className="absolute inset-0 z-[550] rounded-2xl bg-[rgba(19,16,11,0.5)] flex items-center justify-center backdrop-blur-[1px]">
                <span className="flex items-center gap-2 text-sm"><Spinner /> Loading published parcels…</span>
              </div>
            )}
            <GisMap
              properties={filtered}
              institution={institution}
              selectedId={selectedId}
              onSelect={setSelectedId}
              focus={focus}
              heightClass="h-[62vh] xl:h-[74vh]"
            />
          </div>

          <aside className="card p-3.5 max-h-[74vh] overflow-y-auto">
            <p className="label px-1 mb-2">Records in view</p>
            {filtered.length === 0 ? (
              <EmptyState title="No parcels match" message="Relax the geographic filters or clear the search." />
            ) : (
              <ul className="space-y-2">
                {filtered.map((p) => (
                  <li key={p.id}>
                    <button
                      onClick={() => flyTo(p)}
                      className={`w-full text-left rounded-xl border p-3 transition-colors ${
                        selectedId === p.id ? "border-[rgba(232,137,47,0.6)] bg-[rgba(232,137,47,0.08)]" : "hairline hover:bg-[rgba(244,236,216,0.05)]"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[13px] font-semibold leading-tight">{p.title}</span>
                        <MapPin size={12} className="shrink-0 text-[var(--color-saffron-2)]" />
                      </div>
                      <p className="text-[11px] text-[rgba(244,236,216,0.5)] mt-1">
                        {p.mouza} · {p.tahasil} · {p.district}
                      </p>
                      <p className="text-[10.5px] text-[rgba(244,236,216,0.42)] mt-0.5">
                        {p.assetCode} {p.khataNo ? `· Khata ${p.khataNo}` : ""} {p.plotNo ? `· Plot ${p.plotNo}` : ""}
                      </p>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </aside>
        </div>
      </main>

      <PropertyDrawer property={selected} onClose={() => setSelectedId(null)} onViewOnMap={flyTo} />
    </div>
  );
}

function FilterSelect({
  label,
  value,
  onChange,
  options,
  allLabel,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
  allLabel: string;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <select className="select" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">{allLabel}</option>
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
    </div>
  );
}
