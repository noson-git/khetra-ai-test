"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  Archive,
  Building2,
  FileScan,
  Landmark,
  Map as MapIcon,
  MapPin,
  Satellite,
  ScanSearch,
  ShieldCheck,
  Workflow,
  CheckCircle2,
  Coins,
  FileText as FileTextIcon,
} from "lucide-react";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import DemoNotice from "@/components/demo-notice";
import HundiWidget from "@/components/hundi-widget";
import { useInstitution } from "@/components/institution-context";
import { DemoTag, SectionHeading, Spinner } from "@/components/ui";

type Stats = {
  properties: {
    total: number;
    totalAreaAcres: number;
    byDistrict: { label: string; count: number; areaAcres: number }[];
    byTahasil: { label: string; count: number; areaAcres: number }[];
    byMouza: { label: string; count: number; areaAcres: number }[];
  };
  documents: { total: number; ocrProcessed: number };
  hundi: { latest: { collectionDate: string; totalRupees: number } | null; entries: number };
};

const MODULES = [
  {
    icon: Archive,
    title: "Centralised Digital Repository",
    body: "Institution asset records, cadastral details and source documents unified in one searchable estate register — institution selection kept independent of district, tahasil and mouza filters.",
  },
  {
    icon: FileScan,
    title: "Historical Document Preservation",
    body: "Scans are enhanced, OCR-processed in English, Odia and Hindi, then verified by humans against the original. Illegible marks stay illegible — nothing is invented.",
  },
  {
    icon: ShieldCheck,
    title: "Role-Based Administration",
    body: "Data Entry Operators, Reviewers and Administrators move records through Draft → Needs Review → Approved → Published, with a full audit trail of who changed what, and when.",
  },
  {
    icon: MapIcon,
    title: "Spatial Estate Intelligence",
    body: "Per-district, tahasil and mouza statistics computed live from the stored dataset. Temple markers are actual locations; parcel outlines are illustrative placeholders.",
  },
  {
    icon: Workflow,
    title: "Transparent Update Workflows",
    body: "Corrections never overwrite original scans. Document versions are preserved; public views show only published, redacted information.",
  },
  {
    icon: Coins,
    title: "Dana Hundi History",
    body: "Date-wise collection records with committee references — displayed as history with honest “no record available” states, never as ₹0. Not a payment gateway.",
  },
];

const PIPELINE = [
  { icon: FileScan, label: "Scan Upload", sub: "PDF / PNG / JPG" },
  { icon: ScanSearch, label: "Enhancement", sub: "Contrast & denoise" },
  { icon: FileTextIcon, label: "Multilingual OCR", sub: "eng · ori · hin" },
  { icon: CheckCircle2, label: "Human Verification", sub: "Uncertainty badges" },
  { icon: MapPin, label: "Property Linking", sub: "Khata · Plot · Kisam" },
  { icon: ShieldCheck, label: "Approval & Publish", sub: "Role-gated workflow" },
];

export default function LandingPage() {
  const { institutions, institution, institutionId, setInstitutionId, loading } = useInstitution();
  const [stats, setStats] = useState<Stats | null>(null);
  const [statsLoading, setStatsLoading] = useState(true);

  useEffect(() => {
    if (!institutionId) return;
    setStatsLoading(true);
    fetch(`/api/stats?institution=${institutionId}`)
      .then((r) => r.json())
      .then((d) => setStats(d?.ok ? d : null))
      .catch(() => setStats(null))
      .finally(() => setStatsLoading(false));
  }, [institutionId]);

  const maxDistrictArea = useMemo(
    () => Math.max(...(stats?.properties.byDistrict ?? []).map((d) => d.areaAcres), 0.01),
    [stats],
  );

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />

      {/* ------------------------------ HERO ------------------------------ */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/hero.jpg" alt="Temple spires at dusk (illustrative)" className="w-full h-full object-cover opacity-45" />
          <div className="absolute inset-0 bg-gradient-to-b from-[rgba(19,16,11,0.5)] via-[rgba(19,16,11,0.72)] to-[var(--color-ink)]" />
          <div className="absolute inset-0 bg-[radial-gradient(900px_380px_at_75%_20%,rgba(232,137,47,0.14),transparent_60%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 md:px-6 pt-20 md:pt-28 pb-20">
          <div className="flex flex-wrap items-center gap-2 mb-6 rise">
            <DemoTag />
            <span className="chip">OSFIC (Startup Odisha) venture blueprint</span>
            <span className="chip">PostgreSQL · Next.js · Leaflet Web-GIS</span>
          </div>
          <h1 className="font-display text-5xl sm:text-6xl md:text-7xl xl:text-8xl leading-[0.98] max-w-5xl rise" style={{ animationDelay: "0.08s" }}>
            <span className="font-odia not-italic text-[var(--color-saffron-2)]">କ୍ଷେତ୍ର</span> — where sacred
            <span className="italic text-[var(--color-saffron-2)]"> land</span> meets
            <span className="italic"> spatial intelligence</span>
          </h1>
          <p className="mt-6 max-w-2xl text-base md:text-lg text-[rgba(244,236,216,0.68)] leading-relaxed rise" style={{ animationDelay: "0.16s" }}>
            KhetraAI is an enterprise GIS concept for religious endowments: digitised property registers, preserved
            historical documents, multilingual OCR verification, and a Dana Hundi collection ledger — for
            geographically dispersed temple lands, from Bhubaneswar to Puri and beyond.
          </p>
          <div className="mt-9 flex flex-wrap gap-3 rise" style={{ animationDelay: "0.24s" }}>
            <Link href="/map" className="btn btn-primary">
              <Satellite size={15} /> Explore GIS Map
            </Link>
            <Link href="/properties" className="btn btn-ghost">
              <Landmark size={15} /> Temple Lands & Properties
            </Link>
            <Link href="/admin" className="btn btn-ghost">
              <ShieldCheck size={15} /> Staff Console
            </Link>
          </div>
          <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-px rounded-2xl border hairline overflow-hidden bg-[rgba(244,236,216,0.08)] rise" style={{ animationDelay: "0.32s" }}>
            {[
              { k: "Published records", v: statsLoading ? null : String(stats?.properties.total ?? 0) },
              { k: "Districts touched", v: statsLoading ? null : String(stats?.properties.byDistrict.length ?? 0) },
              { k: "Illustrative acres mapped", v: statsLoading ? null : (stats?.properties.totalAreaAcres?.toFixed(2) ?? "0") },
              { k: "Documents digitised", v: statsLoading ? null : String(stats?.documents.total ?? 0) },
            ].map((s) => (
              <div key={s.k} className="bg-[rgba(19,16,11,0.8)] backdrop-blur px-5 py-5">
                <p className="font-display text-2xl md:text-3xl text-[var(--color-saffron-2)] min-h-[2.25rem]">
                  {s.v === null ? <Spinner size={18} /> : s.v}
                </p>
                <p className="text-[11px] uppercase tracking-[0.18em] text-[rgba(244,236,216,0.5)] mt-1">{s.k}</p>
              </div>
            ))}
          </div>
          <p className="mt-3 text-[10.5px] text-[rgba(244,236,216,0.4)]">
            Computed live from the demonstration dataset for the selected institution — sample data only.
          </p>
        </div>
      </section>

      {/* --------------------------- DEMO NOTICE --------------------------- */}
      <div className="py-10">
        <DemoNotice />
      </div>

      {/* ------------------------ INSTITUTION SELECT ------------------------ */}
      <section className="mx-auto max-w-7xl px-4 md:px-6 py-14 w-full">
        <SectionHeading
          eyebrow="Institution / Jurisdiction"
          title={
            <>
              One estate register, <span className="italic text-[var(--color-saffron-2)]">two sacred seats</span>
            </>
          }
          right={<DemoTag />}
        />
        <div className="grid md:grid-cols-2 gap-5">
          {(loading
            ? [null, null]
            : institutions.slice(0, 2)
          ).map((inst, i) => {
            const activeHere = inst?.id === institutionId;
            const img = inst?.id === "jagannath" ? "/images/jagannath.jpg" : "/images/lingaraj.jpg";
            return (
              <button
                key={inst?.id ?? i}
                disabled={!inst}
                onClick={() => inst && setInstitutionId(inst.id)}
                className={`group relative text-left overflow-hidden rounded-2xl border transition-all duration-300 ${
                  activeHere
                    ? "border-[rgba(232,137,47,0.65)] shadow-[0_0_60px_rgba(232,137,47,0.15)]"
                    : "hairline hover:border-[rgba(244,236,216,0.35)]"
                }`}
              >
                <div className="aspect-[16/8] overflow-hidden">
                  {inst ? (
                    <img src={img} alt={`${inst.name} (illustrative rendering)`} className="w-full h-full object-cover opacity-70 group-hover:opacity-85 group-hover:scale-[1.03] transition-all duration-700" />
                  ) : (
                    <div className="w-full h-full bg-[var(--color-ink-3)] pulse-soft" />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-[rgba(19,16,11,0.94)] via-transparent to-transparent" />
                </div>
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <div className="flex items-center gap-2 mb-1.5">
                    {activeHere && <span className="chip chip-status-needs_review">Selected</span>}
                    <span className="chip">Temple · {inst?.district ?? "…"}</span>
                  </div>
                  <p className="font-display text-2xl md:text-3xl">{inst?.name ?? "Loading…"}</p>
                  {inst && (
                    <p className="text-sm text-[rgba(244,236,216,0.6)] mt-1 flex items-center gap-1.5">
                      <MapPin size={13} className="text-[var(--color-saffron-2)]" /> {inst.city} · holdings mapped across multiple districts
                    </p>
                  )}
                </div>
              </button>
            );
          })}
        </div>
        <p className="mt-4 text-xs text-[rgba(244,236,216,0.5)] max-w-3xl leading-relaxed">
          The institution selector is deliberately independent of geographic filters: Lingaraj Temple’s sample holdings
          span Khordha and Puri districts; Shree Jagannath Temple’s span Puri, Khordha and Cuttack. The schema remains
          extensible for additional temples, mathas and endowments.
        </p>
      </section>

      {/* ------------------------------ STATS ------------------------------ */}
      <section className="mx-auto max-w-7xl px-4 md:px-6 py-10 w-full">
        <div className="card p-6 md:p-9">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-7">
            <div>
              <p className="eyebrow text-[var(--color-saffron-2)] mb-2">Live Dataset Statistics</p>
              <h3 className="font-display text-2xl md:text-3xl">{institution?.name ?? "—"} — estate snapshot</h3>
            </div>
            <DemoTag />
          </div>
          {statsLoading ? (
            <div className="flex items-center gap-3 py-10 justify-center text-sm text-[rgba(244,236,216,0.5)]"><Spinner /> Computing from stored records…</div>
          ) : (
            <div className="grid lg:grid-cols-[1.15fr_1fr] gap-8">
              <div>
                <p className="label mb-3">Area by district (illustrative acres, published records)</p>
                <div className="space-y-3">
                  {(stats?.properties.byDistrict ?? []).map((d) => (
                    <div key={d.label}>
                      <div className="flex justify-between text-[13px] mb-1">
                        <span className="font-semibold">{d.label}</span>
                        <span className="text-[rgba(244,236,216,0.55)]">{d.count} record{d.count === 1 ? "" : "s"} · {d.areaAcres.toFixed(2)} ac</span>
                      </div>
                      <div className="h-2 rounded-full bg-[rgba(244,236,216,0.07)] overflow-hidden">
                        <div className="h-full rounded-full bg-gradient-to-r from-[var(--color-clay)] to-[var(--color-saffron)]" style={{ width: `${Math.max(4, (d.areaAcres / maxDistrictArea) * 100)}%` }} />
                      </div>
                    </div>
                  ))}
                  {!(stats?.properties.byDistrict ?? []).length && <p className="text-sm text-[rgba(244,236,216,0.5)]">No published records yet for this institution.</p>}
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4 content-start">
                {[
                  { label: "Tahasils", items: stats?.properties.byTahasil ?? [] },
                  { label: "Mouzas / Villages", items: stats?.properties.byMouza ?? [] },
                ].map((g) => (
                  <div key={g.label} className="rounded-xl border hairline p-4 bg-[rgba(244,236,216,0.025)]">
                    <p className="label">{g.label}</p>
                    <ul className="space-y-1.5 mt-1">
                      {g.items.slice(0, 6).map((m) => (
                        <li key={m.label} className="flex justify-between text-[13px]">
                          <span>{m.label}</span>
                          <span className="text-[var(--color-saffron-2)] font-semibold">{m.count}</span>
                        </li>
                      ))}
                      {!g.items.length && <li className="text-[13px] text-[rgba(244,236,216,0.45)]">None</li>}
                    </ul>
                  </div>
                ))}
                <div className="rounded-xl border hairline p-4 bg-[rgba(244,236,216,0.025)] sm:col-span-2 flex items-center gap-3">
                  <Building2 size={18} className="text-[var(--color-tealdeep)]" />
                  <p className="text-[13px] text-[rgba(244,236,216,0.65)] leading-relaxed">
                    Figures are calculated from the platform’s own sample dataset — never copied from official portals,
                    and never presented as verified institutional totals.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* ---------------------------- MODULES ----------------------------- */}
      <section className="mx-auto max-w-7xl px-4 md:px-6 py-14 w-full">
        <SectionHeading
          eyebrow="Platform Modules"
          title={
            <>
              Built for <span className="italic text-[var(--color-saffron-2)]">stewardship</span>, not spectacle
            </>
          }
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {MODULES.map((m, i) => (
            <div key={m.title} className="card p-6 rise" style={{ animationDelay: `${i * 0.05}s` }}>
              <div className="w-11 h-11 rounded-xl border hairline flex items-center justify-center text-[var(--color-saffron-2)] mb-4 bg-[rgba(232,137,47,0.08)]">
                <m.icon size={19} />
              </div>
              <h3 className="font-display text-lg mb-2">{m.title}</h3>
              <p className="text-[13px] text-[rgba(244,236,216,0.6)] leading-relaxed">{m.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ---------------------------- PIPELINE ----------------------------- */}
      <section className="mx-auto max-w-7xl px-4 md:px-6 py-10 w-full">
        <div className="card-paper p-6 md:p-10 text-[var(--color-ink)]">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
            <div>
              <p className="eyebrow text-[var(--color-clay)] mb-2">Preservation Pipeline</p>
              <h3 className="font-display text-2xl md:text-4xl">From brittle paper to verifiable record</h3>
            </div>
            <Link href="/admin" className="btn btn-primary btn-sm">Open the workbench <ArrowRight size={13} /></Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {PIPELINE.map((p, i) => (
              <div key={p.label} className="relative rounded-xl border border-[rgba(19,16,11,0.12)] bg-[rgba(255,255,255,0.45)] p-4">
                <span className="absolute top-3 right-3 font-display text-lg text-[rgba(19,16,11,0.22)]">{String(i + 1).padStart(2, "0")}</span>
                <p.icon size={18} className="text-[var(--color-clay)] mb-3" />
                <p className="text-[13px] font-bold leading-tight">{p.label}</p>
                <p className="text-[11px] text-[rgba(19,16,11,0.55)] mt-1">{p.sub}</p>
              </div>
            ))}
          </div>
          <p className="mt-5 text-[12px] text-[rgba(19,16,11,0.6)] leading-relaxed max-w-4xl">
            Honesty is an architectural rule: faded characters are flagged <em>Illegible</em> or <em>Not detected</em>,
            original units (Acres &amp; Decimals, Guntha &amp; Mana) are preserved verbatim with normalised acreage stored
            separately, and tenant/litigation details are redacted before anything reaches the public portal.
          </p>
        </div>
      </section>

      {/* --------------------------- IMAGERY NOTE --------------------------- */}
      <section className="mx-auto max-w-7xl px-4 md:px-6 py-14 w-full grid lg:grid-cols-2 gap-6 items-stretch">
        <div className="card p-7 md:p-9">
          <Satellite size={22} className="text-[var(--color-saffron-2)] mb-4" />
          <h3 className="font-display text-2xl mb-3">Satellite imagery, described honestly</h3>
          <div className="space-y-3 text-[13.5px] text-[rgba(244,236,216,0.65)] leading-relaxed">
            <p>
              Basemaps use <strong className="text-[var(--color-paper)]">Esri World Imagery</strong> (and a labelled variant) alongside{" "}
              <strong className="text-[var(--color-paper)]">OpenStreetMap</strong>. Esri documents that imagery dates, resolution and
              accuracy <em>vary by location and scale</em>. This platform never describes imagery as live, uniformly recent, or survey-accurate.
            </p>
            <p>
              A satellite photo is context — never proof of ownership, a legal parcel boundary, or evidence of
              encroachment. If imagery tiles fail to load, the map falls back automatically to the street basemap.
            </p>
            <p className="text-[12px] text-[rgba(244,236,216,0.45)]">
              No browser-facing API keys are required for these public basemap endpoints; provider attribution is
              displayed on the map frame at all times.
            </p>
          </div>
        </div>
        <Link href="/map" className="group relative overflow-hidden rounded-2xl border hairline min-h-[280px] block">
          <img src="/images/map-teaser.jpg" alt="Illustrative satellite view of temple precinct" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-[1.03] transition-transform duration-700" />
          <div className="absolute inset-0 bg-gradient-to-t from-[rgba(19,16,11,0.9)] to-transparent" />
          <div className="absolute bottom-0 p-7">
            <p className="eyebrow text-[var(--color-saffron-2)] mb-2">Interactive Web-GIS</p>
            <h3 className="font-display text-2xl md:text-3xl mb-2">Open the estate map</h3>
            <p className="text-[13px] text-[rgba(244,236,216,0.6)] max-w-md">
              Switch basemaps, slide parcel opacity over imagery, and click any illustrative plot to open its record.
            </p>
            <span className="btn btn-primary btn-sm mt-4">Launch map <ArrowRight size={13} /></span>
          </div>
        </Link>
      </section>

      <SiteFooter />
      <HundiWidget />
    </div>
  );
}
