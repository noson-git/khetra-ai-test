import {
  pgTable,
  text,
  integer,
  numeric,
  boolean,
  timestamp,
  date,
  jsonb,
  uuid,
  uniqueIndex,
  index,
  doublePrecision,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Identity & access                                                   */
/* ------------------------------------------------------------------ */

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  username: text("username").notNull().unique(),
  displayName: text("display_name").notNull(),
  role: text("role").notNull(), // admin | reviewer | operator
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/* ------------------------------------------------------------------ */
/* Institutions (extensible — more temples / mathas can be registered)  */
/* ------------------------------------------------------------------ */

export const institutions = pgTable("institutions", {
  id: text("id").primaryKey(), // e.g. "lingaraj", "jagannath"
  name: text("name").notNull(),
  nameOdia: text("name_odia"),
  deity: text("deity"),
  type: text("type").notNull().default("temple"),
  city: text("city").notNull(),
  district: text("district").notNull(),
  lat: doublePrecision("lat").notNull(), // actual temple location marker
  lng: doublePrecision("lng").notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/* ------------------------------------------------------------------ */
/* Asset / property records                                            */
/* ------------------------------------------------------------------ */

export const properties = pgTable(
  "properties",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    assetCode: text("asset_code").notNull().unique(), // e.g. KTR-LT-0001
    institutionId: text("institution_id")
      .notNull()
      .references(() => institutions.id),
    assetType: text("asset_type").notNull().default("land"), // land | building | other
    title: text("title").notNull(),
    description: text("description"),
    district: text("district").notNull(),
    tahasil: text("tahasil").notNull(),
    mouza: text("mouza").notNull(),
    khataNo: text("khata_no"),
    plotNo: text("plot_no"),
    landClass: text("land_class"), // kisam
    areaOriginal: text("area_original"), // preserved historical unit text
    areaUnit: text("area_unit"), // original unit label
    areaAcres: numeric("area_acres", { precision: 12, scale: 4 }), // normalised
    docDate: date("doc_date"),
    docRef: text("doc_ref"),
    // Illustrative geometry (GeoJSON polygon) — NOT survey data
    geom: jsonb("geom"),
    lat: doublePrecision("lat"), // illustrative centroid
    lng: doublePrecision("lng"),
    geometryNote: text("geometry_note").default("Illustrative parcel — not a legal/survey boundary"),
    status: text("status").notNull().default("draft"), // draft | needs_review | approved | published
    archived: boolean("archived").notNull().default(false),
    reportedConcern: boolean("reported_concern").notNull().default(false),
    concernNote: text("concern_note"), // public label: "Reported concern — not legally determined"
    sampleData: boolean("sample_data").notNull().default(true),
    sensitiveNote: text("sensitive_note"), // staff-only (redacted publicly)
    createdBy: uuid("created_by").references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("idx_props_inst").on(t.institutionId),
    index("idx_props_geo").on(t.district, t.tahasil, t.mouza),
    index("idx_props_status").on(t.status, t.archived),
  ],
);

/* ------------------------------------------------------------------ */
/* Documents & OCR pipeline                                            */
/* ------------------------------------------------------------------ */

export const documents = pgTable(
  "documents",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    institutionId: text("institution_id")
      .notNull()
      .references(() => institutions.id),
    propertyId: uuid("property_id").references(() => properties.id, { onDelete: "set null" }),
    title: text("title").notNull(),
    docType: text("doc_type").notNull().default("record"), // ror_extract | register_page | settlement | other
    refNo: text("ref_no"),
    docDate: date("doc_date"),
    status: text("status").notNull().default("draft"), // draft | needs_review | approved | published
    mime: text("mime").notNull(),
    sizeBytes: integer("size_bytes").notNull().default(0),
    originalPath: text("original_path").notNull(), // storage-relative (private store)
    enhancedPath: text("enhanced_path"), // enhanced copy, original preserved
    pageKind: text("page_kind").notNull().default("image"), // image | pdf (pdf rasterisation may be unavailable)
    version: integer("version").notNull().default(1),
    redactedPublic: boolean("redacted_public").notNull().default(true),
    sensitiveNote: text("sensitive_note"), // staff-only; never sent to public clients
    // Verified / extracted fields — JSONB array of field objects
    // [{ key, label, value, normalized, status: ok|uncertain|illegible|not_detected|manual, confidence, source: ocr|manual }]
    extracted: jsonb("extracted"),
    // OCR run metadata { status, engine, languages, processedAt, avgConfidence, words, message, rawText }
    ocr: jsonb("ocr"),
    sampleData: boolean("sample_data").notNull().default(true),
    createdBy: uuid("created_by").references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("idx_docs_inst").on(t.institutionId), index("idx_docs_prop").on(t.propertyId)],
);

export const documentVersions = pgTable("document_versions", {
  id: uuid("id").defaultRandom().primaryKey(),
  documentId: uuid("document_id")
    .notNull()
    .references(() => documents.id, { onDelete: "cascade" }),
  version: integer("version").notNull(),
  note: text("note"),
  path: text("path").notNull(),
  createdBy: uuid("created_by").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/* ------------------------------------------------------------------ */
/* Dana Hundi collection ledger                                        */
/* ------------------------------------------------------------------ */

export const hundiEntries = pgTable(
  "hundi_entries",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    institutionId: text("institution_id")
      .notNull()
      .references(() => institutions.id),
    collectionDate: date("collection_date").notNull(),
    cashRupees: numeric("cash_rupees", { precision: 14, scale: 2 }).notNull().default("0"),
    draftRupees: numeric("draft_rupees", { precision: 14, scale: 2 }).notNull().default("0"),
    totalRupees: numeric("total_rupees", { precision: 14, scale: 2 }).notNull().default("0"),
    committeeNote: text("committee_note"), // unsealing committee / EO audit reference
    sourceRef: text("source_ref"),
    sampleData: boolean("sample_data").notNull().default(true),
    createdBy: uuid("created_by").references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("uq_hundi_inst_date").on(t.institutionId, t.collectionDate)],
);

/* ------------------------------------------------------------------ */
/* Audit trail                                                         */
/* ------------------------------------------------------------------ */

export const auditLog = pgTable(
  "audit_log",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id"),
    userName: text("user_name"),
    userRole: text("user_role"),
    action: text("action").notNull(), // create | update | transition | archive | restore | upload | ocr_run | delete | login ...
    entity: text("entity").notNull(), // property | document | hundi | institution | session
    entityId: text("entity_id"),
    summary: text("summary").notNull(),
    payload: jsonb("payload"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("idx_audit_created").on(t.createdAt), index("idx_audit_entity").on(t.entity, t.entityId)],
);
