"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { X, History, Coins, CalendarRange, Landmark, FileText, TriangleAlert } from "lucide-react";
import { useInstitution } from "./institution-context";
import { DemoTag, EmptyState, Spinner, formatDate, formatINR } from "./ui";

type HundiEntry = {
  id: string;
  collectionDate: string;
  cashRupees: number;
  draftRupees: number;
  totalRupees: number;
  committeeNote: string | null;
  sourceRef: string | null;
};

type HundiResponse = {
  ok: boolean;
  entries: HundiEntry[];
  totals: { cash: number; draft: number; total: number; count: number };
  latest: HundiEntry | null;
  disclaimer: string;
};

export default function HundiWidget() {
  const { institution, institutionId } = useInstitution();
  const [dismissed, setDismissed] = useState(false);
  const [open, setOpen] = useState(false);
  const [data, setData] = useState<HundiResponse | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(
    (from?: string, to?: string) => {
      if (!institutionId) return;
      setLoading(true);
      const params = new URLSearchParams({ institution: institutionId });
      if (from) params.set("from", from);
      if (to) params.set("to", to);
      fetch(`/api/hundi?${params.toString()}`)
        .then((r) => r.json())
        .then((d) => setData(d))
        .catch(() => setData(null))
        .finally(() => setLoading(false));
    },
    [institutionId],
  );

  useEffect(() => {
    setDismissed(false);
    load();
  }, [load]);

  if (!institutionId) return null;

  return (
    <>
      {!dismissed && (
        <div className="fixed bottom-4 right-4 z-[70] w-[calc(100vw-2rem)] max-w-xs rise">
          <div className="card p-4 !rounded-2xl relative overflow-hidden">
            <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-[rgba(201,162,75,0.14)] blur-2xl pointer-events-none" />
            <button
              onClick={() => setDismissed(true)}
              className="absolute top-2.5 right-2.5 text-[rgba(244,236,216,0.4)] hover:text-[var(--color-paper)] transition-colors"
              aria-label="Dismiss Dana Hundi widget"
            >
              <X size={14} />
            </button>
            <div className="flex items-center gap-2 mb-1.5">
              <Coins size={14} className="text-[var(--color-gold)]" />
              <p className="text-[10px] uppercase tracking-[0.22em] font-bold text-[var(--color-gold)]">Dana Hundi</p>
              <span className="ml-auto"><DemoTag label="Sample" /></span>
            </div>
            <p className="text-sm font-semibold leading-tight mb-2">{institution?.name ?? "—"}</p>
            {loading ? (
              <div className="flex items-center gap-2 text-xs text-[rgba(244,236,216,0.55)] py-2"><Spinner size={13} /> Loading…</div>
            ) : data?.latest ? (
              <div className="mb-3">
                <p className="text-[11px] text-[rgba(244,236,216,0.5)]">Latest recorded collection · {formatDate(data.latest.collectionDate)}</p>
                <p className="font-display text-2xl mt-0.5">{formatINR(data.latest.totalRupees)}</p>
              </div>
            ) : (
              <p className="text-xs text-[rgba(244,236,216,0.55)] mb-3">No collection records available for this institution.</p>
            )}
            <button onClick={() => setOpen(true)} className="btn btn-ghost btn-sm w-full">
              <History size={13} /> View History
            </button>
            <p className="mt-2 text-[9.5px] leading-snug text-[rgba(244,236,216,0.4)]">
              Collection history only — not a payment gateway or donation request.
            </p>
          </div>
        </div>
      )}
      {dismissed && (
        <button
          onClick={() => setDismissed(false)}
          className="fixed bottom-4 right-4 z-[70] btn btn-ghost btn-sm !rounded-full shadow-[var(--shadow-card)]"
          aria-label="Show Dana Hundi widget"
        >
          <Coins size={13} className="text-[var(--color-gold)]" /> Hundi
        </button>
      )}
      {open && <HundiModal institutionName={institution?.name ?? ""} onClose={() => setOpen(false)} load={load} data={data} loading={loading} />}
    </>
  );
}

function HundiModal({
  institutionName,
  onClose,
  load,
  data,
  loading,
}: {
  institutionName: string;
  onClose: () => void;
  load: (from?: string, to?: string) => void;
  data: HundiResponse | null;
  loading: boolean;
}) {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [singleDate, setSingleDate] = useState("");
  const entries = data?.entries ?? [];

  const shownEntries = useMemo(() => {
    if (!singleDate) return entries;
    return entries.filter((e) => e.collectionDate === singleDate);
  }, [entries, singleDate]);

  const shownTotal = useMemo(
    () => (singleDate ? shownEntries.reduce((a, e) => a + e.totalRupees, 0) : (data?.totals.total ?? 0)),
    [singleDate, shownEntries, data],
  );

  return (
    <div className="fixed inset-0 z-[95] flex items-end sm:items-center justify-center p-0 sm:p-6">
      <div className="absolute inset-0 bg-[rgba(10,8,5,0.72)] backdrop-blur-sm" onClick={onClose} />
      <div className="relative card !rounded-b-none sm:!rounded-2xl w-full max-w-3xl max-h-[88vh] flex flex-col overflow-hidden">
        <div className="p-5 md:p-6 border-b hairline flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Landmark size={15} className="text-[var(--color-gold)]" />
              <p className="eyebrow text-[var(--color-gold)] !text-[10px]">Dana Hundi Collection History</p>
              <DemoTag label="Demo / Sample Data" />
            </div>
            <h3 className="font-display text-xl md:text-2xl">{institutionName}</h3>
            <p className="text-[11px] text-[rgba(244,236,216,0.5)] mt-1">
              Date-wise audit of recorded unsealing counts. Missing dates mean no record — never shown as ₹0.
            </p>
          </div>
          <button onClick={onClose} className="btn-ghost btn btn-sm !px-2.5 shrink-0" aria-label="Close">
            <X size={15} />
          </button>
        </div>

        <div className="p-5 md:p-6 pt-4 overflow-y-auto">
          <div className="grid grid-cols-1 sm:grid-cols-[1fr_1fr_1fr_auto] gap-3 items-end mb-2">
            <div>
              <label className="label">Start date</label>
              <input type="date" className="input" value={from} onChange={(e) => setFrom(e.target.value)} />
            </div>
            <div>
              <label className="label">End date</label>
              <input type="date" className="input" value={to} onChange={(e) => setTo(e.target.value)} />
            </div>
            <div>
              <label className="label">Single date check</label>
              <input
                type="date"
                className="input"
                value={singleDate}
                onChange={(e) => setSingleDate(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <button className="btn btn-primary btn-sm" onClick={() => load(from || undefined, to || undefined)}>
                <CalendarRange size={13} /> Apply
              </button>
              <button
                className="btn btn-ghost btn-sm"
                onClick={() => {
                  setFrom("");
                  setTo("");
                  setSingleDate("");
                  load();
                }}
              >
                Reset
              </button>
            </div>
          </div>
          {singleDate && (
            <button className="text-[11px] text-[var(--color-saffron-2)] underline underline-offset-2 mb-2" onClick={() => setSingleDate("")}>
              Clear single-date check
            </button>
          )}

          {loading ? (
            <div className="flex items-center justify-center gap-2 py-12 text-sm text-[rgba(244,236,216,0.55)]"><Spinner /> Loading ledger…</div>
          ) : singleDate && shownEntries.length === 0 ? (
            <EmptyState
              icon={CalendarRange}
              title="No record available"
              message={`No Dana Hundi collection record exists for ${formatDate(singleDate)}. This does not imply a ₹0 collection — it means no recording is available.`}
            />
          ) : shownEntries.length === 0 ? (
            <EmptyState
              icon={CalendarRange}
              title="No record available"
              message="No collection records exist for the selected range. Adjust the dates or reset the filter."
            />
          ) : (
            <div className="table-shell">
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Cash</th>
                    <th>Cheque / Draft</th>
                    <th>Total</th>
                    <th className="hidden md:table-cell">Unsealing Committee / Audit Note</th>
                    <th className="hidden md:table-cell">Source</th>
                  </tr>
                </thead>
                <tbody>
                  {shownEntries.map((e) => (
                    <tr key={e.id}>
                      <td className="font-semibold whitespace-nowrap">{formatDate(e.collectionDate)}</td>
                      <td>{formatINR(e.cashRupees)}</td>
                      <td>{formatINR(e.draftRupees)}</td>
                      <td className="font-display text-[var(--color-saffron-2)]">{formatINR(e.totalRupees)}</td>
                      <td className="hidden md:table-cell text-[12px] text-[rgba(244,236,216,0.6)] max-w-[16rem]">{e.committeeNote ?? "—"}</td>
                      <td className="hidden md:table-cell text-[12px]">
                        {e.sourceRef ? (
                          <span className="inline-flex items-center gap-1 text-[rgba(244,236,216,0.6)]"><FileText size={11} /> {e.sourceRef}</span>
                        ) : (
                          "—"
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border hairline bg-[rgba(244,236,216,0.04)] px-4 py-3">
            <p className="text-[11px] text-[rgba(244,236,216,0.55)]">
              {singleDate ? `Total for ${formatDate(singleDate)}` : "Range total"} · {shownEntries.length} record{shownEntries.length === 1 ? "" : "s"}
            </p>
            <p className="font-display text-xl">{formatINR(shownTotal)}</p>
          </div>

          <p className="mt-3 flex items-start gap-2 text-[10.5px] leading-relaxed text-[rgba(244,236,216,0.42)]">
            <TriangleAlert size={12} className="mt-0.5 shrink-0 text-[var(--color-gold)]" />
            All amounts are illustrative demonstration data. This panel displays collection history; it is not a payment
            gateway, not a donation request, and not an audited institutional account.
          </p>
        </div>
      </div>
    </div>
  );
}
