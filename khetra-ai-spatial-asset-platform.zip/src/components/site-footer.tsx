import { DEMO_NOTICE } from "@/lib/constants";
import { FlaskConical, Landmark } from "lucide-react";

export default function SiteFooter() {
  return (
    <footer className="border-t hairline mt-24">
      <div className="mx-auto max-w-7xl px-4 md:px-6 py-12 grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="flex items-center gap-2 font-display text-xl mb-3">
            <span className="font-odia text-[var(--color-saffron-2)]">କ୍ଷେତ୍ର</span> KhetraAI
          </p>
          <p className="text-sm text-[rgba(244,236,216,0.55)] leading-relaxed max-w-md">
            Enterprise GIS & spatial asset intelligence concept for religious endowments — centralised digital
            repository, historical-document preservation, and transparent review workflows.
          </p>
          <p className="mt-4 text-[11px] leading-relaxed text-[rgba(244,236,216,0.4)] max-w-md border hairline rounded-xl p-3 bg-[rgba(244,236,216,0.03)]">
            <FlaskConical size={12} className="inline mr-1.5 text-[var(--color-gold)]" />
            {DEMO_NOTICE}
          </p>
        </div>
        <div>
          <p className="label mb-3">Concept Modules</p>
          <ul className="space-y-2 text-sm text-[rgba(244,236,216,0.6)]">
            <li>Multi-provider Web-GIS (Esri World Imagery, OpenStreetMap)</li>
            <li>Historical scan preservation & OCR verification</li>
            <li>Role-based administration & audit trail</li>
            <li>Dana Hundi collection history</li>
          </ul>
        </div>
        <div>
          <p className="label mb-3">Integrity Notes</p>
          <ul className="space-y-2 text-sm text-[rgba(244,236,216,0.6)]">
            <li className="flex gap-2"><Landmark size={14} className="mt-1 shrink-0 text-[var(--color-gold)]" /> Temple markers are actual temple locations; parcel outlines are illustrative.</li>
            <li>Satellite imagery dates & resolution vary by location — not survey grade.</li>
            <li>No official seal, emblem or government branding is used. No endorsement implied.</li>
            <li>This is not an official land-records portal.</li>
          </ul>
        </div>
      </div>
      <div className="border-t hairline py-5 text-center text-[11px] text-[rgba(244,236,216,0.35)]">
        KhetraAI demonstration build · OSFIC (Startup Odisha) venture blueprint · All figures are illustrative sample data
      </div>
    </footer>
  );
}
