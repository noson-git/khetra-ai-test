"use client";

import { useEffect, useState } from "react";
import { X, MapPin, FileText, Fingerprint, ExternalLink, ScrollText } from "lucide-react";
import type { MapProperty } from "./gis-map";
import { DemoTag, EmptyState, Field, Spinner, StatusChip, formatDate } from "./ui";

export type PropertyRecord = MapProperty & {
  id: string;
  institutionId: string;
  description: string | null;
  landClass: string | null;
  areaUnit: string | null;
  areaAcres: number | null;
  docDate: string | null;
  docRef: string | null;
  archived: boolean;
  sampleData: boolean;
  redactionNote?: string | null;
  updatedAt?: string;
};

type LinkedDoc = {
  id: string;
  title: string;
  docType: string;
  refNo: string | null;
  docDate: string | null;
  status: string;
  pageKind: string;
  hasSensitiveRedactions?: boolean;
};

export default function PropertyDrawer({
  property,
  onClose,
  onViewOnMap,
}: {
  property: PropertyRecord | null;
  onClose: () => void;
  onViewOnMap?: (p: PropertyRecord) => void;
}) {
  const [docs, setDocs] = useState<LinkedDoc[] | null>(null);

  useEffect(() => {
    setDocs(null);
    if (!property) return;
    fetch(`/api/documents?propertyId=${property.id}`)
      .then((r) => r.json())
      .then((d) => setDocs(d?.ok ? d.documents : []))
      .catch(() => setDocs([]));
  }, [property?.id]);

  if (!property) return null;

  return (
    <div className="fixed inset-0 z-[85] flex justify-end">
      <div className="absolute inset-0 bg-[rgba(10,8,5,0.6)] backdrop-blur-[2px]" onClick={onClose} />
      <aside className="relative w-full max-w-lg h-full bg-[var(--color-ink-2)] border-l hairline overflow-y-auto shadow-[var(--shadow-card)]">
        <div className="sticky top-0 z-10 bg-[rgba(27,23,18,0.94)] backdrop-blur border-b hairline p-5 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 mb-1.5">
              <span className="chip"><Fingerprint size={10} /> {property.assetCode}</span>
              <StatusChip status={property.status} />
              {property.sampleData && <DemoTag label="Sample" />}
            </div>
            <h3 className="font-display text-xl leading-snug">{property.title}</h3>
          </div>
          <button onClick={onClose} className="btn-ghost btn btn-sm !px-2.5 shrink-0" aria-label="Close record">
            <X size={15} />
          </button>
        </div>

        <div className="p-5 space-y-6">
          {onViewOnMap && (
            <button className="btn btn-primary w-full" onClick={() => onViewOnMap(property)}>
              <MapPin size={15} /> View on Map
            </button>
          )}

          {property.reportedConcern && (
            <div className="rounded-xl border border-[rgba(217,93,57,0.5)] bg-[rgba(217,93,57,0.1)] p-3.5">
              <p className="text-[12px] font-bold text-[#f2b09d] mb-0.5">Reported concern — not legally determined</p>
              <p className="text-[11.5px] text-[rgba(244,236,216,0.6)] leading-relaxed">
                This is a fictional workflow demonstration. No real individual or identifiable private property is
                referenced, and no encroachment is asserted.
              </p>
            </div>
          )}

          <div>
            <p className="eyebrow text-[var(--color-gold)] !text-[10px] mb-3">Cadastral Identity</p>
            <div className="grid grid-cols-2 gap-x-4 gap-y-4">
              <Field label="Asset type" value={property.assetType} />
              <Field label="District" value={property.district} />
              <Field label="Tahasil" value={property.tahasil} />
              <Field label="Mouza / Village" value={property.mouza} />
              <Field label="Khata No." value={property.khataNo} mono />
              <Field label="Plot No." value={property.plotNo} mono />
              <Field label="Land classification (Kisam)" value={property.landClass} />
              <Field label="Record / document date" value={formatDate(property.docDate)} />
              <Field label="Source document reference" value={property.docRef} mono />
            </div>
          </div>

          <div className="rounded-xl border hairline p-4 bg-[rgba(244,236,216,0.03)]">
            <div className="grid grid-cols-2 gap-4">
              <Field label="Area — original unit" value={property.areaOriginal ? `${property.areaOriginal}${property.areaUnit ? "" : ""}` : null} />
              <Field label="Original unit label" value={property.areaUnit} />
              <Field label="Normalised area (acres)" value={property.areaAcres !== null && property.areaAcres !== undefined ? `${Number(property.areaAcres).toFixed(4)} ac` : null} />
            </div>
            <p className="mt-3 text-[10.5px] text-[rgba(244,236,216,0.45)] leading-relaxed">
              Original historical units are preserved verbatim; normalisation is stored separately and is indicative.
            </p>
          </div>

          {property.description && (
            <div>
              <p className="eyebrow text-[var(--color-gold)] !text-[10px] mb-2">Notes</p>
              <p className="text-sm text-[rgba(244,236,216,0.7)] leading-relaxed">{property.description}</p>
            </div>
          )}

          {property.redactionNote && (
            <p className="text-[11.5px] text-[rgba(244,236,216,0.5)] border hairline rounded-lg p-3 bg-[rgba(244,236,216,0.03)]">
              {property.redactionNote}
            </p>
          )}

          <div>
            <p className="eyebrow text-[var(--color-gold)] !text-[10px] mb-3">Linked Historical Scans</p>
            {docs === null ? (
              <div className="flex items-center gap-2 text-xs text-[rgba(244,236,216,0.5)] py-3"><Spinner size={13} /> Loading…</div>
            ) : docs.length === 0 ? (
              <EmptyState icon={ScrollText} title="No linked scans" message="No published historical documents are linked to this record yet." />
            ) : (
              <div className="space-y-2.5">
                {docs.map((d) => (
                  <div key={d.id} className="rounded-xl border hairline p-3.5 bg-[rgba(244,236,216,0.02)]">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold leading-snug flex items-center gap-1.5">
                          <FileText size={13} className="shrink-0 text-[var(--color-saffron-2)]" /> {d.title}
                        </p>
                        <p className="text-[11px] text-[rgba(244,236,216,0.5)] mt-1">
                          {d.docType.replace(/_/g, " ")} {d.refNo ? `· Ref ${d.refNo}` : ""} {d.docDate ? `· ${formatDate(d.docDate)}` : ""}
                        </p>
                        {d.hasSensitiveRedactions && (
                          <p className="text-[10px] text-[var(--color-gold)] mt-1">Personal details redacted for public view</p>
                        )}
                      </div>
                      <a className="btn btn-ghost btn-sm shrink-0" href={`/api/documents/${d.id}/file`} target="_blank" rel="noreferrer">
                        <ExternalLink size={12} /> View scan
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <p className="text-[10px] text-[rgba(244,236,216,0.35)] leading-relaxed border-t hairline pt-3">
            {property.geometryNote ?? "Illustrative parcel — not a legal or survey boundary."} Record ID {property.id}.
            Showcased for demonstration; not for legal, ownership, survey or financial decisions.
          </p>
        </div>
      </aside>
    </div>
  );
}
