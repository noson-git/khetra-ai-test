"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type Institution = {
  id: string;
  name: string;
  nameOdia: string | null;
  deity: string | null;
  type: string;
  city: string;
  district: string;
  lat: number;
  lng: number;
  active: boolean;
};

type InstitutionContextValue = {
  institutions: Institution[];
  institution: Institution | null;
  institutionId: string;
  setInstitutionId: (id: string) => void;
  loading: boolean;
};

const InstitutionContext = createContext<InstitutionContextValue | null>(null);
const STORAGE_KEY = "khetra:institution";

export function InstitutionProvider({ children }: { children: ReactNode }) {
  const [institutions, setInstitutions] = useState<Institution[]>([]);
  const [institutionId, setInstitutionIdState] = useState<string>("lingaraj");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const saved = typeof window !== "undefined" ? window.localStorage.getItem(STORAGE_KEY) : null;
    if (saved) setInstitutionIdState(saved);
    fetch("/api/institutions")
      .then((r) => r.json())
      .then((d) => {
        if (d?.ok && Array.isArray(d.institutions)) {
          setInstitutions(d.institutions);
          if (saved && !d.institutions.some((i: Institution) => i.id === saved)) {
            setInstitutionIdState(d.institutions[0]?.id ?? "lingaraj");
          }
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const setInstitutionId = useCallback((id: string) => {
    setInstitutionIdState(id);
    try {
      window.localStorage.setItem(STORAGE_KEY, id);
    } catch {}
  }, []);

  const institution = useMemo(
    () => institutions.find((i) => i.id === institutionId) ?? institutions[0] ?? null,
    [institutions, institutionId],
  );

  const value = useMemo(
    () => ({ institutions, institution, institutionId: institution?.id ?? institutionId, setInstitutionId, loading }),
    [institutions, institution, institutionId, setInstitutionId, loading],
  );

  return <InstitutionContext.Provider value={value}>{children}</InstitutionContext.Provider>;
}

export function useInstitution(): InstitutionContextValue {
  const ctx = useContext(InstitutionContext);
  if (!ctx) throw new Error("useInstitution must be used inside InstitutionProvider");
  return ctx;
}
