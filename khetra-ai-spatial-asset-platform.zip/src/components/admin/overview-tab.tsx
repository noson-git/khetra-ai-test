"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Archive, FileScan, Workflow, Database, ArrowRight } from "lucide-react";
import { useInstitution } from "@/components/institution-context";
import { DemoTag, Spinner, formatINR, formatDate } from "@/components/ui";
import type { SessionUser } from "@/lib/auth";

type StaffStats = {
  properties: { total: number; totalAreaAcres: number; byStatus: { label: string; count: number }[] };
  documents: { total: number; byStatus: Record<string, number>; ocrProcessed: number; pendingOcr?: number };
  hundi: { latest: { collectionDate: string; totalRupees: number } | null; entries: number; totalRupees: number };
};

export default function OverviewTab({ user }: { user: SessionUser }) {
  void user;
  const { institution, institutionId } = useInstitution();
  const [stats, setStats] = useState<StaffStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!institutionId) return;
    setLoading(true);
    fetch(`/api/stats?institution=${institutionId}&scope=staff`)
      .then((r) => r.json())
      .then((d) => setStats(d?.ok ? d : null))
      .catch(() => setStats(null))
      .finally(() => setLoading(false));
  }, [institutionId]);

  const statusOrder = ["draft", "needs_review", "approved", "published"];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="eyebrow text-[var(--color-saffron-2)] mb-1">Full dataset view (staff scope)</p>
          <h2 className="font-display text-2xl md:text-3xl">{institution?.name ?? "—"}</h2>
        </div>
        <DemoTag />
      </div>

      {loading ? (
        <div className="flex justify-center py-14"><Spinner /></div>
      ) : !stats ? (
        <p className="text-sm text-[rgba(244,236,216,0.5)]">Could not load statistics.</p>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Archive, label: "Asset records", value: stats.properties.total, sub: `${stats.properties.totalAreaAcres.toFixed(2)} illustrative acres` },
              { icon: FileScan, label: "Documents", value: stats.documents.total, sub: `${stats.documents.ocrProcessed} OCR-processed · ${stats.documents.pendingOcr ?? 0} pending` },
              { icon: Workflow, label: "In draft / review", value: (stats.properties.byStatus.find((s) => s.label === "draft")?.count ?? 0) + (stats.properties.byStatus.find((s) => s.label === "needs_review")?.count ?? 0), sub: "awaiting reviewer / publisher" },
              { icon: Database, label: "Hundi entries", value: stats.hundi.entries, sub: stats.hundi.latest ? `latest ${formatDate(stats.hundi.latest.collectionDate)} · ${formatINR(stats.hundi.latest.totalRupees)}` : "no records yet" },
            ].map((c) => (
              <div key={c.label} className="card p-5">
                <c.icon size={17} className="text-[var(--color-saffron-2)] mb-3" />
                <p className="font-display text-3xl">{c.value}</p>
                <p className="text-[11px] uppercase tracking-[0.16em] text-[rgba(244,236,216,0.5)] mt-1">{c.label}</p>
                <p className="text-[11px] text-[rgba(244,236,216,0.45)] mt-1.5">{c.sub}</p>
              </div>
            ))}
          </div>

          <div className="card p-6">
            <p className="label mb-4">Record pipeline — counts by workflow status</p>
            <div className="flex flex-wrap gap-3">
              {statusOrder.map((s) => {
                const count = stats.properties.byStatus.find((x) => x.label === s)?.count ?? 0;
                return (
                  <div key={s} className="flex-1 min-w-[130px] rounded-xl border hairline p-4 bg-[rgba(244,236,216,0.02)]">
                    <p className="font-display text-2xl">{count}</p>
                    <p className={`chip chip-status-${s === "needs_review" ? "needs_review" : s} mt-2`}>{s.replace("_", " ")}</p>
                  </div>
                );
              })}
            </div>
            <p className="mt-4 text-[11.5px] text-[rgba(244,236,216,0.5)] leading-relaxed">
              Workflow: <strong className="text-[var(--color-paper)]">Draft → Needs Review → Approved → Published</strong>. Transitions are
              permission-checked on the server and written to the audit trail with the actor and timestamp.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {stats.hundi.latest && (
              <div className="card p-6">
                <p className="label mb-2">Latest recorded hundi collection</p>
                <p className="font-display text-3xl text-[var(--color-saffron-2)]">{formatINR(stats.hundi.latest.totalRupees)}</p>
                <p className="text-[12px] text-[rgba(244,236,216,0.55)] mt-1">on {formatDate(stats.hundi.latest.collectionDate)} · {stats.hundi.entries} recorded dates · cumulative {formatINR(stats.hundi.totalRupees)} (sample)</p>
              </div>
            )}
            <div className="card p-6 flex flex-col justify-between gap-4">
              <p className="text-[13px] text-[rgba(244,236,216,0.6)] leading-relaxed">
                Upload a historical scan to walk the full pipeline: enhance → multilingual OCR → human verification →
                link to a property → approve → publish.
              </p>
              <div>
                <Link href="/properties" className="btn btn-ghost btn-sm mr-2">View public portal <ArrowRight size={12} /></Link>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
