"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  CloudUpload,
  FileImage,
  FileText,
  FlaskConical,
  Link2,
  Lock,
  RefreshCw,
  Replace,
  ScanSearch,
  Sparkles,
  TriangleAlert,
  X,
} from "lucide-react";
import { useInstitution } from "@/components/institution-context";
import { DemoTag, EmptyState, Spinner, StatusChip, formatDate } from "@/components/ui";
import type { SessionUser } from "@/lib/auth";
import { DOC_TYPES, ROLE_LABELS, STATUS_LABELS, TRANSITIONS, type Role, type Status } from "@/lib/constants";

type ExtractedField = {
  key: string;
  label: string;
  value: string | null;
  normalized: string | null;
  status: "ok" | "uncertain" | "illegible" | "not_detected";
  confidence: number | null;
  source: "ocr" | "manual";
  note?: string;
};

type Doc = {
  id: string;
  institutionId: string;
  propertyId: string | null;
  title: string;
  docType: string;
  refNo: string | null;
  docDate: string | null;
  status: Status;
  mime: string;
  pageKind: string;
  version: number;
  extracted: ExtractedField[] | null;
  ocr: {
    status: string | null;
    message?: string | null;
    avgConfidence?: number | null;
    words?: number | null;
    imageQuality?: string | null;
    engine?: string | null;
    languages?: string[] | null;
    processedAt?: string | null;
  } | null;
  enhancedPath?: string | null;
  sensitiveNote?: string | null;
  createdAt: string;
};

type PropOption = { id: string; assetCode: string; title: string };

const FIELD_STATUS_STYLE: Record<string, string> = {
  ok: "!border-[rgba(143,160,107,0.55)] !text-[#b7c895]",
  uncertain: "!border-[rgba(232,137,47,0.6)] !text-[var(--color-saffron-2)]",
  illegible: "!border-[rgba(217,93,57,0.6)] !text-[#f2b09d]",
  not_detected: "!border-[rgba(244,236,216,0.25)] !text-[rgba(244,236,216,0.55)]",
};

const FIELD_STATUS_LABEL: Record<string, string> = {
  ok: "legible",
  uncertain: "uncertain",
  illegible: "Illegible — needs manual review",
  not_detected: "Not detected",
};

export default function DocumentsTab({ user }: { user: SessionUser }) {
  const { institutionId } = useInstitution();
  const [docs, setDocs] = useState<Doc[]>([]);
  const [props, setProps] = useState<PropOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [ocrCap, setOcrCap] = useState<{ configured: boolean; notes: string[]; setup: string[]; languages: { lang: string; present: boolean }[] } | null>(null);
  const [active, setActive] = useState<Doc | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const replaceRef = useRef<HTMLInputElement>(null);
  const [uploadForm, setUploadForm] = useState({ title: "", docType: "ror_extract", refNo: "", propertyId: "", docDate: "", sensitiveNote: "" });
  const [busy, setBusy] = useState<"upload" | "ocr" | "save" | "replace" | null>(null);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [fieldsDraft, setFieldsDraft] = useState<ExtractedField[]>([]);
  const [showEnhanced, setShowEnhanced] = useState(false);

  const load = useCallback(() => {
    if (!institutionId) return;
    setLoading(true);
    fetch(`/api/documents?institution=${institutionId}&scope=staff`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setDocs(d?.ok ? d.documents : []))
      .catch(() => setDocs([]))
      .finally(() => setLoading(false));
    fetch(`/api/properties?institution=${institutionId}&scope=staff`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setProps(d?.ok ? d.properties.map((p: PropOption) => ({ id: p.id, assetCode: p.assetCode, title: p.title })) : []))
      .catch(() => {});
  }, [institutionId]);

  useEffect(() => {
    load();
    fetch("/api/ocr/status")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setOcrCap(d?.ok ? d.availability : null))
      .catch(() => setOcrCap(null));
  }, [load]);

  useEffect(() => {
    if (active) {
      setFieldsDraft(active.extracted ?? []);
      setShowEnhanced(false);
      setMessage(null);
    }
  }, [active?.id]);

  const refreshActive = (doc: Doc) => {
    setActive(doc);
    setDocs((prev) => prev.map((d) => (d.id === doc.id ? doc : d)));
  };

  /* ------------------------------ upload ------------------------------ */
  const upload = async (file: File) => {
    setBusy("upload");
    setMessage(null);
    const fd = new FormData();
    fd.set("file", file);
    fd.set("title", uploadForm.title || file.name);
    fd.set("institutionId", institutionId);
    fd.set("docType", uploadForm.docType);
    if (uploadForm.refNo) fd.set("refNo", uploadForm.refNo);
    if (uploadForm.propertyId) fd.set("propertyId", uploadForm.propertyId);
    if (uploadForm.docDate) fd.set("docDate", uploadForm.docDate);
    if (uploadForm.sensitiveNote) fd.set("sensitiveNote", uploadForm.sensitiveNote);
    const res = await fetch("/api/documents", { method: "POST", body: fd });
    const data = await res.json().catch(() => null);
    setBusy(null);
    if (!res.ok || !data?.ok) {
      setMessage({ ok: false, text: data?.message ?? "Upload failed." });
      return;
    }
    setMessage({ ok: true, text: `Stored “${data.document.title}” (v1, draft). Original preserved.` });
    setUploadForm({ title: "", docType: "ror_extract", refNo: "", propertyId: "", docDate: "", sensitiveNote: "" });
    load();
    setActive(data.document);
  };

  /* -------------------------------- OCR -------------------------------- */
  const runOcr = async (doc: Doc) => {
    setBusy("ocr");
    setMessage(null);
    const res = await fetch(`/api/documents/${doc.id}/ocr`, { method: "POST" });
    const data = await res.json().catch(() => null);
    setBusy(null);
    if (!res.ok || !data?.ok) {
      setMessage({ ok: false, text: data?.message ?? "OCR failed — see setup notes." });
      if (data?.document) refreshActive(data.document);
      return;
    }
    setMessage({
      ok: true,
      text: `OCR complete (${data.document.ocr?.words ?? 0} tokens, avg confidence ${data.document.ocr?.avgConfidence ?? "n/a"}). Review every field — nothing auto-publishes.`,
    });
    refreshActive(data.document);
    setFieldsDraft(data.document.extracted ?? []);
  };

  const replaceFile = async (file: File) => {
    if (!active || user.role === "operator") return;
    setBusy("replace");
    const fd = new FormData();
    fd.set("file", file);
    fd.set("note", "Replacement upload from workbench");
    const res = await fetch(`/api/documents/${active.id}`, { method: "PUT", body: fd });
    const data = await res.json().catch(() => null);
    setBusy(null);
    setMessage(res.ok && data?.ok ? { ok: true, text: `Replaced as v${data.document.version}; prior version retained.` } : { ok: false, text: data?.message ?? "Replace failed." });
    if (res.ok && data?.ok) refreshActive(data.document);
  };

  /* --------------------------- verification save --------------------------- */
  const saveFields = async () => {
    if (!active) return;
    setBusy("save");
    const res = await fetch(`/api/documents/${active.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        extracted: fieldsDraft.map((f) => ({ ...f, source: f.source === "ocr" && f.status === "not_detected" && f.value ? "manual" : f.source })),
      }),
    });
    const data = await res.json().catch(() => null);
    setBusy(null);
    setMessage(res.ok && data?.ok ? { ok: true, text: "Corrections saved — original scan untouched." } : { ok: false, text: data?.message ?? "Save failed." });
    if (res.ok && data?.ok) refreshActive(data.document);
  };

  const linkProperty = async (propertyId: string) => {
    if (!active) return;
    const res = await fetch(`/api/documents/${active.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ linkPropertyId: propertyId || null }),
    });
    const data = await res.json().catch(() => null);
    if (res.ok && data?.ok) {
      refreshActive(data.document);
      setMessage({ ok: true, text: propertyId ? "Linked to property record." : "Unlinked." });
    }
  };

  const transition = async (doc: Doc, status: Status) => {
    const res = await fetch(`/api/documents/${doc.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.ok) {
      setMessage({ ok: false, text: data?.message ?? "Transition rejected." });
      return;
    }
    setMessage({ ok: true, text: `Status → ${STATUS_LABELS[status]}.` });
    load();
    if (active?.id === doc.id) refreshActive(data.document);
  };

  const setField = (idx: number, patch: Partial<ExtractedField>) =>
    setFieldsDraft((prev) => prev.map((f, i) => (i === idx ? { ...f, ...patch } : f)));

  const canEditFields = !(user.role === "operator" && active && !["draft", "needs_review"].includes(active.status));

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="eyebrow text-[var(--color-saffron-2)] mb-1">Upload &amp; Extract Land Information</p>
          <h2 className="font-display text-2xl">Historical Document Scanner</h2>
        </div>
        <DemoTag />
      </div>

      {/* capability banner — never simulated */}
      {ocrCap && !ocrCap.configured && (
        <div className="rounded-2xl border border-[rgba(217,93,57,0.5)] bg-[rgba(217,93,57,0.09)] p-5">
          <p className="flex items-center gap-2 font-semibold text-[#f2b09d] text-sm mb-2"><TriangleAlert size={15} /> OCR engine not fully configured in this deployment</p>
          <ul className="list-disc pl-5 space-y-1 text-[12px] text-[rgba(244,236,216,0.65)]">
            {ocrCap.setup.map((s) => <li key={s} className="font-mono break-all">{s}</li>)}
          </ul>
          <p className="text-[11.5px] text-[rgba(244,236,216,0.5)] mt-3">Uploads, manual field entry, linking and the approval workflow remain fully functional — nothing is simulated.</p>
        </div>
      )}
      {ocrCap?.configured && (
        <div className="rounded-2xl border hairline bg-[rgba(244,236,216,0.03)] p-4 flex flex-wrap items-center gap-2">
          <Sparkles size={14} className="text-[#b7c895]" />
          <span className="text-[12.5px] text-[rgba(244,236,216,0.75)]">OCR ready —</span>
          {ocrCap.languages.map((l) => (
            <span key={l.lang} className={`chip ${l.present ? "!border-[rgba(143,160,107,0.6)] !text-[#b7c895]" : "!border-[rgba(217,93,57,0.5)] !text-[#f2b09d]"}`}>{l.lang}</span>
          ))}
          <span className="text-[11px] text-[rgba(244,236,216,0.45)]">Confidence values are indicative; human verification is mandatory before publication.</span>
        </div>
      )}

      {/* upload card */}
      <div className="card p-5">
        <p className="font-display text-lg mb-4 flex items-center gap-2"><CloudUpload size={17} className="text-[var(--color-saffron-2)]" /> Upload scan (PDF / JPG / PNG)</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
          <div>
            <label className="label">Document title</label>
            <input className="input" value={uploadForm.title} onChange={(e) => setUploadForm((f) => ({ ...f, title: e.target.value }))} placeholder="e.g. RoR extract — Old Town khata 241/137" />
          </div>
          <div>
            <label className="label">Document type</label>
            <select className="select" value={uploadForm.docType} onChange={(e) => setUploadForm((f) => ({ ...f, docType: e.target.value }))}>
              {DOC_TYPES.map((d) => <option key={d.id} value={d.id}>{d.label}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Reference no.</label>
            <input className="input" value={uploadForm.refNo} onChange={(e) => setUploadForm((f) => ({ ...f, refNo: e.target.value }))} />
          </div>
          <div>
            <label className="label">Link to property (optional)</label>
            <select className="select" value={uploadForm.propertyId} onChange={(e) => setUploadForm((f) => ({ ...f, propertyId: e.target.value }))}>
              <option value="">— link later —</option>
              {props.map((p) => <option key={p.id} value={p.id}>{p.assetCode} — {p.title}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Document date</label>
            <input type="date" className="input" value={uploadForm.docDate} onChange={(e) => setUploadForm((f) => ({ ...f, docDate: e.target.value }))} />
          </div>
          <div>
            <label className="label">Staff-only note (never public)</label>
            <input className="input" value={uploadForm.sensitiveNote} onChange={(e) => setUploadForm((f) => ({ ...f, sensitiveNote: e.target.value }))} placeholder="Tenant / litigation notes…" />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg,application/pdf"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) upload(f);
              e.target.value = "";
            }}
          />
          <button className="btn btn-primary" onClick={() => fileRef.current?.click()} disabled={busy === "upload"}>
            {busy === "upload" ? <Spinner size={14} /> : <CloudUpload size={14} />} {busy === "upload" ? "Storing securely…" : "Choose file & upload"}
          </button>
          <span className="text-[11px] text-[rgba(244,236,216,0.45)]">Max 15 MB · stored in private storage · drafts are invisible publicly</span>
        </div>
        {message && (
          <p className={`mt-3 text-[12.5px] rounded-lg px-3 py-2 border ${message.ok ? "border-[rgba(143,160,107,0.5)] bg-[rgba(143,160,107,0.08)] text-[#c8d6ad]" : "border-[rgba(217,93,57,0.5)] bg-[rgba(217,93,57,0.09)] text-[#f2b09d]"}`}>
            {message.text}
          </p>
        )}
      </div>

      {/* register + workbench */}
      <div className="grid lg:grid-cols-[320px_1fr] gap-4 items-start">
        <div className="card p-3.5 max-h-[76vh] overflow-y-auto">
          <p className="label px-1 mb-2">Document register ({docs.length})</p>
          {loading ? (
            <div className="flex justify-center py-10"><Spinner /></div>
          ) : docs.length === 0 ? (
            <EmptyState icon={FileText} title="No documents" message="Upload the first historical scan above." />
          ) : (
            <ul className="space-y-2">
              {docs.map((d) => (
                <li key={d.id}>
                  <button
                    onClick={() => setActive(d)}
                    className={`w-full text-left rounded-xl border p-3 transition-colors ${active?.id === d.id ? "border-[rgba(232,137,47,0.6)] bg-[rgba(232,137,47,0.08)]" : "hairline hover:bg-[rgba(244,236,216,0.05)]"}`}
                  >
                    <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                      <StatusChip status={d.status} />
                      <span className="chip">v{d.version}</span>
                      <span className="chip">{d.pageKind === "pdf" ? "PDF" : "IMG"}</span>
                    </div>
                    <p className="text-[13px] font-semibold leading-snug">{d.title}</p>
                    <p className="text-[10.5px] text-[rgba(244,236,216,0.45)] mt-1">
                      {d.ocr?.status === "done" ? `OCR ✓ conf ${d.ocr.avgConfidence ?? "—"}` : `OCR: ${d.ocr?.status ?? "pending"}`}
                      {d.propertyId ? " · linked" : " · unlinked"}
                    </p>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* workbench */}
        {!active ? (
          <div className="card"><EmptyState icon={ScanSearch} title="Select a document" message="Pick a document from the register to enhance, OCR, verify, link and publish." /></div>
        ) : (
          <div className="card p-5 space-y-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <StatusChip status={active.status} />
                  <span className="chip">v{active.version}</span>
                  {active.ocr?.imageQuality && <span className="chip">scan quality: {active.ocr.imageQuality}</span>}
                </div>
                <h3 className="font-display text-xl">{active.title}</h3>
                <p className="text-[11.5px] text-[rgba(244,236,216,0.5)] mt-1">{createdStamp(active)}</p>
              </div>
              <button className="btn-ghost btn btn-sm !px-2.5" onClick={() => setActive(null)}><X size={14} /></button>
            </div>

            {active.ocr?.message && (
              <p className={`text-[12px] rounded-lg border px-3 py-2 flex items-start gap-2 ${active.ocr.status === "done" ? "border-[rgba(143,160,107,0.45)] bg-[rgba(143,160,107,0.07)]" : "border-[rgba(232,137,47,0.45)] bg-[rgba(232,137,47,0.07)]"}`}>
                <FlaskConical size={13} className="mt-0.5 shrink-0" /> {active.ocr.message}
              </p>
            )}

            <div className="grid xl:grid-cols-2 gap-5">
              {/* scan pane */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="label !mb-0">Scan inspection</p>
                  {active.enhancedPath && (
                    <div className="flex gap-1">
                      <button className={`btn btn-ghost btn-sm !text-[10px] ${!showEnhanced ? "!bg-[rgba(232,137,47,0.18)]" : ""}`} onClick={() => setShowEnhanced(false)}>Original</button>
                      <button className={`btn btn-ghost btn-sm !text-[10px] ${showEnhanced ? "!bg-[rgba(232,137,47,0.18)]" : ""}`} onClick={() => setShowEnhanced(true)}>Enhanced</button>
                    </div>
                  )}
                </div>
                <div className="rounded-xl overflow-hidden border hairline bg-black/40 min-h-[300px] flex items-center justify-center">
                  {active.pageKind === "pdf" ? (
                    <div className="p-6 text-center text-[12px] text-[rgba(244,236,216,0.55)]">
                      <FileText size={22} className="mx-auto mb-2 text-[rgba(244,236,216,0.4)]" />
                      PDF preview opens in a new tab. Page-image extraction is unavailable in this environment (no poppler/ghostscript).
                      <div><a className="btn btn-ghost btn-sm mt-3" href={`/api/documents/${active.id}/file`} target="_blank" rel="noreferrer">Open PDF</a></div>
                    </div>
                  ) : (
                    <a href={`/api/documents/${active.id}/file${showEnhanced ? "?kind=enhanced" : ""}`} target="_blank" rel="noreferrer">
                      <img src={`/api/documents/${active.id}/file${showEnhanced ? "?kind=enhanced" : ""}`} alt={active.title} className="w-full max-h-[460px] object-contain" />
                    </a>
                  )}
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  <button className="btn btn-primary btn-sm" onClick={() => runOcr(active)} disabled={busy === "ocr" || active.pageKind === "pdf"}>
                    {busy === "ocr" ? <Spinner size={13} /> : <ScanSearch size={13} />}
                    {busy === "ocr" ? "Enhancing & extracting… (can take ~20s)" : active.ocr?.status === "done" ? "Re-run OCR" : "Enhance image & extract text"}
                  </button>
                  {user.role !== "operator" && (
                    <>
                      <input
                        ref={replaceRef}
                        type="file"
                        accept="image/png,image/jpeg,application/pdf"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) replaceFile(f);
                          e.target.value = "";
                        }}
                      />
                      <button className="btn btn-ghost btn-sm" onClick={() => replaceRef.current?.click()} disabled={busy === "replace"}>
                        {busy === "replace" ? <Spinner size={13} /> : <Replace size={13} />} Replace file (new version)
                      </button>
                    </>
                  )}
                </div>
                <p className="text-[10.5px] text-[rgba(244,236,216,0.45)] mt-2 leading-relaxed">
                  Enhancement (grayscale · contrast stretch · denoise) writes a separate derivative — the uploaded original is
                  never altered. Supports skew/fade/stains as best-effort; handwritten cursive and damaged type will surface
                  as uncertain or illegible.
                </p>
              </div>

              {/* fields pane */}
              <div>
                <div className="flex items-center justify-between mb-2 gap-2">
                  <p className="label !mb-0">Extracted fields — human verification</p>
                  {!canEditFields && <span className="chip"><Lock size={10} /> view only</span>}
                </div>
                {fieldsDraft.length === 0 ? (
                  <div className="rounded-xl border hairline p-4 text-[12.5px] text-[rgba(244,236,216,0.55)] space-y-2">
                    <p>No extracted fields yet.</p>
                    <ol className="list-decimal pl-4 space-y-1 text-[11.5px]">
                      <li>Run OCR on a legible image scan, or</li>
                      <li>Add fields manually below — entries marked <em>Not detected</em> never appear on the public portal as fabricated values.</li>
                    </ol>
                    <button
                      className="btn btn-ghost btn-sm mt-2"
                      onClick={() =>
                        setFieldsDraft(defaultFields())
                      }
                    >
                      <FileImage size={12} /> Start manual entry from template
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-[400px] overflow-y-auto pr-1">
                    {fieldsDraft.map((f, idx) => (
                      <div key={f.key + idx} className={`rounded-xl border p-3 bg-[rgba(244,236,216,0.02)] ${FIELD_STATUS_STYLE[f.status].split(" ")[0]}`}>
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <span className="text-[10.5px] font-bold uppercase tracking-[0.12em] text-[rgba(244,236,216,0.6)]">{f.label}</span>
                          <span className={`chip !text-[9.5px] ${FIELD_STATUS_STYLE[f.status]}`}>
                            {FIELD_STATUS_LABEL[f.status]}{f.confidence !== null && f.confidence !== undefined ? ` · ${f.confidence}%` : ""}{f.source === "manual" ? " · manual" : ""}
                          </span>
                        </div>
                        <input
                          className="input !bg-[rgba(19,16,11,0.4)]"
                          value={f.value ?? ""}
                          disabled={!canEditFields}
                          placeholder={f.status === "not_detected" ? "Not detected — enter manually if legible on scan" : ""}
                          onChange={(e) => {
                            const v = e.target.value;
                            setField(idx, {
                              value: v === "" ? null : v,
                              status: v === "" ? (f.status === "not_detected" ? "not_detected" : "illegible") : f.status === "not_detected" || f.status === "illegible" ? "ok" : f.status,
                              source: "manual",
                            });
                          }}
                        />
                        {f.normalized && <p className="text-[10.5px] text-[rgba(244,236,216,0.5)] mt-1.5">Normalised: {f.normalized}</p>}
                        {f.note && <p className="text-[10px] text-[rgba(244,236,216,0.4)] mt-1">{f.note}</p>}
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex flex-wrap gap-2 mt-3">
                  {fieldsDraft.length > 0 && (
                    <button className="btn btn-primary btn-sm" onClick={saveFields} disabled={busy === "save" || !canEditFields}>
                      {busy === "save" ? <Spinner size={13} /> : <RefreshCw size={13} />} Save corrections
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* linking + workflow */}
            <div className="flex flex-wrap items-end gap-3 border-t hairline pt-4">
              <div className="grow max-w-md">
                <label className="label flex items-center gap-1.5"><Link2 size={11} /> Link to cadastral property</label>
                <select className="select" value={active.propertyId ?? ""} onChange={(e) => linkProperty(e.target.value)}>
                  <option value="">— not linked —</option>
                  {props.map((p) => <option key={p.id} value={p.id}>{p.assetCode} — {p.title}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Workflow ({ROLE_LABELS[user.role]})</label>
                <div className="flex flex-wrap gap-1.5">
                  {(TRANSITIONS[user.role as Role][active.status] ?? []).map((t) => (
                    <button key={t} className="btn btn-ghost btn-sm" onClick={() => transition(active, t)}>
                      → {STATUS_LABELS[t]}
                    </button>
                  ))}
                  {(TRANSITIONS[user.role as Role][active.status] ?? []).length === 0 && (
                    <span className="text-[11px] text-[rgba(244,236,216,0.4)] flex items-center gap-1.5"><Lock size={11} /> no transitions available for your role at this state</span>
                  )}
                </div>
              </div>
            </div>
            <p className="text-[10.5px] text-[rgba(244,236,216,0.45)] leading-relaxed">
              OCR output never becomes a published record automatically — extraction feeds the verification workbench,
              and publication requires the role-gated workflow above. Tenant/litigation notes stay staff-only and are
              redacted from public payloads.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function createdStamp(d: Doc) {
  return `Uploaded ${formatDate(d.createdAt)} · ${d.docType.replace(/_/g, " ")}${d.refNo ? ` · Ref ${d.refNo}` : ""}${d.docDate ? ` · Dated ${formatDate(d.docDate)}` : ""}`;
}

function defaultFields(): ExtractedField[] {
  const mk = (key: string, label: string): ExtractedField => ({
    key,
    label,
    value: null,
    normalized: null,
    status: "not_detected",
    confidence: null,
    source: "manual",
  });
  return [
    mk("institution", "Institution / Deity"),
    mk("district", "District"),
    mk("tahasil", "Tahasil"),
    mk("mouza", "Mouza / Village"),
    mk("khataNo", "Khata No."),
    mk("plotNo", "Plot No."),
    mk("area", "Area (as recorded)"),
    mk("landClass", "Land Classification (Kisam)"),
    mk("docDate", "Record Date / Year"),
    mk("refNo", "Document Reference No."),
  ];
}
