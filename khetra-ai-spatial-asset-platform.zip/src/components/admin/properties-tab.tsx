"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Archive, ArchiveRestore, ChevronRight, Lock, Pencil, Plus, Search, X } from "lucide-react";
import { useInstitution } from "@/components/institution-context";
import { DemoTag, EmptyState, Spinner, StatusChip, formatDate } from "@/components/ui";
import type { SessionUser } from "@/lib/auth";
import { STATUSES, STATUS_LABELS, TRANSITIONS, type Status, type Role } from "@/lib/constants";

type Prop = {
  id: string;
  assetCode: string;
  institutionId: string;
  assetType: string;
  title: string;
  description: string | null;
  district: string;
  tahasil: string;
  mouza: string;
  khataNo: string | null;
  plotNo: string | null;
  landClass: string | null;
  areaOriginal: string | null;
  areaUnit: string | null;
  areaAcres: number | null;
  docDate: string | null;
  docRef: string | null;
  lat: number | null;
  lng: number | null;
  status: Status;
  archived: boolean;
  reportedConcern: boolean;
  concernNote: string | null;
  sampleData: boolean;
};

const BLANK = {
  title: "", assetType: "land", district: "", tahasil: "", mouza: "", khataNo: "", plotNo: "",
  landClass: "", areaOriginal: "", areaUnit: "", areaAcres: "", docDate: "", docRef: "",
  description: "", lat: "", lng: "", reportedConcern: false, concernNote: "",
};

export default function PropertiesTab({ user }: { user: SessionUser }) {
  const { institutionId, institutions } = useInstitution();
  const [rows, setRows] = useState<Prop[]>([]);
  const [loading, setLoading] = useState(true);
  const [showArchived, setShowArchived] = useState(false);
  const [statusFilter, setStatusFilter] = useState("");
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState<Prop | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState(BLANK);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(() => {
    if (!institutionId) return;
    setLoading(true);
    const params = new URLSearchParams({ institution: institutionId, scope: "staff" });
    if (showArchived) params.set("archived", "true");
    fetch(`/api/properties?${params}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setRows(d?.ok ? d.properties : []))
      .catch(() => setRows([]))
      .finally(() => setLoading(false));
  }, [institutionId, showArchived]);

  useEffect(load, [load]);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return rows.filter((r) => {
      if (statusFilter && r.status !== statusFilter) return false;
      if (needle && ![r.title, r.assetCode, r.khataNo, r.plotNo, r.mouza].filter(Boolean).join(" ").toLowerCase().includes(needle)) return false;
      return true;
    });
  }, [rows, statusFilter, q]);

  const mutate = async (id: string, payload: Record<string, unknown>) => {
    setBusy(true);
    setNotice(null);
    const res = await fetch(`/api/properties/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => null);
    setBusy(false);
    if (!res.ok || !data?.ok) {
      setNotice(data?.message ?? "Action rejected by the server.");
      return false;
    }
    setNotice("Saved. Audit trail updated.");
    load();
    return true;
  };

  const saveEdit = async () => {
    if (!editing) return;
    const ok = await mutate(editing.id, {
      ...form,
      areaAcres: form.areaAcres === "" ? null : Number(form.areaAcres),
      lat: form.lat === "" ? null : Number(form.lat),
      lng: form.lng === "" ? null : Number(form.lng),
    });
    if (ok) {
      setEditing(null);
      setCreating(false);
    }
  };

  const saveCreate = async () => {
    setBusy(true);
    setNotice(null);
    const res = await fetch(`/api/properties`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        institutionId,
        areaAcres: form.areaAcres === "" ? null : Number(form.areaAcres),
        lat: form.lat === "" ? null : Number(form.lat),
        lng: form.lng === "" ? null : Number(form.lng),
      }),
    });
    const data = await res.json().catch(() => null);
    setBusy(false);
    if (!res.ok || !data?.ok) {
      setNotice(data?.message ?? "Create failed.");
      return;
    }
    setNotice(`Draft ${data.property.assetCode} created.`);
    setCreating(false);
    setEditing(null);
    setForm(BLANK);
    load();
  };

  const openEditor = (p?: Prop) => {
    if (p) {
      setEditing(p);
      setCreating(false);
      setForm({
        title: p.title, assetType: p.assetType, district: p.district, tahasil: p.tahasil, mouza: p.mouza,
        khataNo: p.khataNo ?? "", plotNo: p.plotNo ?? "", landClass: p.landClass ?? "",
        areaOriginal: p.areaOriginal ?? "", areaUnit: p.areaUnit ?? "",
        areaAcres: p.areaAcres !== null ? String(p.areaAcres) : "", docDate: p.docDate ?? "", docRef: p.docRef ?? "",
        description: p.description ?? "", lat: p.lat !== null ? String(p.lat) : "", lng: p.lng !== null ? String(p.lng) : "",
        reportedConcern: p.reportedConcern, concernNote: p.concernNote ?? "",
      });
    } else {
      setEditing(null);
      setCreating(true);
      setForm(BLANK);
    }
  };

  const field = (k: keyof typeof BLANK, label: string, opts?: { placeholder?: string; type?: string }) => (
    <div>
      <label className="label">{label}</label>
      <input
        className="input"
        type={opts?.type ?? "text"}
        placeholder={opts?.placeholder}
        value={String(form[k])}
        onChange={(e) => setForm((f) => ({ ...f, [k]: e.target.value }))}
      />
    </div>
  );

  const editorOpen = creating || editing !== null;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="eyebrow text-[var(--color-saffron-2)] mb-1">Asset Records</p>
          <h2 className="font-display text-2xl">Manage demonstration records</h2>
        </div>
        <div className="flex items-center gap-2">
          <DemoTag />
          <button className="btn btn-primary btn-sm" onClick={() => openEditor()}><Plus size={13} /> New record</button>
        </div>
      </div>

      {notice && <p className="text-[12.5px] border hairline rounded-lg px-3 py-2 bg-[rgba(244,236,216,0.04)]">{notice}</p>}

      <div className="card p-3.5 flex flex-wrap items-end gap-3">
        <div className="grow max-w-xs min-w-[180px]">
          <label className="label">Search</label>
          <div className="relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[rgba(244,236,216,0.35)]" />
            <input className="input !pl-8" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Title / ID / khata / plot…" />
          </div>
        </div>
        <div>
          <label className="label">Status</label>
          <select className="select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="">All statuses</option>
            {STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
          </select>
        </div>
        <label className="flex items-center gap-2 text-[12px] text-[rgba(244,236,216,0.6)] mb-2">
          <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} className="accent-[#e8892f]" />
          Show archived
        </label>
      </div>

      <div className="table-shell overflow-x-auto">
        <table className="min-w-[1020px]">
          <thead>
            <tr><th>Record</th><th>Location</th><th>Khata/Plot</th><th>Area</th><th>Status</th><th>Workflow</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-10"><Spinner className="inline" /></td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={7}><EmptyState icon={Archive} title="No records" message="Create the first draft record for this institution." /></td></tr>
            ) : (
              filtered.map((p) => {
                const allowed = p.archived ? [] : (TRANSITIONS[user.role as Role][p.status] ?? []);
                return (
                  <tr key={p.id} className={p.archived ? "opacity-55" : ""}>
                    <td>
                      <span className="font-mono text-[11px] text-[var(--color-saffron-2)]">{p.assetCode}</span><br />
                      <span className="text-[13px] font-semibold">{p.title}</span>
                      {p.reportedConcern && <span className="chip !border-[rgba(217,93,57,0.5)] !text-[#f2b09d] ml-2">concern</span>}
                    </td>
                    <td className="text-[12px]">{p.mouza} · {p.tahasil} · {p.district}</td>
                    <td className="font-mono text-[11.5px]">{p.khataNo ?? "—"} / {p.plotNo ?? "—"}</td>
                    <td className="text-[12px]">{p.areaOriginal ?? (p.areaAcres != null ? `${p.areaAcres} ac` : "—")}</td>
                    <td><StatusChip status={p.archived ? "draft" : p.status} />{p.archived && <span className="chip ml-1">archived</span>}</td>
                    <td>
                      {allowed.length ? (
                        <div className="flex flex-wrap gap-1">
                          {allowed.map((t) => (
                            <button key={t} disabled={busy} onClick={() => mutate(p.id, { status: t })} className="btn btn-ghost btn-sm !px-2 !text-[10.5px]">
                              {STATUS_LABELS[t]} <ChevronRight size={9} />
                            </button>
                          ))}
                        </div>
                      ) : (
                        <span className="text-[10.5px] text-[rgba(244,236,216,0.35)] flex items-center gap-1"><Lock size={9} /> no moves for this role</span>
                      )}
                    </td>
                    <td>
                      <div className="flex gap-1.5">
                        <button className="btn btn-ghost btn-sm !px-2" onClick={() => openEditor(p)} aria-label="Edit" disabled={p.archived}><Pencil size={12} /></button>
                        {user.role === "admin" &&
                          (p.archived ? (
                            <button className="btn btn-ghost btn-sm !px-2" disabled={busy} onClick={() => mutate(p.id, { archived: false })} aria-label="Restore"><ArchiveRestore size={12} /></button>
                          ) : (
                            <button className="btn btn-danger btn-sm !px-2" disabled={busy} onClick={() => mutate(p.id, { archived: true })} aria-label="Archive"><Archive size={12} /></button>
                          ))}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {editorOpen && (
        <div className="fixed inset-0 z-[88] flex justify-end">
          <div className="absolute inset-0 bg-[rgba(10,8,5,0.6)]" onClick={() => { setEditing(null); setCreating(false); }} />
          <aside className="relative w-full max-w-2xl h-full bg-[var(--color-ink-2)] border-l hairline overflow-y-auto p-6">
            <div className="flex items-start justify-between mb-5">
              <div>
                <p className="eyebrow text-[var(--color-saffron-2)] !text-[10px] mb-1">{creating ? "New draft record" : `Editing ${editing?.assetCode}`}</p>
                <h3 className="font-display text-xl">{creating ? "Create asset record" : editing?.title}</h3>
                {creating && <p className="text-[11px] text-[rgba(244,236,216,0.5)] mt-1">Institution: {institutions.find((i) => i.id === institutionId)?.name}</p>}
              </div>
              <button className="btn-ghost btn btn-sm !px-2.5" onClick={() => { setEditing(null); setCreating(false); }}><X size={14} /></button>
            </div>
            <div className="grid sm:grid-cols-2 gap-3.5">
              <div className="sm:col-span-2">{field("title", "Record title")}</div>
              <div>
                <label className="label">Asset type</label>
                <select className="select" value={form.assetType} onChange={(e) => setForm((f) => ({ ...f, assetType: e.target.value }))}>
                  <option value="land">Land</option><option value="building">Building</option><option value="other">Other property</option>
                </select>
              </div>
              {field("district", "District")}
              {field("tahasil", "Tahasil")}
              {field("mouza", "Mouza / Village")}
              {field("khataNo", "Khata No.")}
              {field("plotNo", "Plot No.")}
              {field("landClass", "Land classification (Kisam)")}
              {field("areaOriginal", "Area — original unit", { placeholder: "e.g. 2 Acres 35 Decimals / 14 Guntha 9 Mana" })}
              {field("areaUnit", "Original unit label", { placeholder: "Acres & Decimals / Guntha & Mana" })}
              {field("areaAcres", "Normalised acres (indicative)")}
              {field("docDate", "Record date", { type: "date" })}
              {field("docRef", "Source document reference")}
              {field("lat", "Illustrative centroid — latitude", { placeholder: "20.2380" })}
              {field("lng", "Illustrative centroid — longitude", { placeholder: "85.8410" })}
              <div className="sm:col-span-2">
                <label className="label">Notes (public-safe)</label>
                <textarea className="input min-h-[70px]" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
              </div>
              <label className="flex items-center gap-2 text-[12px] text-[rgba(244,236,216,0.65)] sm:col-span-2">
                <input type="checkbox" className="accent-[#e8892f]" checked={form.reportedConcern} onChange={(e) => setForm((f) => ({ ...f, reportedConcern: e.target.checked }))} />
                Mark as fictional “Reported concern — not legally determined”
              </label>
              {form.reportedConcern && (
                <div className="sm:col-span-2">{field("concernNote", "Concern note (fictional, no real individuals)")}</div>
              )}
            </div>
            <p className="text-[10.5px] text-[rgba(244,236,216,0.45)] mt-4 leading-relaxed">
              Providing a centroid auto-generates an illustrative parcel outline for the map. All records are flagged as
              sample data.
            </p>
            <div className="flex gap-2 mt-5">
              <button className="btn btn-primary" onClick={creating ? saveCreate : saveEdit} disabled={busy || !form.title || !form.district || !form.tahasil || !form.mouza}>
                {busy ? <Spinner size={14} /> : <Plus size={14} />} {creating ? "Create draft" : "Save changes"}
              </button>
              <button className="btn btn-ghost" onClick={() => { setEditing(null); setCreating(false); }}>Cancel</button>
            </div>
            {editing && <p className="mt-4 text-[11px] text-[rgba(244,236,216,0.45)]">Current status: <StatusChip status={editing.status} /> — use workflow buttons in the table to transition.</p>}
          </aside>
        </div>
      )}
    </div>
  );
}
