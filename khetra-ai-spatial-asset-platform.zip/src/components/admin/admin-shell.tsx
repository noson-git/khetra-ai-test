"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Gauge,
  Archive,
  FileScan,
  Coins,
  ScrollText,
  HeartPulse,
  LogOut,
  BadgeCheck,
} from "lucide-react";
import SiteHeader from "@/components/site-header";
import { DemoTag } from "@/components/ui";
import { ROLE_LABELS, type Role } from "@/lib/constants";
import type { SessionUser } from "@/lib/auth";
import OverviewTab from "./overview-tab";
import PropertiesTab from "./properties-tab";
import DocumentsTab from "./documents-tab";
import HundiTab from "./hundi-tab";
import { AuditTab, SystemTab } from "./misc-tabs";

type TabId = "overview" | "properties" | "documents" | "hundi" | "audit" | "system";

const TABS: { id: TabId; label: string; icon: typeof Gauge; roles: Role[] }[] = [
  { id: "overview", label: "Overview", icon: Gauge, roles: ["admin", "reviewer", "operator"] },
  { id: "properties", label: "Asset Records", icon: Archive, roles: ["admin", "reviewer", "operator"] },
  { id: "documents", label: "Documents & OCR", icon: FileScan, roles: ["admin", "reviewer", "operator"] },
  { id: "hundi", label: "Dana Hundi Ledger", icon: Coins, roles: ["admin", "reviewer", "operator"] },
  { id: "audit", label: "Audit Trail", icon: ScrollText, roles: ["admin", "reviewer", "operator"] },
  { id: "system", label: "System", icon: HeartPulse, roles: ["admin"] },
];

export default function AdminShell({ user }: { user: SessionUser }) {
  const router = useRouter();
  const visible = TABS.filter((t) => t.roles.includes(user.role));
  const [tab, setTab] = useState<TabId>("overview");
  const active = visible.some((t) => t.id === tab) ? tab : "overview";

  const signOut = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <div className="border-b hairline bg-[rgba(19,16,11,0.55)]">
        <div className="mx-auto max-w-7xl px-4 md:px-6 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl border hairline flex items-center justify-center text-[var(--color-saffron-2)] bg-[rgba(232,137,47,0.08)]">
              <BadgeCheck size={18} />
            </span>
            <div>
              <h1 className="font-display text-xl leading-tight">Administration Console</h1>
              <p className="text-[11.5px] text-[rgba(244,236,216,0.5)]">
                {user.displayName} · <span className="text-[var(--color-saffron-2)] font-semibold">{ROLE_LABELS[user.role]}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <DemoTag />
            <button onClick={signOut} className="btn btn-ghost btn-sm"><LogOut size={13} /> Sign out</button>
          </div>
        </div>
        <div className="mx-auto max-w-7xl px-4 md:px-6 pb-3 flex gap-1.5 overflow-x-auto">
          {visible.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 rounded-full px-4 py-2 text-[12.5px] font-semibold whitespace-nowrap transition-colors ${
                active === t.id
                  ? "bg-[rgba(232,137,47,0.22)] text-[var(--color-saffron-2)]"
                  : "text-[rgba(244,236,216,0.6)] hover:bg-[rgba(244,236,216,0.07)]"
              }`}
            >
              <t.icon size={13} /> {t.label}
            </button>
          ))}
        </div>
      </div>
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 md:px-6 py-7">
        {active === "overview" && <OverviewTab user={user} />}
        {active === "properties" && <PropertiesTab user={user} />}
        {active === "documents" && <DocumentsTab user={user} />}
        {active === "hundi" && <HundiTab user={user} />}
        {active === "audit" && <AuditTab />}
        {active === "system" && user.role === "admin" && <SystemTab />}
      </main>
    </div>
  );
}
