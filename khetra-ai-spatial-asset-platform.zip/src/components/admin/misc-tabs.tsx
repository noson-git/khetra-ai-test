"use client";

import { useCallback, useEffect, useState } from "react";
import { CheckCircle2, HeartPulse, ScrollText, TriangleAlert, XCircle } from "lucide-react";
import { Spinner, formatDate } from "@/components/ui";

type AuditEntry = {
  id: string;
  userName: string | null;
  userRole: string | null;
  action: string;
  entity: string;
  entityId: string | null;
  summary: string;
  createdAt: string;
};

export function AuditTab() {
  const [entries, setEntries] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [entity, setEntity] = useState("");

  const load = useCallback(() => {
    setLoading(true);
    const params = entity ? `?entity=${entity}` : "";
    fetch(`/api/audit${params}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setEntries(d?.ok ? d.entries : []))
      .catch(() => setEntries([]))
      .finally(() => setLoading(false));
  }, [entity]);

  useEffect(load, [load]);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="eyebrow text-[var(--color-saffron-2)] mb-1">Audit Trail</p>
          <h2 className="font-display text-2xl">Who changed what, and when</h2>
        </div>
        <div>
          <label className="label">Entity filter</label>
          <select className="select" value={entity} onChange={(e) => setEntity(e.target.value)}>
            <option value="">All entities</option>
            <option value="property">Asset records</option>
            <option value="document">Documents</option>
            <option value="hundi">Hundi ledger</option>
            <option value="session">Sessions</option>
            <option value="system">System</option>
          </select>
        </div>
      </div>
      <div className="table-shell">
        <table className="min-w-[760px]">
          <thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Entity</th><th>Summary</th></tr></thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={5} className="text-center py-10"><Spinner className="inline" /></td></tr>
            ) : (
              entries.map((e) => (
                <tr key={e.id}>
                  <td className="whitespace-nowrap text-[12px]">{new Date(e.createdAt).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}</td>
                  <td className="text-[12px]">{e.userName ?? "system"}<span className="block text-[10px] text-[rgba(244,236,216,0.4)]">{e.userRole}</span></td>
                  <td><span className="chip">{e.action}</span></td>
                  <td className="capitalize text-[12px]">{e.entity}</td>
                  <td className="text-[12.5px]">{e.summary}</td>
                </tr>
              ))
            )}
            {!loading && !entries.length && (
              <tr><td colSpan={5} className="text-center py-10 text-sm text-[rgba(244,236,216,0.5)]">No audit entries yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

type SystemStatus = {
  database: { connected: boolean; engine: string; counts: Record<string, number> };
  ocr: {
    configured: boolean;
    engine: string | null;
    languages: { lang: string; present: boolean }[];
    pdfRasterisation: boolean;
    notes: string[];
    setup: string[];
  };
  storage: { root: string; note: string };
  environment: Record<string, string | null>;
};

export function SystemTab() {
  const [data, setData] = useState<SystemStatus | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetch("/api/system/status")
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => setData(d))
      .catch(() => setError(true));
  }, []);

  if (error) return <p className="text-sm text-[#f2b09d]">Diagnostics are available to Administrators only.</p>;
  if (!data) return <div className="flex justify-center py-16"><Spinner /></div>;

  return (
    <div className="space-y-5">
      <div>
        <p className="eyebrow text-[var(--color-saffron-2)] mb-1">Diagnostics</p>
        <h2 className="font-display text-2xl flex items-center gap-2"><HeartPulse size={20} className="text-[var(--color-saffron-2)]" /> System status</h2>
        <p className="text-[12px] text-[rgba(244,236,216,0.5)] mt-1">Honest capability reporting — no simulated integrations. Checked {formatDate(new Date().toISOString())}.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="card p-5">
          <p className="label mb-3">Database</p>
          <p className="text-sm flex items-center gap-2 mb-3">{data.database.connected ? <CheckCircle2 size={15} className="text-[#b7c895]" /> : <XCircle size={15} className="text-[#f2b09d]" />} {data.database.engine}</p>
          <div className="grid grid-cols-3 gap-2">
            {Object.entries(data.database.counts).map(([k, v]) => (
              <div key={k} className="rounded-lg border hairline p-2.5 text-center">
                <p className="font-display text-xl">{v}</p>
                <p className="text-[9.5px] uppercase tracking-[0.12em] text-[rgba(244,236,216,0.45)]">{k}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <p className="label mb-3">OCR engine</p>
          <p className="text-sm flex items-center gap-2 mb-3">
            {data.ocr.configured ? <CheckCircle2 size={15} className="text-[#b7c895]" /> : <TriangleAlert size={15} className="text-[var(--color-saffron-2)]" />}
            {data.ocr.configured ? `Configured — ${data.ocr.engine}` : "Not fully configured"}
          </p>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {data.ocr.languages.map((l) => (
              <span key={l.lang} className={`chip ${l.present ? "!border-[rgba(143,160,107,0.6)] !text-[#b7c895]" : "!border-[rgba(217,93,57,0.5)] !text-[#f2b09d]"}`}>
                {l.lang} {l.present ? "present" : "missing"}
              </span>
            ))}
            <span className={`chip ${data.ocr.pdfRasterisation ? "" : "!border-[rgba(217,93,57,0.5)] !text-[#f2b09d]"}`}>
              PDF rasterisation: {data.ocr.pdfRasterisation ? "available" : "unavailable"}
            </span>
          </div>
          <ul className="space-y-1.5 text-[11.5px] text-[rgba(244,236,216,0.55)] leading-relaxed list-disc pl-4">
            {data.ocr.notes.map((n) => <li key={n}>{n}</li>)}
          </ul>
          {data.ocr.setup.length > 0 && (
            <div className="mt-3 rounded-lg border border-[rgba(232,137,47,0.4)] bg-[rgba(232,137,47,0.07)] p-3">
              <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-[var(--color-saffron-2)] mb-1.5">Setup required</p>
              <ul className="space-y-1 text-[11px] text-[rgba(244,236,216,0.65)] font-mono break-all">
                {data.ocr.setup.map((s) => <li key={s}>· {s}</li>)}
              </ul>
            </div>
          )}
        </div>

        <div className="card p-5">
          <p className="label mb-3">Private document storage</p>
          <p className="text-[12px] font-mono break-all text-[rgba(244,236,216,0.7)]">{data.storage.root}</p>
          <p className="text-[11.5px] text-[rgba(244,236,216,0.5)] mt-2">{data.storage.note}</p>
        </div>

        <div className="card p-5">
          <p className="label mb-3">Environment</p>
          <dl className="space-y-2 text-[12px]">
            {Object.entries(data.environment).map(([k, v]) => (
              <div key={k} className="flex justify-between gap-3">
                <dt className="text-[rgba(244,236,216,0.5)]">{k}</dt>
                <dd className="font-mono text-[11px] text-right">{String(v)}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}

export function ScrollTextIcon() {
  return <ScrollText size={16} />;
}
