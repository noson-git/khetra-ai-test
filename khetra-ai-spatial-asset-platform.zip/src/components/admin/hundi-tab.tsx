"use client";

import { useCallback, useEffect, useState } from "react";
import { Coins, Plus, Pencil, Trash2, Lock } from "lucide-react";
import { useInstitution } from "@/components/institution-context";
import { DemoTag, EmptyState, Spinner, formatDate, formatINR } from "@/components/ui";
import type { SessionUser } from "@/lib/auth";

type Entry = {
  id: string;
  collectionDate: string;
  cashRupees: number;
  draftRupees: number;
  totalRupees: number;
  committeeNote: string | null;
  sourceRef: string | null;
};

const emptyForm = { collectionDate: "", cashRupees: "", draftRupees: "", committeeNote: "", sourceRef: "" };

export default function HundiTab({ user }: { user: SessionUser }) {
  const { institution, institutionId } = useInstitution();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const isAdmin = user.role === "admin";

  const load = useCallback(() => {
    if (!institutionId) return;
    setLoading(true);
    fetch(`/api/hundi?institution=${institutionId}`)
      .then((r) => r.json())
      .then((d) => setEntries(d?.ok ? d.entries : []))
      .catch(() => setEntries([]))
      .finally(() => setLoading(false));
  }, [institutionId]);

  useEffect(load, [load]);

  const set = (k: keyof typeof emptyForm) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async () => {
    if (!isAdmin) return;
    setBusy(true);
    setMessage(null);
    const payload = {
      institutionId,
      collectionDate: form.collectionDate,
      cashRupees: Number(form.cashRupees || 0),
      draftRupees: Number(form.draftRupees || 0),
      committeeNote: form.committeeNote || null,
      sourceRef: form.sourceRef || null,
    };
    const res = editingId
      ? await fetch(`/api/hundi/${editingId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })
      : await fetch(`/api/hundi`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const data = await res.json().catch(() => null);
    setBusy(false);
    if (!res.ok || !data?.ok) {
      setMessage({ ok: false, text: data?.message ?? "Save failed." });
      return;
    }
    setMessage({ ok: true, text: editingId ? "Entry corrected and audited." : "Collection entry recorded." });
    setForm(emptyForm);
    setEditingId(null);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this collection entry? The deletion is recorded in the audit trail.")) return;
    const res = await fetch(`/api/hundi/${id}`, { method: "DELETE" });
    if (res.ok) load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="eyebrow text-[var(--color-saffron-2)] mb-1">Dana Hundi Ledger</p>
          <h2 className="font-display text-2xl">{institution?.name ?? "—"}</h2>
          <p className="text-[12px] text-[rgba(244,236,216,0.5)] mt-1">History only — separate ledger per institution. Not a payment gateway.</p>
        </div>
        <DemoTag />
      </div>

      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <p className="font-display text-lg flex items-center gap-2"><Coins size={16} className="text-[var(--color-gold)]" /> {editingId ? "Correct entry" : "Add collection entry"}</p>
          {!isAdmin && (
            <span className="chip !border-[rgba(217,93,57,0.5)] !text-[#f2b09d]"><Lock size={10} /> Administrator only</span>
          )}
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div>
            <label className="label">Collection date</label>
            <input type="date" className="input" value={form.collectionDate} onChange={set("collectionDate")} disabled={!isAdmin} />
          </div>
          <div>
            <label className="label">Cash (₹)</label>
            <input className="input" inputMode="decimal" placeholder="e.g. 18250" value={form.cashRupees} onChange={set("cashRupees")} disabled={!isAdmin} />
          </div>
          <div>
            <label className="label">Cheque / Draft (₹)</label>
            <input className="input" inputMode="decimal" placeholder="e.g. 5000" value={form.draftRupees} onChange={set("draftRupees")} disabled={!isAdmin} />
          </div>
          <div className="lg:col-span-2">
            <label className="label">Committee / audit note</label>
            <input className="input" placeholder="Unsealing committee reference…" value={form.committeeNote} onChange={set("committeeNote")} disabled={!isAdmin} />
          </div>
          <div className="sm:col-span-2 lg:col-span-1">
            <label className="label">Source reference</label>
            <input className="input" placeholder="Register folio…" value={form.sourceRef} onChange={set("sourceRef")} disabled={!isAdmin} />
          </div>
        </div>
        <div className="flex items-center gap-3 mt-4">
          <button className="btn btn-primary btn-sm" onClick={submit} disabled={!isAdmin || busy || !form.collectionDate}>
            {busy ? <Spinner size={13} /> : <Plus size={13} />} {editingId ? "Save correction" : "Add entry"}
          </button>
          {editingId && <button className="btn btn-ghost btn-sm" onClick={() => { setEditingId(null); setForm(emptyForm); }}>Cancel edit</button>}
          {message && <p className={`text-[12px] ${message.ok ? "text-[#b7c895]" : "text-[#f2b09d]"}`}>{message.text}</p>}
        </div>
      </div>

      <div className="table-shell overflow-x-auto">
        <table className="min-w-[820px]">
          <thead>
            <tr><th>Date</th><th>Cash</th><th>Draft</th><th>Total</th><th>Committee note</th><th>Source</th><th className="w-24">Actions</th></tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-10"><Spinner className="inline" /></td></tr>
            ) : entries.length === 0 ? (
              <tr><td colSpan={7}><EmptyState icon={Coins} title="No record available" message="No collection entries exist for this institution yet." /></td></tr>
            ) : (
              entries.map((e) => (
                <tr key={e.id}>
                  <td className="font-semibold whitespace-nowrap">{formatDate(e.collectionDate)}</td>
                  <td>{formatINR(e.cashRupees)}</td>
                  <td>{formatINR(e.draftRupees)}</td>
                  <td className="font-display text-[var(--color-saffron-2)]">{formatINR(e.totalRupees)}</td>
                  <td className="text-[12px] max-w-[16rem]">{e.committeeNote ?? "—"}</td>
                  <td className="text-[12px] font-mono">{e.sourceRef ?? "—"}</td>
                  <td>
                    {isAdmin ? (
                      <div className="flex gap-1.5">
                        <button className="btn btn-ghost btn-sm !px-2" onClick={() => { setEditingId(e.id); setForm({ collectionDate: e.collectionDate, cashRupees: String(e.cashRupees), draftRupees: String(e.draftRupees), committeeNote: e.committeeNote ?? "", sourceRef: e.sourceRef ?? "" }); }} aria-label="Edit">
                          <Pencil size={12} />
                        </button>
                        <button className="btn btn-danger btn-sm !px-2" onClick={() => remove(e.id)} aria-label="Delete">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    ) : (
                      <span className="text-[10.5px] text-[rgba(244,236,216,0.35)]">admin only</span>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
