import { DEMO_NOTICE } from "@/lib/constants";
import { TriangleAlert } from "lucide-react";

export default function DemoNotice({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <div className="flex items-start gap-2.5 rounded-xl border border-[rgba(201,162,75,0.45)] bg-[rgba(201,162,75,0.09)] px-4 py-3">
        <TriangleAlert size={15} className="mt-0.5 shrink-0 text-[var(--color-gold)]" />
        <p className="text-[11.5px] leading-relaxed text-[#e8d9ae]">
          <em>{DEMO_NOTICE}</em>
        </p>
      </div>
    );
  }
  return (
    <section className="mx-auto max-w-5xl px-4 md:px-6">
      <div className="relative overflow-hidden rounded-2xl border border-[rgba(201,162,75,0.5)] bg-gradient-to-br from-[rgba(201,162,75,0.13)] to-[rgba(180,83,47,0.08)] p-6 md:p-8">
        <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-[rgba(232,137,47,0.14)] blur-3xl" />
        <div className="flex items-start gap-4">
          <span className="shrink-0 w-11 h-11 rounded-full border border-[rgba(201,162,75,0.6)] flex items-center justify-center text-[var(--color-gold)]">
            <TriangleAlert size={20} />
          </span>
          <div>
            <p className="eyebrow text-[var(--color-gold)] mb-2">Credibility Statement</p>
            <p className="font-display text-base md:text-xl leading-relaxed italic text-[#f0e3bd]">{DEMO_NOTICE}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
