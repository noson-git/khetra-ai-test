"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Landmark, Map, Archive, LayoutDashboard, Menu, X, ChevronDown } from "lucide-react";
import { useState } from "react";
import { useInstitution } from "./institution-context";

const NAV = [
  { href: "/", label: "Overview", icon: Landmark },
  { href: "/map", label: "GIS Map", icon: Map },
  { href: "/properties", label: "Temple Lands & Properties", icon: Archive },
  { href: "/admin", label: "Staff Console", icon: LayoutDashboard },
];

export function InstitutionPill({ compact = false }: { compact?: boolean }) {
  const { institutions, institutionId, setInstitutionId } = useInstitution();
  const [open, setOpen] = useState(false);
  const active = institutions.find((i) => i.id === institutionId);
  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 rounded-full border hairline bg-[rgba(244,236,216,0.05)] px-3 py-1.5 text-xs font-semibold hover:bg-[rgba(244,236,216,0.1)] transition-colors"
        aria-label="Select institution"
      >
        <span className="w-2 h-2 rounded-full bg-[var(--color-saffron)] shadow-[0_0_8px_rgba(232,137,47,0.9)]" />
        <span className={compact ? "max-w-[9rem] truncate" : ""}>{active ? active.name : "Select institution"}</span>
        <ChevronDown size={13} className={`transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-50 mt-2 w-72 card p-2 shadow-[var(--shadow-card)]">
            <p className="label px-2 pt-1">Institution / Jurisdiction</p>
            {institutions.map((i) => (
              <button
                key={i.id}
                onClick={() => {
                  setInstitutionId(i.id);
                  setOpen(false);
                }}
                className={`w-full text-left rounded-lg px-3 py-2.5 transition-colors ${
                  i.id === institutionId ? "bg-[rgba(232,137,47,0.14)]" : "hover:bg-[rgba(244,236,216,0.06)]"
                }`}
              >
                <p className="text-sm font-semibold">{i.name}</p>
                <p className="text-xs text-[rgba(244,236,216,0.5)]">
                  {i.city} · {i.district} district
                </p>
              </button>
            ))}
            <p className="px-3 pb-1 pt-2 text-[10px] leading-relaxed text-[rgba(244,236,216,0.4)]">
              Selection updates map layers, records, documents, statistics and Dana Hundi history. Kept separate from
              district / tahasil / mouza filters — endowment lands may sit in distant districts.
            </p>
          </div>
        </>
      )}
    </div>
  );
}

export default function SiteHeader() {
  const pathname = usePathname();
  const [mobile, setMobile] = useState(false);
  return (
    <header className="sticky top-0 z-[80] border-b hairline backdrop-blur-xl bg-[rgba(19,16,11,0.78)]">
      <div className="mx-auto max-w-7xl px-4 md:px-6 h-16 flex items-center justify-between gap-3">
        <Link href="/" className="flex items-center gap-3 shrink-0">
          <span className="font-odia text-xl text-[var(--color-saffron-2)] leading-none">କ୍ଷେତ୍ର</span>
          <span className="leading-tight">
            <span className="block font-display text-lg tracking-tight">KhetraAI</span>
            <span className="hidden sm:block text-[9px] uppercase tracking-[0.28em] text-[rgba(244,236,216,0.45)]">
              Endowment Spatial Intelligence
            </span>
          </span>
        </Link>
        <nav className="hidden md:flex items-center gap-1">
          {NAV.map((n) => {
            const activeHere = n.href === "/" ? pathname === "/" : pathname.startsWith(n.href);
            return (
              <Link
                key={n.href}
                href={n.href}
                className={`px-3.5 py-1.5 rounded-full text-[0.83rem] font-medium transition-colors ${
                  activeHere
                    ? "bg-[rgba(232,137,47,0.16)] text-[var(--color-saffron-2)]"
                    : "text-[rgba(244,236,216,0.7)] hover:bg-[rgba(244,236,216,0.07)]"
                }`}
              >
                {n.label}
              </Link>
            );
          })}
        </nav>
        <div className="flex items-center gap-2">
          <div className="hidden sm:block">
            <InstitutionPill compact />
          </div>
          <button className="md:hidden btn-ghost btn btn-sm !px-2.5" onClick={() => setMobile((v) => !v)} aria-label="Menu">
            {mobile ? <X size={16} /> : <Menu size={16} />}
          </button>
        </div>
      </div>
      {mobile && (
        <div className="md:hidden border-t hairline px-4 py-3 space-y-1 bg-[rgba(19,16,11,0.95)]">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              onClick={() => setMobile(false)}
              className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium hover:bg-[rgba(244,236,216,0.06)]"
            >
              <n.icon size={15} className="text-[var(--color-saffron-2)]" /> {n.label}
            </Link>
          ))}
          <div className="pt-2">
            <InstitutionPill />
          </div>
        </div>
      )}
    </header>
  );
}
