"use client";

import "leaflet/dist/leaflet.css";
import { useEffect, useMemo, useRef, useState } from "react";
import { Satellite, Map as MapIcon, Layers, AlertTriangle } from "lucide-react";
import { BASEMAPS, type BasemapId } from "@/lib/constants";
import type { Institution } from "./institution-context";

export type MapProperty = {
  id: string;
  assetCode: string;
  title: string;
  assetType: string;
  mouza: string;
  tahasil: string;
  district: string;
  khataNo: string | null;
  plotNo: string | null;
  areaOriginal: string | null;
  status: string;
  reportedConcern?: boolean;
  concernNote?: string | null;
  geom: { type: "Polygon"; coordinates: number[][][] } | null;
  lat: number | null;
  lng: number | null;
  geometryNote?: string | null;
};

type LeafletNS = typeof import("leaflet");

const FILL_COLORS: Record<string, string> = { land: "#d9a441", building: "#d95d39", other: "#5ba393" };

export default function GisMap({
  properties,
  institution,
  selectedId,
  onSelect,
  heightClass = "h-[70vh]",
  showControls = true,
  focus,
  initialZoom = 11,
}: {
  properties: MapProperty[];
  institution: Institution | null;
  selectedId?: string | null;
  onSelect?: (id: string) => void;
  heightClass?: string;
  showControls?: boolean;
  focus?: { lat: number; lng: number; zoom?: number } | null;
  initialZoom?: number;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<import("leaflet").Map | null>(null);
  const LRef = useRef<LeafletNS | null>(null);
  const parcelGroupRef = useRef<import("leaflet").LayerGroup | null>(null);
  const templeGroupRef = useRef<import("leaflet").LayerGroup | null>(null);
  const baseLayersRef = useRef<Record<BasemapId, import("leaflet").TileLayer[]>>({ satellite: [], labeled: [], street: [] });
  const overlayRef = useRef<import("leaflet").TileLayer | null>(null);
  const errorCountRef = useRef(0);
  const fallbackFiredRef = useRef(false);

  const [basemap, setBasemap] = useState<BasemapId>("satellite");
  const [fillOpacity, setFillOpacity] = useState(0.32);
  const [fallbackNotice, setFallbackNotice] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  /* ---------------- init map ---------------- */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = await import("leaflet");
      if (cancelled || !containerRef.current || mapRef.current) return;
      LRef.current = L;
      const center: [number, number] = institution ? [institution.lat, institution.lng] : [20.25, 85.83];
      const map = L.map(containerRef.current, {
        center,
        zoom: initialZoom,
        zoomControl: true,
        attributionControl: true,
        worldCopyJump: true,
      });
      mapRef.current = map;

      const handleTileError = () => {
        errorCountRef.current += 1;
        if (errorCountRef.current >= 8 && !fallbackFiredRef.current) {
          fallbackFiredRef.current = true;
          setFallbackNotice("Satellite tiles failed to load — switched to the street map fallback.");
          setBasemap("street");
        }
      };

      baseLayersRef.current = {
        satellite: [
          L.tileLayer(BASEMAPS.satellite.url, { attribution: BASEMAPS.satellite.attribution, maxZoom: 19, crossOrigin: true }),
        ],
        labeled: [
          L.tileLayer(BASEMAPS.labeled.url, { attribution: BASEMAPS.labeled.attribution, maxZoom: 19, crossOrigin: true }),
        ],
        street: [L.tileLayer(BASEMAPS.street.url, { attribution: BASEMAPS.street.attribution, maxZoom: 20 })],
      };
      baseLayersRef.current.satellite[0].on("tileerror", handleTileError);
      baseLayersRef.current.labeled[0].on("tileerror", handleTileError);

      overlayRef.current = L.tileLayer(BASEMAPS.labeled.overlayUrl!, { maxZoom: 19, pane: "shadowPane" });

      parcelGroupRef.current = L.layerGroup().addTo(map);
      templeGroupRef.current = L.layerGroup().addTo(map);
      L.control.scale({ imperial: false }).addTo(map);

      baseLayersRef.current.satellite.forEach((l) => l.addTo(map));
      setReady(true);
    })();
    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
      setReady(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------------- basemap switching ---------------- */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready) return;
    (Object.keys(baseLayersRef.current) as BasemapId[]).forEach((k) => {
      baseLayersRef.current[k].forEach((l) => {
        if (map.hasLayer(l)) map.removeLayer(l);
      });
    });
    baseLayersRef.current[basemap].forEach((l) => l.addTo(map));
    if (overlayRef.current) {
      if (basemap === "labeled") {
        if (!map.hasLayer(overlayRef.current)) overlayRef.current.addTo(map);
      } else if (map.hasLayer(overlayRef.current)) map.removeLayer(overlayRef.current);
    }
  }, [basemap, ready]);

  /* ---------------- parcels + temple marker ---------------- */
  useEffect(() => {
    const L = LRef.current;
    const map = mapRef.current;
    if (!L || !map || !ready) return;

    // temple marker — ACTUAL location, visually distinct
    if (templeGroupRef.current) {
      templeGroupRef.current.clearLayers();
      if (institution) {
        const icon = L.divIcon({
          className: "",
          html: `<div class="map-temple-pin" style="display:flex;flex-direction:column;align-items:center;transform:translate(-50%,-100%)">
              <svg width="26" height="34" viewBox="0 0 26 34" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 0C6 0 0.8 5.2 0.8 11.8c0 8.4 9.4 19.9 11.6 22.3a1 1 0 0 0 1.5 0C16.1 31.7 25.2 20.2 25.2 11.8 25.2 5.2 20 0 13 0z" fill="#e8892f" stroke="#13100b" stroke-width="1.4"/>
                <path d="M13 4.5l1.7 3.4 3.8.6-2.7 2.7.6 3.8-3.4-1.8-3.4 1.8.6-3.8L7.5 8.5l3.8-.6z" fill="#13100b"/>
              </svg>
              <div style="background:#13100b;border:1px solid rgba(244,236,216,.35);color:#f4ecd8;font-size:10px;font-weight:700;letter-spacing:.04em;padding:3px 8px;border-radius:999px;margin-top:3px;white-space:nowrap;max-width:190px;overflow:hidden;text-overflow:ellipsis">${institution.name.replace(/</g, "&lt;")}</div>
            </div>`,
          iconSize: [26, 60],
          iconAnchor: [13, 58],
        });
        const marker = L.marker([institution.lat, institution.lng], { icon, zIndexOffset: 1000 }).addTo(templeGroupRef.current);
        marker.bindTooltip(
          `<strong>${institution.name}</strong><br/>Actual temple location marker.<br/><span style="opacity:.7">Not a property parcel.</span>`,
          { direction: "top", offset: [0, -52] },
        );
      }
    }

    // illustrative parcels
    if (parcelGroupRef.current) {
      parcelGroupRef.current.clearLayers();
      for (const p of properties) {
        if (!p.geom || !p.geom.coordinates?.[0]) continue;
        const ring = p.geom.coordinates[0].map((c) => [c[1], c[0]] as [number, number]);
        const color = FILL_COLORS[p.assetType] ?? FILL_COLORS.other;
        const poly = L.polygon(ring, {
          color: "#ffe2ad",
          weight: p.id === selectedId ? 3.2 : 1.8,
          opacity: 0.95,
          fillColor: color,
          fillOpacity: p.id === selectedId ? Math.min(1, fillOpacity + 0.25) : fillOpacity,
          dashArray: "5 4",
        });
        const meta = [p.assetCode, p.mouza ? `Mouza: ${p.mouza}` : null, p.khataNo ? `Khata ${p.khataNo}` : null, p.plotNo ? `Plot ${p.plotNo}` : null, p.areaOriginal].filter(Boolean).join(" · ");
        poly.bindTooltip(
          `<div style="max-width:240px"><strong>${p.title}</strong><br/><span style="opacity:.75;font-size:11px">${meta}</span><br/><span style="color:#d9a441;font-size:10px">Illustrative parcel — not a survey boundary${p.reportedConcern ? "<br/>⚠ " + (p.concernNote ?? "Reported concern — not legally determined") : ""}</span></div>`,
          { sticky: true },
        );
        poly.on("click", () => onSelect?.(p.id));
        poly.addTo(parcelGroupRef.current);
      }
    }

    // framing
    const boundsParcel: [number, number][] = [];
    for (const p of properties) {
      if (p.geom?.coordinates?.[0]) for (const c of p.geom.coordinates[0]) boundsParcel.push([c[1], c[0]]);
    }
    if (boundsParcel.length >= 3) {
      map.fitBounds(L.latLngBounds(boundsParcel).pad(0.25), { maxZoom: 15 });
    } else if (institution) {
      map.setView([institution.lat, institution.lng], 13);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [properties, institution, ready]);

  /* selection highlight restyle without refit */
  useEffect(() => {
    const g = parcelGroupRef.current;
    if (!g) return;
    let i = 0;
    const withGeom = properties.filter((p) => p.geom?.coordinates?.[0]);
    g.eachLayer((layer) => {
      const p = withGeom[i++];
      const poly = layer as import("leaflet").Polygon;
      poly.setStyle({
        weight: p?.id === selectedId ? 3.2 : 1.8,
        fillOpacity: p?.id === selectedId ? Math.min(1, fillOpacity + 0.25) : fillOpacity,
      });
    });
  }, [selectedId, fillOpacity, properties]);

  /* flyTo on external focus */
  useEffect(() => {
    if (focus && mapRef.current && ready) {
      mapRef.current.flyTo([focus.lat, focus.lng], focus.zoom ?? 15, { duration: 1.1 });
    }
  }, [focus, ready]);

  const notice = useMemo(() => {
    if (basemap === "street") return null;
    return "Imagery date, resolution & accuracy vary by location and scale — not survey-accurate, never proof of ownership.";
  }, [basemap]);

  return (
    <div className={`relative w-full ${heightClass} overflow-hidden rounded-2xl border hairline bg-[#0e0c08]`}>
      <div ref={containerRef} className="absolute inset-0 z-0" />

      {showControls && (
        <>
          {/* basemap switcher */}
          <div className="absolute top-3 left-3 z-[500] flex flex-wrap gap-1.5 rounded-xl border hairline bg-[rgba(19,16,11,0.85)] backdrop-blur-md p-1.5">
            {(
              [
                { id: "satellite", icon: Satellite, label: "Satellite" },
                { id: "labeled", icon: Layers, label: "Satellite + Labels" },
                { id: "street", icon: MapIcon, label: "Street" },
              ] as { id: BasemapId; icon: typeof Satellite; label: string }[]
            ).map((b) => (
              <button
                key={b.id}
                onClick={() => {
                  errorCountRef.current = 0;
                  setFallbackNotice(null);
                  fallbackFiredRef.current = false;
                  setBasemap(b.id);
                }}
                className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-semibold transition-colors ${
                  basemap === b.id ? "bg-[rgba(232,137,47,0.25)] text-[var(--color-saffron-2)]" : "text-[rgba(244,236,216,0.7)] hover:bg-[rgba(244,236,216,0.08)]"
                }`}
              >
                <b.icon size={12} /> {b.label}
              </button>
            ))}
          </div>

          {/* opacity slider */}
          <div className="absolute bottom-4 left-3 z-[500] w-56 rounded-xl border hairline bg-[rgba(19,16,11,0.85)] backdrop-blur-md p-3">
            <div className="flex justify-between text-[10px] font-semibold uppercase tracking-[0.14em] text-[rgba(244,236,216,0.55)] mb-1.5">
              <span>Parcel fill</span>
              <span className="text-[var(--color-saffron-2)]">{Math.round(fillOpacity * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(fillOpacity * 100)}
              onChange={(e) => setFillOpacity(Number(e.target.value) / 100)}
              className="w-full accent-[#e8892f]"
              aria-label="Parcel fill opacity"
            />
          </div>

          {/* legend */}
          <div className="absolute bottom-4 right-3 z-[500] max-w-[240px] rounded-xl border hairline bg-[rgba(19,16,11,0.85)] backdrop-blur-md p-3 space-y-1.5">
            <LegendSwatch color="#e8892f" pin label="Temple marker — actual location" />
            <LegendSwatch color="#d9a441" label="Land parcel (illustrative)" />
            <LegendSwatch color="#d95d39" label="Building (illustrative)" />
            <LegendSwatch color="#5ba393" label="Other asset (illustrative)" />
            {notice && <p className="text-[9.5px] leading-snug text-[rgba(244,236,216,0.45)] pt-1 border-t hairline">{notice}</p>}
          </div>
        </>
      )}

      {(fallbackNotice || !ready) && (
        <div className="absolute top-3 right-3 z-[600] flex max-w-xs items-center gap-2 rounded-xl border border-[rgba(232,137,47,0.5)] bg-[rgba(19,16,11,0.92)] px-3 py-2 text-[11px] text-[var(--color-saffron-2)]">
          <AlertTriangle size={13} className="shrink-0" />
          {fallbackNotice ?? "Loading map tiles…"}
        </div>
      )}
    </div>
  );
}

function LegendSwatch({ color, label, pin = false }: { color: string; label: string; pin?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <span className={`inline-block shrink-0 ${pin ? "w-2.5 h-2.5 rounded-full" : "w-3.5 h-2.5 rounded-[3px]"}`} style={{ background: color }} />
      <span className="text-[10px] leading-tight text-[rgba(244,236,216,0.65)]">{label}</span>
    </div>
  );
}
