"use client";

import { FlaskConical, Loader2, MapPinOff, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { STATUS_LABELS, type Status } from "@/lib/constants";

export function DemoTag({ label = "Demo / Sample Data" }: { label?: string }) {
  return (
    <span className="chip chip-demo">
      <FlaskConical size={11} strokeWidth={2.2} />
      {label}
    </span>
  );
}

export function StatusChip({ status }: { status: string }) {
  const label = STATUS_LABELS[status as Status] ?? status;
  return <span className={`chip chip-status-${status}`}>{label}</span>;
}

export function Spinner({ size = 16, className = "" }: { size?: number; className?: string }) {
  return <Loader2 size={size} className={`spin ${className}`} />;
}

export function EmptyState({
  icon: Icon = MapPinOff,
  title,
  message,
  action,
}: {
  icon?: LucideIcon;
  title: string;
  message?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center text-center gap-3 py-14 px-6">
      <div className="w-12 h-12 rounded-full border hairline flex items-center justify-center text-[rgba(244,236,216,0.5)]">
        <Icon size={20} />
      </div>
      <p className="font-display text-lg">{title}</p>
      {message ? <p className="text-sm text-[rgba(244,236,216,0.55)] max-w-md">{message}</p> : null}
      {action}
    </div>
  );
}

export function Field({ label, value, mono = false }: { label: string; value: ReactNode; mono?: boolean }) {
  if (value === null || value === undefined || value === "") return null;
  return (
    <div className="min-w-0">
      <div className="label !mb-1">{label}</div>
      <div className={`text-sm leading-snug break-words ${mono ? "font-mono text-[0.82rem]" : ""}`}>{value}</div>
    </div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  right,
}: {
  eyebrow: string;
  title: ReactNode;
  right?: ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
      <div>
        <p className="eyebrow text-[var(--color-saffron-2)] mb-2">{eyebrow}</p>
        <h2 className="font-display text-3xl md:text-4xl leading-tight">{title}</h2>
      </div>
      {right}
    </div>
  );
}

export function formatINR(v: number | null | undefined): string {
  if (v === null || v === undefined || Number.isNaN(v)) return "—";
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(v);
}

export function formatDate(d: string | null | undefined): string {
  if (!d) return "—";
  const dt = new Date(d.length === 10 ? `${d}T00:00:00` : d);
  if (Number.isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}
