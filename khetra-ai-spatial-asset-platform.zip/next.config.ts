import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Keep native/WASM and worker-based packages out of the bundler so they
  // resolve from node_modules at runtime (OCR + image enhancement).
  serverExternalPackages: ["sharp", "tesseract.js", "pg"],
};

export default nextConfig;
