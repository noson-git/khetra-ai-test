/**
 * KhetraAI demonstration dataset seeder.
 *
 * Every record inserted here is FICTIONAL SAMPLE DATA. Parcel geometry is
 * procedurally generated illustrative geometry. Scanned documents are
 * synthetically rendered "aged paper" pages carrying a SAMPLE watermark.
 *
 * Run:  npx tsx scripts/seed.ts
 */
import "dotenv/config";
import { randomUUID } from "node:crypto";
import { mkdir } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";
import { db } from "../src/db";
import { auditLog, documents, documentVersions, hundiEntries, institutions, properties, users } from "../src/db/schema";
import { sql } from "drizzle-orm";
import { hashPassword } from "../src/lib/password";
import { illustrativePolygon } from "../src/lib/geo";

const now = () => new Date();

/* ------------------------------------------------------------------ */
/* Synthetic "aged paper" scans                                        */
/* ------------------------------------------------------------------ */

type ScanSpec = {
  heading: string;
  sub: string;
  lines: [string, string][];
  table?: { head: string[]; rows: string[][] };
  dateLine: string;
  footnote: string;
  fade?: number; // 0..1 text opacity reduction for degraded-scan honesty demo
  blur?: number;
  stamp?: string;
};

function scanSvg(spec: ScanSpec): string {
  const W = 1654;
  const H = 2339;
  const opacity = spec.fade !== undefined ? 1 - spec.fade : 1;
  const content: string[] = [];
  content.push(`<rect width="${W}" height="${H}" fill="${spec.fade ? "#e7dcc0" : "#f1e8cf"}"/>`);
  if (spec.fade) content.push(`<rect width="${W}" height="${H}" fill="#d8c9a4" opacity="0.35"/>`);
  // paper noise + stains
  content.push(`
    <filter id="noise"><feTurbulence type="fractalNoise" baseFrequency="0.012 0.018" numOctaves="4" seed="7" result="n"/>
    <feColorMatrix in="n" type="matrix" values="0 0 0 0 0.32  0 0 0 0 0.25  0 0 0 0 0.14  0 0 0 0.5 0"/></filter>
    <rect width="${W}" height="${H}" filter="url(#noise)" opacity="0.55"/>`);
  const stains = [
    [300, 480, 210, 0.10], [1250, 300, 160, 0.09], [900, 1750, 260, 0.11], [250, 1900, 150, 0.10], [1400, 1250, 120, 0.08],
  ];
  for (const [cx, cy, r, o] of stains) {
    content.push(`<circle cx="${cx}" cy="${cy}" r="${r}" fill="#8a6a32" opacity="${o}"/>`);
    content.push(`<circle cx="${cx + 30}" cy="${cy - 20}" r="${r * 0.55}" fill="#6d4f22" opacity="${o * 0.6}"/>`);
  }
  // border
  content.push(`<rect x="70" y="70" width="${W - 140}" height="${H - 140}" fill="none" stroke="#4a3a20" stroke-width="3" opacity="${0.8 * opacity}"/>`);
  content.push(`<rect x="88" y="88" width="${W - 176}" height="${H - 176}" fill="none" stroke="#4a3a20" stroke-width="1.4" opacity="${0.6 * opacity}"/>`);

  const textOp = 0.92 * opacity;
  const blurAttr = spec.blur ? ` filter="url(#soft)"` : "";
  if (spec.blur) content.push(`<filter id="soft"><feGaussianBlur stdDeviation="${spec.blur}"/></filter>`);

  content.push(`<g font-family="'Courier New', Courier, monospace" fill="#2c2416"${blurAttr}>`);
  content.push(`<text x="${W / 2}" y="200" text-anchor="middle" font-size="44" font-weight="bold" letter-spacing="3" opacity="${textOp}">${esc(spec.heading)}</text>`);
  content.push(`<text x="${W / 2}" y="255" text-anchor="middle" font-size="30" opacity="${textOp}">${esc(spec.sub)}</text>`);
  content.push(`<line x1="200" y1="300" x2="${W - 200}" y2="300" stroke="#4a3a20" stroke-width="2" opacity="${0.7 * opacity}"/>`);

  let y = 380;
  for (const [label, value] of spec.lines) {
    content.push(`<text x="220" y="${y}" font-size="32" font-weight="bold" opacity="${textOp}">${esc(label)}</text>`);
    content.push(`<text x="700" y="${y}" font-size="32" opacity="${textOp}">${esc(value)}</text>`);
    y += 74;
  }

  if (spec.table) {
    y += 20;
    const x0 = 200;
    const x1 = W - 200;
    const rh = 62;
    content.push(`<line x1="${x0}" y1="${y - 34}" x2="${x1}" y2="${y - 34}" stroke="#4a3a20" stroke-width="2" opacity="${0.7 * opacity}"/>`);
    const cols = spec.table.head.length;
    const cw = (x1 - x0) / cols;
    spec.table.head.forEach((h, i) => {
      content.push(`<text x="${x0 + 16 + i * cw}" y="${y}" font-size="27" font-weight="bold" opacity="${textOp}">${esc(h)}</text>`);
    });
    y += 26;
    content.push(`<line x1="${x0}" y1="${y}" x2="${x1}" y2="${y}" stroke="#4a3a20" stroke-width="1.6" opacity="${0.65 * opacity}"/>`);
    for (const row of spec.table.rows) {
      y += rh;
      row.forEach((cell, i) => {
        content.push(`<text x="${x0 + 16 + i * cw}" y="${y - 14}" font-size="27" opacity="${textOp}">${esc(cell)}</text>`);
      });
      content.push(`<line x1="${x0}" y1="${y + 10}" x2="${x1}" y2="${y + 10}" stroke="#4a3a20" stroke-width="1" opacity="${0.4 * opacity}"/>`);
    }
  }

  content.push(`<text x="220" y="${H - 420}" font-size="30" opacity="${textOp}">${esc(spec.dateLine)}</text>`);
  content.push(`<text x="220" y="${H - 340}" font-size="24" opacity="${0.75 * opacity}">${esc(spec.footnote)}</text>`);
  // specimen seal ring — explicitly non-official
  content.push(`
    <g transform="translate(${W - 430}, ${H - 420})" opacity="${0.6 * opacity}">
      <circle r="130" fill="none" stroke="#7c3f21" stroke-width="4"/>
      <circle r="104" fill="none" stroke="#7c3f21" stroke-width="1.6"/>
      <text text-anchor="middle" y="-14" font-size="26" font-weight="bold" fill="#7c3f21" letter-spacing="2">SPECIMEN</text>
      <text text-anchor="middle" y="22" font-size="20" fill="#7c3f21">DEMONSTRATION</text>
      <text text-anchor="middle" y="52" font-size="16" fill="#7c3f21">NOT AN OFFICIAL SEAL</text>
    </g>`);
  content.push("</g>");

  // SAMPLE watermark band
  content.push(`
    <g transform="translate(${W / 2}, ${H / 2}) rotate(-24)" opacity="0.10">
      <text text-anchor="middle" font-family="'Courier New', monospace" font-size="120" font-weight="bold" fill="#5c4322" letter-spacing="14">SAMPLE DATA</text>
      <text text-anchor="middle" y="130" font-family="'Courier New', monospace" font-size="48" fill="#5c4322" letter-spacing="8">DEMONSTRATION ONLY</text>
    </g>`);

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">${content.join("\n")}</svg>`;
}

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

async function renderScan(id: string, spec: ScanSpec): Promise<string> {
  const rel = `documents/${id}-original.png`;
  const abs = path.join(process.cwd(), "storage", rel);
  await mkdir(path.dirname(abs), { recursive: true });
  await sharp(Buffer.from(scanSvg(spec))).png({ compressionLevel: 9 }).toFile(abs);
  return rel;
}

/* ------------------------------------------------------------------ */
/* Seed                                                                */
/* ------------------------------------------------------------------ */

async function main() {
  const existing = await db.select({ c: sql<number>`count(*)::int` }).from(properties);
  if ((existing[0]?.c ?? 0) > 0) {
    console.log("Seed skipped — demonstration data already present (properties table is not empty).");
    return;
  }
  console.log("Seeding demonstration dataset…");

  /* users */
  const [admin] = await db
    .insert(users)
    .values([
      { username: "admin", displayName: "Devdutta Mishra (Administrator)", role: "admin", passwordHash: hashPassword("admin123") },
      { username: "reviewer", displayName: "Sujata Rath (Reviewer)", role: "reviewer", passwordHash: hashPassword("review123") },
      { username: "operator", displayName: "Prakash Behera (Data Entry Operator)", role: "operator", passwordHash: hashPassword("operator123") },
    ])
    .returning();

  /* institutions */
  await db.insert(institutions).values([
    {
      id: "lingaraj",
      name: "Lingaraj Temple — Bhubaneswar",
      nameOdia: "ଲିଙ୍ଗରାଜ ମନ୍ଦିର",
      deity: "Lord Lingaraj (Harihara)",
      type: "temple",
      city: "Bhubaneswar (Old Town)",
      district: "Khordha",
      lat: 20.23833,
      lng: 85.83515,
    },
    {
      id: "jagannath",
      name: "Shree Jagannath Temple — Puri",
      nameOdia: "ଶ୍ରୀ ଜଗନ୍ନାଥ ମନ୍ଦିର",
      deity: "Lord Jagannath",
      type: "temple",
      city: "Puri",
      district: "Puri",
      lat: 19.80472,
      lng: 85.81811,
    },
  ]);

  /* properties — fictional, geographically dispersed endowment demos */
  type P = {
    code: string; inst: string; type: string; title: string; desc?: string;
    district: string; tahasil: string; mouza: string; khata?: string; plot?: string;
    kisam?: string; areaO?: string; unit?: string; acres?: number; date?: string; ref?: string;
    status: string; lat: number; lng: number; size?: number; concern?: boolean; concernNote?: string;
  };
  const props: P[] = [
    { code: "KTR-LT-0001", inst: "lingaraj", type: "land", title: "Old Town sevayat bhoomi plot", desc: "Illustrative endowment land entry modelled on how a pre-merger RoR extract would be indexed.", district: "Khordha", tahasil: "Bhubaneswar", mouza: "Old Town", khata: "241/137", plot: "812", kisam: "Patita", areaO: "1 Acres 12 Decimals", unit: "Acres & Decimals", acres: 1.12, date: "1987-03-12", ref: "ROR-KH/1987/4412", status: "published", lat: 20.2379, lng: 85.8414 },
    { code: "KTR-LT-0002", inst: "lingaraj", type: "land", title: "Kapileswar paddy-bandh plot", district: "Khordha", tahasil: "Bhubaneswar", mouza: "Kapileswar", khata: "188", plot: "1403", kisam: "Sarad", areaO: "2 Acres 35 Decimals", unit: "Acres & Decimals", acres: 2.35, date: "1991-11-02", ref: "ROR-KH/1991/0904", status: "published", lat: 20.2264, lng: 85.8519 },
    { code: "KTR-LT-0003", inst: "lingaraj", type: "building", title: "Old Town Sanskrit pathshala block", desc: "Masonry structure registered as a temple-managed building asset (fictional demonstration).", district: "Khordha", tahasil: "Bhubaneswar", mouza: "Old Town", khata: "241/140", plot: "900", kisam: "Bari", areaO: "0 Acres 45 Decimals", unit: "Acres & Decimals", acres: 0.45, date: "2003-06-21", ref: "BLD-EN/2003/012", status: "published", lat: 20.2356, lng: 85.8445 },
    { code: "KTR-LT-0004", inst: "lingaraj", type: "land", title: "Janla grazing-adjacent plot", district: "Khordha", tahasil: "Jatani", mouza: "Janla", khata: "77", plot: "2110", kisam: "Rakhit", areaO: "3 Acres 60 Decimals", unit: "Acres & Decimals", acres: 3.6, date: "1979-01-09", ref: "SET-JT/1979/338", status: "approved", lat: 20.1548, lng: 85.7146, size: 70 },
    { code: "KTR-LT-0005", inst: "lingaraj", type: "land", title: "Teisipur cooperative-share plot", desc: "Fictional plot carrying a reported-concern workflow flag — invented storyline, no real parties.", district: "Puri", tahasil: "Pipili", mouza: "Teisipur", khata: "305/8", plot: "176", kisam: "Sarad", areaO: "5 Acres 20 Decimals", unit: "Acres & Decimals", acres: 5.2, date: "1984-08-15", ref: "ROR-PU/1984/771", status: "published", lat: 20.1286, lng: 85.8362, size: 80, concern: true, concernNote: "A fictional citizen flagged this demonstrative parcel through a grievance form. Workflow demo only." },
    { code: "KTR-LT-0006", inst: "lingaraj", type: "land", title: "Old Town ghata-side strip", district: "Khordha", tahasil: "Bhubaneswar", mouza: "Old Town", khata: "242", plot: "45", kisam: "Dhoba", areaO: "0 Acres 88 Decimals", unit: "Acres & Decimals", acres: 0.88, date: "1996-04-30", ref: "ROR-KH/1996/1210", status: "needs_review", lat: 20.24022, lng: 85.83898 },
    { code: "KTR-SJ-0001", inst: "jagannath", type: "land", title: "Balukhanda samil agriculture plot", district: "Puri", tahasil: "Puri Sadar", mouza: "Balukhanda", khata: "66", plot: "2210", kisam: "Sarad", areaO: "18 Guntha 4 Mana", unit: "Guntha & Mana", acres: 0.45, date: "1972-05-19", ref: "SET-PU/1972/119", status: "published", lat: 19.80111, lng: 85.87385 },
    { code: "KTR-SJ-0002", inst: "jagannath", type: "land", title: "Kundheibenta kitchen-garden plot", district: "Puri", tahasil: "Puri Sadar", mouza: "Kundheibenta", khata: "119/2", plot: "540", kisam: "Paili", areaO: "2 Acres 05 Decimals", unit: "Acres & Decimals", acres: 2.05, date: "1989-09-11", ref: "ROR-PU/1989/2081", status: "published", lat: 19.80185, lng: 85.84035 },
    { code: "KTR-SJ-0003", inst: "jagannath", type: "building", title: "Bidanasi rest-house structure", district: "Cuttack", tahasil: "Cuttack Sadar", mouza: "Bidanasi", khata: "410", plot: "2215", kisam: "Bari", areaO: "0 Acres 60 Decimals", unit: "Acres & Decimals", acres: 0.6, date: "2001-02-14", ref: "BLD-CT/2001/089", status: "published", lat: 20.4831, lng: 85.90579 },
    { code: "KTR-SJ-0004", inst: "jagannath", type: "land", title: "Khurda Road approach plot", district: "Khordha", tahasil: "Jatani", mouza: "Khurda Road", khata: "12/44", plot: "1890", kisam: "Rakhit", areaO: "12 Guntha", unit: "Guntha", acres: 0.3, date: "1993-12-02", ref: "ROR-KH/1993/0666", status: "approved", lat: 20.15335, lng: 85.70835 },
    { code: "KTR-SJ-0005", inst: "jagannath", type: "land", title: "Nayapalli leased-frontage plot", district: "Khordha", tahasil: "Bhubaneswar", mouza: "Nayapalli", khata: "561", plot: "77", kisam: "Chhota", areaO: "1 Acres 50 Decimals", unit: "Acres & Decimals", acres: 1.5, date: "2010-07-27", ref: "ROR-KH/2010/1947", status: "draft", lat: 20.2892, lng: 85.80918 },
    { code: "KTR-SJ-0006", inst: "jagannath", type: "other", title: "Kundheibenta tank-bund strip", desc: "Standing-water margin asset recorded as 'other property' in this demonstration.", district: "Puri", tahasil: "Puri Sadar", mouza: "Kundheibenta", khata: "120", plot: "545", kisam: "Jalasaya", areaO: "0 Acres 30 Decimals", unit: "Acres & Decimals", acres: 0.3, date: "1985-10-08", ref: "ROR-PU/1985/0907", status: "published", lat: 19.8032, lng: 85.84188 },
  ];

  const propIds = new Map<string, string>();
  for (const p of props) {
    const id = randomUUID();
    propIds.set(p.code, id);
    await db.insert(properties).values({
      id,
      assetCode: p.code,
      institutionId: p.inst,
      assetType: p.type,
      title: p.title,
      description: p.desc ?? null,
      district: p.district,
      tahasil: p.tahasil,
      mouza: p.mouza,
      khataNo: p.khata ?? null,
      plotNo: p.plot ?? null,
      landClass: p.kisam ?? null,
      areaOriginal: p.areaO ?? null,
      areaUnit: p.unit ?? null,
      areaAcres: p.acres !== undefined ? String(p.acres) : null,
      docDate: p.date ?? null,
      docRef: p.ref ?? null,
      geom: illustrativePolygon(p.lat, p.lng, (p.size ?? 55) * (p.acres && p.acres > 2 ? 1.4 : 1), p.code),
      lat: p.lat,
      lng: p.lng,
      status: p.status,
      reportedConcern: Boolean(p.concern),
      concernNote: p.concernNote ?? null,
      sensitiveNote: p.concern ? "Internal workflow note (demo): dispute intake reference not for public display." : "Tenant/encumbrance notes redacted in public view (demo placeholder).",
      sampleData: true,
      createdBy: admin.id,
    });
  }
  console.log(`  ${props.length} illustrative asset records`);

  /* hundi ledgers — separate per institution */
  type H = { inst: string; date: string; cash: number; draft: number; note: string; src: string };
  const hundi: H[] = [
    { inst: "lingaraj", date: "2025-11-02", cash: 61240, draft: 12500, note: "Unsealing Committee A: deputed Magistrate + Executive Officer. Count of two hundis, evening session.", src: "Hundi Register Folio 118" },
    { inst: "lingaraj", date: "2025-11-09", cash: 58815, draft: 9000, note: "Weekly unsealing. Coin-currency separation sheet attached to folio.", src: "Hundi Register Folio 119" },
    { inst: "lingaraj", date: "2025-11-16", cash: 70520, draft: 15000, note: "Special darshan weekend; two counters reconciled.", src: "Hundi Register Folio 120" },
    { inst: "lingaraj", date: "2025-11-23", cash: 65930, draft: 8000, note: "Committee verified weigh-count of coin bags.", src: "Hundi Register Folio 121" },
    { inst: "lingaraj", date: "2025-11-30", cash: 61110, draft: 11200, note: "Standard weekly unsealing.", src: "Hundi Register Folio 122" },
    { inst: "lingaraj", date: "2025-12-07", cash: 74480, draft: 18300, note: "Kartika month close-out unsealing.", src: "Hundi Register Folio 123" },
    { inst: "lingaraj", date: "2025-12-21", cash: 82305, draft: 21000, note: "Committee B unsealing with EO audit note.", src: "Hundi Register Folio 125" },
    { inst: "lingaraj", date: "2026-01-04", cash: 91120, draft: 26400, note: "New-year footfall unsealing; three hundis.", src: "Hundi Register Folio 127" },
    { inst: "lingaraj", date: "2026-01-18", cash: 77755, draft: 19950, note: "EO countersigned; draft instruments banked next working day.", src: "Hundi Register Folio 129" },
    { inst: "jagannath", date: "2025-11-01", cash: 148230, draft: 40200, note: "Chaturdha committee unsealing; Annex-B coin verification.", src: "SJT Hundi Ledger 88-A" },
    { inst: "jagannath", date: "2025-11-08", cash: 139980, draft: 37500, note: "Weekly unsealing with magistrate observer.", src: "SJT Hundi Ledger 88-B" },
    { inst: "jagannath", date: "2025-11-15", cash: 206410, draft: 58300, note: "Panchuka approach weekend; four hundis counted.", src: "SJT Hundi Ledger 89-A" },
    { inst: "jagannath", date: "2025-11-22", cash: 188770, draft: 49000, note: "Panchuka close unsealing.", src: "SJT Hundi Ledger 89-B" },
    { inst: "jagannath", date: "2025-12-06", cash: 152300, draft: 41050, note: "Standard weekly count, EO countersign.", src: "SJT Hundi Ledger 90-A" },
    { inst: "jagannath", date: "2025-12-20", cash: 181880, draft: 52700, note: "Winter footfall unsealing; Annex-C drafts listing.", src: "SJT Hundi Ledger 90-C" },
    { inst: "jagannath", date: "2026-01-01", cash: 254660, draft: 68900, note: "New-year unsealing; five hundis, dual committee.", src: "SJT Hundi Ledger 91-A" },
    { inst: "jagannath", date: "2026-01-17", cash: 197345, draft: 55600, note: "Weekly unsealing; bank deposit slip referenced.", src: "SJT Hundi Ledger 91-C" },
  ];
  for (const h of hundi) {
    await db.insert(hundiEntries).values({
      id: randomUUID(),
      institutionId: h.inst,
      collectionDate: h.date,
      cashRupees: h.cash.toFixed(2),
      draftRupees: h.draft.toFixed(2),
      totalRupees: (h.cash + h.draft).toFixed(2),
      committeeNote: h.note,
      sourceRef: h.src,
      sampleData: true,
      createdBy: admin.id,
    });
  }
  console.log(`  ${hundi.length} hundi ledger entries (2 separate institutional ledgers)`);

  /* documents — rendered specimen scans */
  const doc1Id = randomUUID();
  const rel1 = await renderScan(doc1Id, {
    heading: "SETTLEMENT RECORD EXTRACT CUM ROR",
    sub: "Specimen Endowment Land Index Office of the Endowment Cell (Demo)",
    lines: [
      ["District :", "Khordha"],
      ["Tahasil :", "Bhubaneswar"],
      ["Mouza :", "Old Town"],
      ["Khata No. :", "241/137"],
      ["Plot No. :", "812"],
      ["Kisam :", "Patita"],
      ["Area :", "1 Acres 12 Decimals"],
      ["Ref No. :", "ROR-KH/1987/4412"],
      ["Recorded For :", "Lingaraj Temple Endowment (Sevayat Bhoomi)"],
    ],
    table: {
      head: ["Plot", "Kisam", "Area", "Status"],
      rows: [
        ["812", "Patita", "0-35", "Recorded"],
        ["813", "Patita", "0-40", "Recorded"],
        ["811", "Dhoba", "0-37", "Recorded"],
      ],
    },
    dateLine: "Date of Record: 12.03.1987",
    footnote: "Extract transcribed from settlement folio. Illustrative specimen — not a legal record.",
  });

  const mkField = (key: string, label: string, value: string | null, opts?: Partial<Record<"normalized" | "status" | "confidence" | "source" | "note", unknown>>) => ({
    key,
    label,
    value,
    normalized: (opts?.normalized as string | null) ?? null,
    status: (opts?.status as "ok" | "uncertain" | "illegible" | "not_detected") ?? "ok",
    confidence: (opts?.confidence as number | null) ?? 88,
    source: (opts?.source as "ocr" | "manual") ?? "ocr",
    note: opts?.note as string | undefined,
  });

  await db.insert(documents).values({
    id: doc1Id,
    institutionId: "lingaraj",
    propertyId: propIds.get("KTR-LT-0001")!,
    title: "Record of Rights extract — Old Town khata 241/137 (1987)",
    docType: "ror_extract",
    refNo: "ROR-KH/1987/4412",
    docDate: "1987-03-12",
    status: "published",
    mime: "image/png",
    sizeBytes: 0,
    originalPath: rel1,
    pageKind: "image",
    version: 1,
    sensitiveNote: "Tenant personal particulars withheld — sealed annexure reference only (demo).",
    extracted: [
      mkField("institution", "Institution / Deity", "Lingaraj Temple — Bhubaneswar", { confidence: 91 }),
      mkField("district", "District", "Khordha", { confidence: 93 }),
      mkField("tahasil", "Tahasil", "Bhubaneswar", { confidence: 90 }),
      mkField("mouza", "Mouza / Village", "Old Town", { confidence: 92 }),
      mkField("khataNo", "Khata No.", "241/137", { confidence: 89 }),
      mkField("plotNo", "Plot No.", "812", { confidence: 90 }),
      mkField("area", "Area (as recorded)", "1 Acres 12 Decimals", { normalized: "1.1200 acres", confidence: 87, note: "Decimals converted at 1 acre = 100 decimals." }),
      mkField("landClass", "Land Classification (Kisam)", "Patita", { confidence: 85 }),
      mkField("docDate", "Record Date / Year", "12.03.1987", { confidence: 86 }),
      mkField("refNo", "Document Reference No.", "ROR-KH/1987/4412", { confidence: 88 }),
    ],
    ocr: {
      status: "done",
      engine: "tesseract.js (WASM Tesseract)",
      languages: ["eng", "ori", "hin"],
      processedAt: now().toISOString(),
      avgConfidence: 89.2,
      words: 118,
      imageQuality: "legible",
      message: "Extraction verified against the scan by the reviewer (sample verification record).",
      rawText: "SETTLEMENT RECORD EXTRACT CUM ROR\nDistrict : Khordha\nTahasil : Bhubaneswar\nMouza : Old Town\nKhata No. : 241/137\nPlot No. : 812\nKisam : Patita\nArea : 1 Acres 12 Decimals\nRef No. : ROR-KH/1987/4412",
    },
    sampleData: true,
    createdBy: admin.id,
  });
  await db.insert(documentVersions).values({ documentId: doc1Id, version: 1, note: "Seed specimen scan", path: rel1, createdBy: admin.id });

  const doc2Id = randomUUID();
  const rel2 = await renderScan(doc2Id, {
    heading: "ENDOWMENT LAND REGISTER PAGE",
    sub: "Specimen Settlement Folio Balukhanda Samil (Demo)",
    lines: [
      ["District :", "Puri"],
      ["Tahasil :", "Puri Sadar"],
      ["Mouza :", "Balukhanda"],
      ["Khata No. :", "66"],
      ["Plot No. :", "2210"],
      ["Kisam :", "Sarad"],
      ["Area :", "18 Guntha 4 Mana"],
      ["Ref No. :", "SET-PU/1972/119"],
      ["Recorded For :", "Shri Jagannath Temple Endowment Samil"],
    ],
    dateLine: "Date of Record: 19.05.1972",
    footnote: "Folio partially faded; uncertain readings marked. Illustrative specimen.",
    fade: 0.42,
    blur: 0.9,
  });
  await db.insert(documents).values({
    id: doc2Id,
    institutionId: "jagannath",
    propertyId: propIds.get("KTR-SJ-0001")!,
    title: "Settlement register page — Balukhanda samil folio (1972, faded)",
    docType: "settlement",
    refNo: "SET-PU/1972/119",
    docDate: "1972-05-19",
    status: "needs_review",
    mime: "image/png",
    sizeBytes: 0,
    originalPath: rel2,
    pageKind: "image",
    version: 1,
    sensitiveNote: "Handwritten margin endorsement names two tenants — redacted publicly (demo).",
    extracted: [
      mkField("institution", "Institution / Deity", "Shree Jagannath Temple — Puri", { confidence: 54, status: "uncertain" }),
      mkField("district", "District", "Puri", { confidence: 61, status: "uncertain" }),
      mkField("tahasil", "Tahasil", "Puri Sadar", { confidence: 47, status: "uncertain" }),
      mkField("mouza", "Mouza / Village", "Balukhanda", { confidence: 58, status: "uncertain" }),
      mkField("khataNo", "Khata No.", "66", { confidence: 72 }),
      mkField("plotNo", "Plot No.", "2210", { confidence: 49, status: "uncertain" }),
      mkField("area", "Area (as recorded)", "18 Guntha 4 Mana", { normalized: "0.4500 acres (approx.)", confidence: 51, status: "uncertain", note: "Guntha normalised at 1 guntha = 0.025 acre; 'Mana' not normalised — verify regionally." }),
      mkField("landClass", "Land Classification (Kisam)", "Sarad", { confidence: 44, status: "uncertain" }),
      mkField("docDate", "Record Date / Year", "19.05.1972", { confidence: 39, status: "illegible", note: "Fading on date digits — confirm against folio." }),
      mkField("refNo", "Document Reference No.", "SET-PU/1972/119", { confidence: 55, status: "uncertain" }),
    ],
    ocr: {
      status: "done",
      engine: "tesseract.js (WASM Tesseract)",
      languages: ["eng", "ori", "hin"],
      processedAt: now().toISOString(),
      avgConfidence: 52.6,
      words: 101,
      imageQuality: "degraded",
      message: "Degraded scan — needs manual review. Low-confidence fields are highlighted; nothing is assumed.",
      rawText: "ENDOWMENT LAND REGISTER PAGE\nDistrict : Puri\nTahasil : Puri Sadar\nMouza : Balukhanda\nKhata No. : 66\nPlot No. : 2210\nKisam : Sarad\nArea : 18 Guntha 4 Mana",
    },
    sampleData: true,
    createdBy: admin.id,
  });
  await db.insert(documentVersions).values({ documentId: doc2Id, version: 1, note: "Seed specimen scan (faded)", path: rel2, createdBy: admin.id });

  const doc3Id = randomUUID();
  const rel3 = await renderScan(doc3Id, {
    heading: "OFFERING BOX OPENING REGISTER",
    sub: "Specimen Daily Collection Folio (Demo)",
    lines: [
      ["Institution :", "Shri Jagannath Temple, Puri"],
      ["Ledger :", "SJT Hundi Ledger 91-C"],
      ["Count Date :", "17-01-2026"],
      ["Cash Counted :", "Rs. 1,97,345"],
      ["Drafts / Cheques :", "Rs. 55,600"],
      ["Ref No. :", "HUN-SJT/2026/017"],
    ],
    dateLine: "Countersigned: Executive Officer (Demo)",
    footnote: "Illustrative folio for the Dana Hundi history demonstration.",
  });
  await db.insert(documents).values({
    id: doc3Id,
    institutionId: "jagannath",
    propertyId: null,
    title: "Hundi opening register folio — 17 Jan 2026 (supporting record)",
    docType: "register_page",
    refNo: "HUN-SJT/2026/017",
    docDate: "2026-01-17",
    status: "draft",
    mime: "image/png",
    sizeBytes: 0,
    originalPath: rel3,
    pageKind: "image",
    version: 1,
    sensitiveNote: null,
    extracted: null,
    ocr: { status: "pending", message: "Awaiting OCR run — open in the workbench and extract.", languages: null, processedAt: null, avgConfidence: null, words: null },
    sampleData: true,
    createdBy: admin.id,
  });
  await db.insert(documentVersions).values({ documentId: doc3Id, version: 1, note: "Seed specimen scan", path: rel3, createdBy: admin.id });

  await db.insert(auditLog).values({
    userId: null,
    userName: "system",
    userRole: "system",
    action: "seed",
    entity: "system",
    summary: "Demonstration dataset initialised — fictional institutions, assets, documents and hundi ledgers.",
  });

  console.log("Seed complete.");
  console.log("Demo accounts: admin/admin123 · reviewer/review123 · operator/operator123");
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
